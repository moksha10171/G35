<?php
class Database {
    private $host = 'localhost';
    private $username = 'u291518478_project1';
    private $password = 'Moksha@10170+10171';
    private $dbname = 'u291518478_project1';
    private $conn;

    public function getConnection() {
        $this->conn = null;

        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->dbname,
                $this->username,
                $this->password,
                array(
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
                )
            );
            return $this->conn;
        } catch(PDOException $e) {
            error_log("Connection Error: " . $e->getMessage());
            throw new Exception("Database connection failed");
        }
    }

    public function initializeTables() {
        try {
            // Companies table
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS companies (
                    id int(11) NOT NULL AUTO_INCREMENT,
                    name varchar(255) NOT NULL,
                    logo varchar(255) DEFAULT NULL,
                    description text DEFAULT NULL,
                    industry varchar(100) DEFAULT NULL,
                    location varchar(255) DEFAULT NULL,
                    website varchar(255) DEFAULT NULL,
                    founded_year int(11) DEFAULT NULL,
                    employee_count varchar(50) DEFAULT NULL,
                    rating decimal(2,1) DEFAULT NULL,
                    created_at timestamp NULL DEFAULT current_timestamp(),
                    PRIMARY KEY (id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");

            // Jobs table
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS jobs (
                    id int(11) NOT NULL AUTO_INCREMENT,
                    company_id int(11) DEFAULT NULL,
                    title varchar(255) NOT NULL,
                    description text DEFAULT NULL,
                    requirements text DEFAULT NULL,
                    responsibilities text DEFAULT NULL,
                    benefits text DEFAULT NULL,
                    job_type enum('Full-time','Part-time','Contract','Remote') DEFAULT NULL,
                    experience_level enum('Entry','Intermediate','Senior','Expert') DEFAULT NULL,
                    salary_min decimal(10,2) DEFAULT NULL,
                    salary_max decimal(10,2) DEFAULT NULL,
                    location varchar(255) DEFAULT NULL,
                    remote_option tinyint(1) DEFAULT 0,
                    status enum('Active','Filled','Expired') DEFAULT 'Active',
                    posted_date timestamp NULL DEFAULT current_timestamp(),
                    deadline_date date DEFAULT NULL,
                    views int(11) DEFAULT 0,
                    PRIMARY KEY (id),
                    KEY company_id (company_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");

            // Additional tables initialization...
            // (job_skills, job_applications, saved_jobs, etc.)
            
            return true;
        } catch(PDOException $e) {
            error_log("Table Creation Error: " . $e->getMessage());
            throw new Exception("Error initializing database tables");
        }
    }
}

// Initialize database connection
try {
    $database = new Database();
    $conn = $database->getConnection();
} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode([
        'success' => false,
        'error' => 'Database connection failed'
    ]);
    exit;
} 