<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('assets/layout/header.php');
$footer = inancap('assets/layout/footer.php');
$meta = inancap('assets/layout/meta.php');
echo $meta;
$descript = 'About TalentSphere - Connecting Talent with Opportunity';
$title = 'About TalentSphere';
echo generateMetaTags($title, $descript, '', '', 'Coding, Courses');
echo $header;
?>
    <main id="main-content">
        <!-- Hero Section -->
        <section class="about-hero">
            <div class="container">
                <div class="hero-content">
                    <h1>Our Mission to Transform Talent Acquisition</h1>
                    <p>At TalentSphere, we're revolutionizing how companies connect with top insurance talent through innovative technology and data-driven solutions.</p>
                </div>
            </div>
        </section>

        <!-- Story Section -->
        <section class="our-story">
            <div class="container">
                <div class="story-content">
                    <div class="story-header">
                        <span class="story-tag">Our Journey</span>
                        <h2>Building the Future of Insurance Recruitment</h2>
                        <p class="story-lead">Founded in 2023, TalentSphere emerged from a simple observation: the insurance industry needed a better way to connect talented professionals with outstanding opportunities.</p>
                    </div>
                    
                    <div class="story-features">
                        <div class="feature-item" data-aos="fade-up">
                            <div class="feature-icon">
                                <i class="fas fa-rocket"></i>
                            </div>
                            <div class="feature-content">
                                <h3>Innovation First</h3>
                                <p>Leveraging AI and machine learning to transform recruitment processes</p>
                            </div>
                        </div>
                        
                        <div class="feature-item" data-aos="fade-up" data-aos-delay="100">
                            <div class="feature-icon">
                                <i class="fas fa-globe"></i>
                            </div>
                            <div class="feature-content">
                                <h3>Global Reach</h3>
                                <p>Connecting talent across 20+ countries with leading insurance companies</p>
                            </div>
                        </div>
                        
                        <div class="feature-item" data-aos="fade-up" data-aos-delay="200">
                            <div class="feature-icon">
                                <i class="fas fa-handshake"></i>
                            </div>
                            <div class="feature-content">
                                <h3>Trusted Partnerships</h3>
                                <p>Building lasting relationships with industry leaders worldwide</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Values Section -->
        <section class="values">
            <div class="container">
                <div class="values-header">
                    <span class="values-tag">Our Values</span>
                    <h2>What Drives Us Forward</h2>
                    <p class="values-lead">Our core values shape every decision we make and guide our interactions with clients, candidates, and partners.</p>
                </div>
                
                <div class="values-grid">
                    <div class="value-card" data-aos="fade-up">
                        <div class="value-icon">
                            <i class="fas fa-star"></i>
                        </div>
                        <h3>Excellence</h3>
                        <p>We strive for excellence in every interaction, delivering outstanding results that exceed expectations.</p>
                    </div>
                    
                    <div class="value-card" data-aos="fade-up" data-aos-delay="100">
                        <div class="value-icon">
                            <i class="fas fa-heart"></i>
                        </div>
                        <h3>Integrity</h3>
                        <p>We maintain the highest ethical standards, ensuring transparency and trust in all our relationships.</p>
                    </div>
                    
                    <div class="value-card" data-aos="fade-up" data-aos-delay="200">
                        <div class="value-icon">
                            <i class="fas fa-lightbulb"></i>
                        </div>
                        <h3>Innovation</h3>
                        <p>We embrace new technologies and ideas to continuously improve our services and solutions.</p>
                    </div>
                    
                    <div class="value-card" data-aos="fade-up" data-aos-delay="300">
                        <div class="value-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <h3>Collaboration</h3>
                        <p>We believe in the power of teamwork and partnership to achieve extraordinary results.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Team Section -->
        <section class="team">
            <div class="container">
                <div class="team-header">
                    <span class="team-tag">Our Team</span>
                    <h2>Meet the Experts Behind TalentSphere</h2>
                    <p class="team-lead">Our diverse team of professionals brings together decades of experience in insurance recruitment and technology.</p>
                </div>
                
                <div class="team-grid">
                    <div class="team-member" data-aos="fade-up">
                        <div class="member-image">
                            <img src="assets/images/team/member1.jpg" alt="Team Member">
                        </div>
                        <div class="member-info">
                            <h3>Sarah Johnson</h3>
                            <span class="member-role">Chief Executive Officer</span>
                            <p>15+ years of experience in insurance recruitment and leadership.</p>
                            <div class="member-social">
                                <a href="#"><i class="fab fa-linkedin"></i></a>
                                <a href="#"><i class="fab fa-twitter"></i></a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="team-member" data-aos="fade-up" data-aos-delay="100">
                        <div class="member-image">
                            <img src="assets/images/team/member2.jpg" alt="Team Member">
                        </div>
                        <div class="member-info">
                            <h3>Michael Chen</h3>
                            <span class="member-role">Chief Technology Officer</span>
                            <p>Expert in AI-driven recruitment solutions and platform development.</p>
                            <div class="member-social">
                                <a href="#"><i class="fab fa-linkedin"></i></a>
                                <a href="#"><i class="fab fa-github"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main>
<?php echo $footer;?>