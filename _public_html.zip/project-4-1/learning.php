<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('assets/layout/header.php');
$footer = inancap('assets/layout/footer.php');
$meta = inancap('assets/layout/meta.php');
echo $meta;
$descript = 'TalentSphere Learning - Professional Development Courses';
$title = 'TalentSphere Learning';
echo generateMetaTags($title, $descript, '', '', 'Learning, Courses, Professional Development');
echo $header;
?>
    <main id="main-content">
        <!-- Hero Section -->
        <section class="learning-hero">
            <div class="container">
                <h1>Expand Your Professional Horizons</h1>
                <p>Access comprehensive learning resources across multiple disciplines to accelerate your career growth</p>
                
                <!-- Hero Stats -->
                <div class="hero-stats">
                    <div class="stat-item">
                        <span class="stat-number">1000+</span>
                        <span class="stat-label">Courses</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number">50K+</span>
                        <span class="stat-label">Learners</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number">15+</span>
                        <span class="stat-label">Categories</span>
                    </div>
                </div>
            </div>
        </section>

        <!-- Learning Categories -->
        <section class="course-categories">
            <div class="container">
                <div class="categories-grid">
                    <!-- Insurance Category -->
                    <div class="category-card">
                        <div class="category-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h3>Insurance Professional</h3>
                        <p>Master insurance concepts and industry practices</p>
                        <ul class="category-courses">
                            <li>Property & Casualty Insurance</li>
                            <li>Life & Health Insurance</li>
                            <li>Risk Management</li>
                            <li>Claims Processing</li>
                        </ul>
                        <a href="/courses/insurance" class="btn-category">View Courses</a>
                    </div>

                    <!-- Employment Skills -->
                    <div class="category-card">
                        <div class="category-icon">
                            <i class="fas fa-briefcase"></i>
                        </div>
                        <h3>Employment Skills</h3>
                        <p>Essential skills for workplace success</p>
                        <ul class="category-courses">
                            <li>Resume Writing</li>
                            <li>Interview Preparation</li>
                            <li>Workplace Communication</li>
                            <li>Career Development</li>
                        </ul>
                        <a href="/courses/employment" class="btn-category">View Courses</a>
                    </div>

                    <!-- Programming -->
                    <div class="category-card">
                        <div class="category-icon">
                            <i class="fas fa-code"></i>
                        </div>
                        <h3>Programming & Development</h3>
                        <p>Learn in-demand programming skills</p>
                        <ul class="category-courses">
                            <li>Web Development</li>
                            <li>Mobile App Development</li>
                            <li>Database Management</li>
                            <li>Cloud Computing</li>
                        </ul>
                        <a href="/courses/programming" class="btn-category">View Courses</a>
                    </div>

                    <!-- Aptitude -->
                    <div class="category-card">
                        <div class="category-icon">
                            <i class="fas fa-brain"></i>
                        </div>
                        <h3>Aptitude & Reasoning</h3>
                        <p>Enhance your logical and analytical skills</p>
                        <ul class="category-courses">
                            <li>Quantitative Aptitude</li>
                            <li>Logical Reasoning</li>
                            <li>Data Interpretation</li>
                            <li>Problem Solving</li>
                        </ul>
                        <a href="/courses/aptitude" class="btn-category">View Courses</a>
                    </div>

                    <!-- Language Skills -->
                    <div class="category-card">
                        <div class="category-icon">
                            <i class="fas fa-language"></i>
                        </div>
                        <h3>Language & Communication</h3>
                        <p>Master professional communication</p>
                        <ul class="category-courses">
                            <li>Business English</li>
                            <li>Professional Writing</li>
                            <li>Public Speaking</li>
                            <li>Cross-cultural Communication</li>
                        </ul>
                        <a href="/courses/language" class="btn-category">View Courses</a>
                    </div>

                    <!-- Personality Development -->
                    <div class="category-card">
                        <div class="category-icon">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <h3>Personality Development</h3>
                        <p>Build professional presence and confidence</p>
                        <ul class="category-courses">
                            <li>Leadership Skills</li>
                            <li>Emotional Intelligence</li>
                            <li>Time Management</li>
                            <li>Stress Management</li>
                        </ul>
                        <a href="/courses/personality" class="btn-category">View Courses</a>
                    </div>

                    <!-- Business Skills -->
                    <div class="category-card">
                        <div class="category-icon">
                            <i class="fas fa-chart-bar"></i>
                        </div>
                        <h3>Business Skills</h3>
                        <p>Essential business and management skills</p>
                        <ul class="category-courses">
                            <li>Project Management</li>
                            <li>Business Analytics</li>
                            <li>Strategic Planning</li>
                            <li>Financial Management</li>
                        </ul>
                        <a href="/courses/business" class="btn-category">View Courses</a>
                    </div>

                    <!-- Digital Skills -->
                    <div class="category-card">
                        <div class="category-icon">
                            <i class="fas fa-laptop"></i>
                        </div>
                        <h3>Digital Skills</h3>
                        <p>Master essential digital tools</p>
                        <ul class="category-courses">
                            <li>Digital Marketing</li>
                            <li>Data Analysis</li>
                            <li>Social Media Management</li>
                            <li>Content Creation</li>
                        </ul>
                        <a href="/courses/digital" class="btn-category">View Courses</a>
                    </div>

                    <!-- Certification Prep -->
                    <div class="category-card">
                        <div class="category-icon">
                            <i class="fas fa-certificate"></i>
                        </div>
                        <h3>Certification Preparation</h3>
                        <p>Prepare for professional certifications</p>
                        <ul class="category-courses">
                            <li>Insurance Licensing</li>
                            <li>Project Management (PMP)</li>
                            <li>IT Certifications</li>
                            <li>HR Certifications</li>
                        </ul>
                        <a href="/courses/certification" class="btn-category">View Courses</a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Newsletter Section -->
        <section class="newsletter">
            <div class="container">
                <div class="newsletter-wrapper">
                    <div class="newsletter-header">
                        <span class="newsletter-tag">Stay Updated</span>
                        <h2>Get Learning Updates</h2>
                        <p>Subscribe to our newsletter for the latest course releases and learning tips</p>
                    </div>
                    <form class="newsletter-form">
                        <div class="form-group">
                            <div class="input-wrapper">
                                <i class="fas fa-envelope input-icon"></i>
                                <input type="email" class="newsletter-input" placeholder="Enter your email">
                            </div>
                            <button type="submit" class="newsletter-button">
                                Subscribe
                                <i class="fas fa-arrow-right"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </main>
<?php echo $footer;?>