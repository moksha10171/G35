class NewsletterForm {
    constructor() {
        this.form = document.querySelector('.subscribe-form');
        this.endpoint = 'https://www.bmreducation.com/quizmaster/newsletter';
        
        if (this.form) {
            this.initializeForm();
        } else {
            console.error('Newsletter form not found in the DOM');
        }
    }

    initializeForm() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
    }

    async handleSubmit(e) {
        e.preventDefault();
        const emailInput = this.form.querySelector('input[type="email"]');
        const submitButton = this.form.querySelector('button[type="submit"]');
        
        if (!emailInput.value || !this.validateEmail(emailInput.value)) {
            this.showMessage('Please enter a valid email address', 'error');
            return;
        }

        try {
            this.toggleLoadingState(true, submitButton);

            const response = await fetch(this.endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ email: emailInput.value })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();

            if (result.success) {
                this.showMessage('Successfully subscribed to our newsletter!', 'success');
                this.form.reset();
            } else {
                throw new Error(result.message || 'Failed to subscribe');
            }
        } catch (error) {
            console.error('Subscription error:', error);
            this.showMessage(error.message || 'Unable to subscribe. Please try again later.', 'error');
        } finally {
            this.toggleLoadingState(false, submitButton);
        }
    }

    validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    toggleLoadingState(isLoading, button) {
        button.disabled = isLoading;
        button.innerHTML = isLoading ? 
            '<i class="fas fa-spinner fa-spin"></i>' : 
            'Subscribe';
    }

    showMessage(message, type) {
        // Remove existing message if any
        const existingMessage = this.form.querySelector('.newsletter-message');
        if (existingMessage) {
            existingMessage.remove();
        }

        // Create new message
        const messageElement = document.createElement('div');
        messageElement.className = `newsletter-message ${type}`;
        messageElement.innerHTML = message;

        // Insert message after the form
        this.form.insertAdjacentElement('afterend', messageElement);

        // Auto-hide after 5 seconds
        setTimeout(() => {
            messageElement.classList.add('fade-out');
            setTimeout(() => {
                if (messageElement.parentNode) {
                    messageElement.remove();
                }
            }, 300);
        }, 5000);
    }
}

// Initialize the form when DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
    new NewsletterForm();
}); 