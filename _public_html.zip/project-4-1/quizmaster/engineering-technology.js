// language-skills.js
class LanguageSkillsQuiz {
    constructor() {
        this.questions = {
            gate: [
                {
                    question: "What is the full form of GATE?",
                    options: ["Graduate Aptitude Test in Engineering", "General Aptitude Test Examination", "Graduate Assessment Test for Engineers", "General Aptitude Test in Engineering"],
                    correct: 0,
                    explanation: "GATE stands for Graduate Aptitude Test in Engineering, a national level examination in India."
                },
                {
                    question: "Which organization conducts GATE exam?",
                    options: ["IITs and IISc", "AICTE", "UGC", "MHRD"],
                    correct: 0,
                    explanation: "GATE is conducted jointly by the Indian Institutes of Technology (IITs) and Indian Institute of Science (IISc)."
                },
                {
                    question: "What is the validity period of GATE score?",
                    options: ["3 years", "2 years", "1 year", "5 years"],
                    correct: 0,
                    explanation: "GATE score is valid for three years from the date of announcement of results."
                },
                {
                    question: "Which section is common to all GATE papers?",
                    options: ["General Aptitude", "Engineering Mathematics", "Core Subject", "Programming"],
                    correct: 0,
                    explanation: "General Aptitude (GA) section is common across all GATE papers."
                },
                {
                    question: "What is the marking scheme in GATE?",
                    options: ["Positive and Negative", "Only Positive", "Only Negative", "No marking scheme"],
                    correct: 0,
                    explanation: "GATE follows both positive and negative marking scheme with negative marks for wrong answers."
                },
                {
                    question: "What is the total duration of GATE exam?",
                    options: ["3 hours", "2 hours", "4 hours", "2.5 hours"],
                    correct: 0,
                    explanation: "The total duration of GATE examination is 3 hours."
                },
                {
                    question: "What is the maximum marks in GATE?",
                    options: ["100", "1000", "500", "200"],
                    correct: 0,
                    explanation: "The total marks in GATE examination is 100."
                },
                {
                    question: "Which type of questions appear in GATE?",
                    options: ["MCQ and NAT", "Only MCQ", "Only NAT", "Subjective"],
                    correct: 0,
                    explanation: "GATE has Multiple Choice Questions (MCQ) and Numerical Answer Type (NAT) questions."
                },
                {
                    question: "What percentage is allocated to General Aptitude?",
                    options: ["15%", "20%", "10%", "25%"],
                    correct: 0,
                    explanation: "General Aptitude carries 15% weightage in GATE exam."
                },
                {
                    question: "How many papers are there in GATE?",
                    options: ["29", "25", "20", "30"],
                    correct: 0,
                    explanation: "GATE is conducted in 29 different papers representing various engineering disciplines."
                }
            ],
            ies: [
                {
                    question: "What is IES?",
                    options: ["Indian Engineering Services", "Indian Economic Services", "Indian Educational Services", "Indian Examination Services"],
                    correct: 0,
                    explanation: "IES stands for Indian Engineering Services, one of the most prestigious engineering services in India."
                },
                {
                    question: "How many stages are there in IES exam?",
                    options: ["3", "2", "4", "5"],
                    correct: 0,
                    explanation: "IES examination consists of 3 stages: Preliminary, Main and Interview."
                },
                {
                    question: "Which organization conducts IES?",
                    options: ["UPSC", "PSC", "SSC", "Railway Board"],
                    correct: 0,
                    explanation: "IES is conducted by Union Public Service Commission (UPSC)."
                },
                {
                    question: "What is the age limit for IES?",
                    options: ["21-30 years", "20-35 years", "18-30 years", "21-35 years"],
                    correct: 0,
                    explanation: "The age limit for IES is 21-30 years with relaxation for reserved categories."
                },
                {
                    question: "How many attempts are allowed in IES?",
                    options: ["6", "4", "8", "Unlimited"],
                    correct: 0,
                    explanation: "Candidates are allowed maximum 6 attempts in IES."
                },
                {
                    question: "Which ministry employs IES officers?",
                    options: ["Ministry of Railways", "Ministry of Defense", "Ministry of Education", "Ministry of External Affairs"],
                    correct: 0,
                    explanation: "IES officers are primarily employed by the Ministry of Railways."
                },
                {
                    question: "What is the exam pattern of IES Prelims?",
                    options: ["Objective Type", "Subjective Type", "Both", "Interview"],
                    correct: 0,
                    explanation: "IES Preliminary examination consists of objective type questions."
                },
                {
                    question: "How many papers are there in IES Mains?",
                    options: ["2", "3", "4", "5"],
                    correct: 0,
                    explanation: "IES Main examination consists of 2 papers."
                },
                {
                    question: "What is the medium of examination?",
                    options: ["English", "Hindi", "Both", "Any regional language"],
                    correct: 0,
                    explanation: "The medium of IES examination is English."
                },
                {
                    question: "Which service category is IES under?",
                    options: ["Group A", "Group B", "Group C", "Group D"],
                    correct: 0,
                    explanation: "IES falls under Group A services in the Government of India."
                }
            ],
            psu: [
                {
                    question: "What is PSU?",
                    options: ["Public Sector Undertaking", "Private Sector Unit", "Public Service Unit", "Private Service Undertaking"],
                    correct: 0,
                    explanation: "PSU stands for Public Sector Undertaking, government-owned corporations in India."
                },
                {
                    question: "Which exam is common for many PSUs?",
                    options: ["GATE", "CAT", "MAT", "XAT"],
                    correct: 0,
                    explanation: "GATE score is accepted by many PSUs for recruitment."
                },
                {
                    question: "Which is the largest PSU in India?",
                    options: ["Indian Oil Corporation", "ONGC", "NTPC", "BHEL"],
                    correct: 0,
                    explanation: "Indian Oil Corporation is the largest PSU in India."
                },
                {
                    question: "What is Maharatna status?",
                    options: ["Highest PSU category", "Private company status", "Joint venture status", "Foreign company status"],
                    correct: 0,
                    explanation: "Maharatna is the highest status given to Central Public Sector Enterprises in India."
                },
                {
                    question: "How many Maharatna PSUs are there?",
                    options: ["10", "8", "12", "15"],
                    correct: 0,
                    explanation: "There are 10 Maharatna PSUs in India."
                },
                {
                    question: "What is the minimum GATE score for PSU?",
                    options: ["Varies by PSU", "60%", "70%", "80%"],
                    correct: 0,
                    explanation: "The minimum GATE score requirement varies by individual PSU."
                },
                {
                    question: "Which sector has most PSUs?",
                    options: ["Manufacturing", "Service", "IT", "Agriculture"],
                    correct: 0,
                    explanation: "Manufacturing sector has the highest number of PSUs in India."
                },
                {
                    question: "What is Navratna status?",
                    options: ["Second highest PSU category", "Lowest PSU category", "Private status", "Foreign status"],
                    correct: 0,
                    explanation: "Navratna is the second highest status given to Central Public Sector Enterprises."
                },
                {
                    question: "How are PSU recruitments conducted?",
                    options: ["Written test and Interview", "Only Interview", "Only Written test", "Group Discussion"],
                    correct: 0,
                    explanation: "PSU recruitment typically involves written test followed by interview."
                },
                {
                    question: "What is the job security in PSUs?",
                    options: ["High", "Low", "Moderate", "None"],
                    correct: 0,
                    explanation: "PSUs offer high job security as they are government-owned organizations."
                }
            ]
        };

        this.currentModule = null;
        this.currentQuestionIndex = 0;
        this.userAnswers = new Map();
        this.hasAnswered = false;

        this.learningContent = {
            gate: {
                theory: `
                    <h4>GATE Exam Preparation</h4>
                    
                    <h5>1. Exam Pattern</h5>
                    <ul>
                        <li>Total Duration: 3 hours</li>
                        <li>Total Marks: 100</li>
                        <li>Question Types: MCQ and NAT</li>
                        <li>Sections: General Aptitude (15%) and Subject Paper (85%)</li>
                    </ul>

                    <h5>2. Important Topics</h5>
                    <ul>
                        <li>Engineering Mathematics</li>
                        <li>Core Subject Knowledge</li>
                        <li>General Aptitude</li>
                        <li>Current Affairs</li>
                    </ul>

                    <h5>3. Preparation Strategy</h5>
                    <ul>
                        <li>Systematic Study Plan</li>
                        <li>Regular Practice</li>
                        <li>Previous Year Papers</li>
                        <li>Mock Tests</li>
                    </ul>
                `,
                examples: `
                    <h4>GATE Sample Questions</h4>

                    <h5>1. Engineering Mathematics</h5>
                    <div class="example-box">
                        <p>Sample calculus problem...</p>
                    </div>

                    <h5>2. General Aptitude</h5>
                    <div class="example-box">
                        <p>Sample verbal ability question...</p>
                    </div>
                `,
                practice: `
                    <h4>GATE Practice Questions</h4>

                    <div class="practice-exercise">
                        <h5>1. Engineering Mathematics</h5>
                        <div class="question">
                            <p>Q1: Find the derivative of f(x) = x³ + 2x² - 4x + 1</p>
                            <p>Answer: f'(x) = 3x² + 4x - 4</p>
                        </div>
                        
                        <div class="question">
                            <p>Q2: Solve the definite integral ∫(0 to 1) x²dx</p>
                            <p>Answer: 1/3</p>
                        </div>

                        <h5>2. Digital Logic</h5>
                        <div class="question">
                            <p>Q1: Simplify the boolean expression: AB + A'B + AB'</p>
                            <p>Answer: A + B</p>
                        </div>

                        <h5>3. Computer Organization</h5>
                        <div class="question">
                            <p>Q1: What is the purpose of cache memory?</p>
                            <p>Answer: To reduce average memory access time and improve CPU performance</p>
                        </div>

                        <div class="tips">
                            <h5>Practice Tips:</h5>
                            <ul>
                                <li>Attempt these questions with a timer</li>
                                <li>Review incorrect answers thoroughly</li>
                                <li>Practice similar variations</li>
                                <li>Focus on concepts rather than memorization</li>
                            </ul>
                        </div>
                    </div>
                `
            },
            ies: {
                theory: `
                    <h4>IES Exam Preparation</h4>
                    
                    <h5>1. Exam Structure</h5>
                    <ul>
                        <li>Preliminary Examination</li>
                        <li>Main Examination</li>
                        <li>Personality Test</li>
                    </ul>

                    <h5>2. Subject Coverage</h5>
                    <ul>
                        <li>Engineering Discipline</li>
                        <li>General Studies</li>
                        <li>English and Comprehension</li>
                    </ul>
                `,
                examples: `
                    <h4>IES Sample Questions</h4>

                    <h5>1. Technical Section</h5>
                    <div class="example-box">
                        <p>Sample engineering problems...</p>
                    </div>

                    <h5>2. General Studies</h5>
                    <div class="example-box">
                        <p>Sample GS questions...</p>
                    </div>
                `,
                practice: `
                    <h4>IES Practice Questions</h4>

                    <div class="practice-exercise">
                        <h5>1. Engineering Mechanics</h5>
                        <div class="question">
                            <p>Q1: Calculate the moment of inertia for a solid cylinder about its central axis.</p>
                            <p>Answer: I = (1/2)MR²</p>
                        </div>

                        <h5>2. Thermodynamics</h5>
                        <div class="question">
                            <p>Q1: State and explain the First Law of Thermodynamics</p>
                            <p>Answer: Energy can neither be created nor destroyed, only converted from one form to another</p>
                        </div>

                        <h5>3. General Studies</h5>
                        <div class="question">
                            <p>Q1: What is India's current renewable energy target for 2030?</p>
                            <p>Answer: 450 GW of renewable energy capacity</p>
                        </div>

                        <div class="tips">
                            <h5>Practice Tips:</h5>
                            <ul>
                                <li>Focus on numerical problem solving</li>
                                <li>Keep up with current affairs</li>
                                <li>Practice drawing diagrams</li>
                                <li>Time management is crucial</li>
                            </ul>
                        </div>
                    </div>
                `
            },
            psu: {
                theory: `
                    <h4>PSU Recruitment Preparation</h4>
                    
                    <h5>1. Selection Process</h5>
                    <ul>
                        <li>GATE Score</li>
                        <li>Technical Interview</li>
                        <li>HR Interview</li>
                    </ul>

                    <h5>2. Important Topics</h5>
                    <ul>
                        <li>Technical Knowledge</li>
                        <li>Current Affairs</li>
                        <li>Company Specific Knowledge</li>
                    </ul>
                `,
                examples: `
                    <h4>PSU Sample Questions</h4>

                    <h5>1. Technical Interview</h5>
                    <div class="example-box">
                        <p>Sample technical questions...</p>
                    </div>

                    <h5>2. HR Interview</h5>
                    <div class="example-box">
                        <p>Sample HR questions...</p>
                    </div>
                `,
                practice: `
                    <h4>PSU Practice Questions</h4>

                    <div class="practice-exercise">
                        <h5>1. Technical Interview Practice</h5>
                        <div class="question">
                            <p>Q1: Explain the working principle of a transformer</p>
                            <p>Answer: A transformer works on the principle of electromagnetic induction, where changing magnetic flux in one coil induces voltage in another coil</p>
                        </div>

                        <h5>2. HR Interview Practice</h5>
                        <div class="question">
                            <p>Q1: Why do you want to join our PSU?</p>
                            <p>Sample Answer: Focus on stability, contribution to nation-building, and professional growth opportunities</p>
                        </div>

                        <h5>3. Company Knowledge</h5>
                        <div class="question">
                            <p>Q1: What are the major projects of NTPC?</p>
                            <p>Answer: Include current power projects, renewable energy initiatives, and expansion plans</p>
                        </div>

                        <div class="tips">
                            <h5>Interview Tips:</h5>
                            <ul>
                                <li>Research the company thoroughly</li>
                                <li>Prepare common technical questions</li>
                                <li>Practice mock interviews</li>
                                <li>Stay updated with industry news</li>
                            </ul>
                        </div>
                    </div>
                `
            }
        };

        this.initializeEventListeners();
        this.initializeTabs();
    }

    initializeEventListeners() {
        document.querySelectorAll('.start-quiz-btn').forEach(btn => {
            btn.addEventListener('click', () => this.startQuiz(btn.dataset.module));
        });

        document.getElementById('prevBtn').addEventListener('click', () => this.navigateQuestion(-1));
        document.getElementById('nextBtn').addEventListener('click', () => this.navigateQuestion(1));
        document.getElementById('askAIBtn').addEventListener('click', () => this.askAI());
        document.getElementById('resetBtn').addEventListener('click', () => this.resetQuiz());
        document.getElementById('viewResultsBtn').addEventListener('click', () => this.showResults());
    }

    initializeTabs() {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => this.switchTab(btn.dataset.tab));
        });
    }

    switchTab(tabId) {
        // Update active button
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabId);
        });

        // Show selected content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.style.display = content.id === tabId ? 'block' : 'none';
        });

        // Load content if not already loaded
        this.loadTabContent(tabId);
    }

    loadTabContent(tabId) {
        if (!this.currentModule) return;
        
        const contentDiv = document.querySelector(`#${tabId} > div`);
        contentDiv.innerHTML = this.learningContent[this.currentModule][tabId];
    }

    startQuiz(module) {
        this.currentModule = module;
        this.currentQuestionIndex = 0;
        this.userAnswers.clear();

        document.querySelector('.language-modules').style.display = 'none';
        document.querySelector('.quiz-section').style.display = 'block';

        document.getElementById('quizTitle').textContent = 
            `${module.charAt(0).toUpperCase() + module.slice(1)} Quiz`;

        this.loadQuestion();
        this.loadTabContent('theory');
        document.querySelector('.learning-content').style.display = 'block';
    }

    loadQuestion() {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        document.getElementById('questionText').textContent = question.question;

        const optionsContainer = document.querySelector('.options-container');
        optionsContainer.innerHTML = '';

        question.options.forEach((option, index) => {
            const optionElement = document.createElement('div');
            optionElement.className = 'option';
            optionElement.textContent = option;
            
            if (this.userAnswers.has(this.currentQuestionIndex)) {
                optionElement.classList.add('disabled');
                const userAnswer = this.userAnswers.get(this.currentQuestionIndex);
                const correctAnswer = question.correct;
                
                if (index === correctAnswer) {
                    optionElement.classList.add('correct');
                } else if (index === userAnswer && userAnswer !== correctAnswer) {
                    optionElement.classList.add('incorrect');
                }
            }

            optionElement.addEventListener('click', () => this.selectOption(index));
            optionsContainer.appendChild(optionElement);
        });

        this.updateProgress();

        // Hide feedback when loading new question
        document.querySelector('.result-feedback').style.display = 'none';
    }

    selectOption(index) {
        // If already answered, don't allow new selection
        if (this.userAnswers.has(this.currentQuestionIndex)) {
            return;
        }

        this.userAnswers.set(this.currentQuestionIndex, index);
        
        // Get the correct answer
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const correctIndex = question.correct;

        // Update options appearance
        document.querySelectorAll('.option').forEach((option, i) => {
            option.classList.add('disabled');
            if (i === correctIndex) {
                option.classList.add('correct');
            } else if (i === index && index !== correctIndex) {
                option.classList.add('incorrect');
            }
        });

        // Show immediate feedback
        this.showFeedback(index);
        
        // Show view results button if at least one question is answered
        this.hasAnswered = true;
        document.getElementById('viewResultsBtn').style.display = 'flex';
    }

    navigateQuestion(direction) {
        const newIndex = this.currentQuestionIndex + direction;
        if (newIndex >= 0 && newIndex < this.questions[this.currentModule].length) {
            this.currentQuestionIndex = newIndex;
            this.loadQuestion();
        }
    }

    updateProgress() {
        const total = this.questions[this.currentModule].length;
        document.getElementById('questionCounter').textContent = 
            `Question ${this.currentQuestionIndex + 1}/${total}`;

        const progress = ((this.currentQuestionIndex + 1) / total) * 100;
        document.querySelector('.progress').style.width = `${progress}%`;
    }

    askAI() {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const chatInput = document.querySelector('#userInput');
        const sendButton = document.querySelector('#sendBtn');
        const chatToggle = document.querySelector('#chatToggle');

        if (chatInput && sendButton && chatToggle) {
            const prompt = `Please explain this question and its answer:
                Question: ${question.question}
                Correct Answer: ${question.options[question.correct]}
                Explanation: ${question.explanation}`;

            chatInput.value = prompt;
            
            chatInput.dispatchEvent(new Event('input', { bubbles: true }));
            
            // Open chat if not already open
            if (!document.querySelector('.chat-widget.active')) {
                chatToggle.click();
            }

            // Trigger send
            sendButton.click();
        }
    }

    resetQuiz() {
        // Reset all state
        this.currentModule = null;
        this.currentQuestionIndex = 0;
        this.userAnswers.clear();

        // Show tutorials, hide quiz
        document.querySelector('.language-modules').style.display = 'grid';
        document.querySelector('.quiz-section').style.display = 'none';

        // Reset progress bar
        document.querySelector('.progress').style.width = '0%';

        // Optional: Scroll to top of tutorials
        document.querySelector('.tutorial-header').scrollIntoView({ 
            behavior: 'smooth',
            block: 'start'
        });
    }

    showFeedback(selectedIndex) {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const feedbackDiv = document.querySelector('.result-feedback');
        const feedbackText = feedbackDiv.querySelector('.feedback-text');
        const explanationText = feedbackDiv.querySelector('.explanation-text');
        
        const isCorrect = selectedIndex === question.correct;
        
        feedbackDiv.style.display = 'block';
        feedbackDiv.className = `result-feedback ${isCorrect ? 'correct' : 'incorrect'}`;
        
        feedbackText.textContent = isCorrect ? 
            'Correct Answer!' : 
            `Incorrect. The correct answer is: ${question.options[question.correct]}`;
        
        explanationText.textContent = question.explanation;
    }

    showResults() {
        const total = this.questions[this.currentModule].length;
        let correct = 0;
        
        this.userAnswers.forEach((answer, questionIndex) => {
            if (answer === this.questions[this.currentModule][questionIndex].correct) {
                correct++;
            }
        });

        const percentage = (correct / total) * 100;
        
        // Create results modal
        const modal = document.createElement('div');
        modal.className = 'results-modal';
        modal.innerHTML = `
            <div class="results-content">
                <h3>Quiz Results</h3>
                <div class="score-circle">
                    <span class="score-percentage">${percentage.toFixed(1)}%</span>
                    <span class="score-text">${correct} out of ${total}</span>
                </div>
                <button class="close-results">Close</button>
            </div>
        `;

        document.body.appendChild(modal);
        
        // Add close functionality
        modal.querySelector('.close-results').addEventListener('click', () => {
            modal.remove();
        });
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new LanguageSkillsQuiz();
});