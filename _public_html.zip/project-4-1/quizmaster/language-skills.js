// language-skills.js
class LanguageSkillsQuiz {
    constructor() {
        this.questions = {
            grammar: [
                {
                    question: "Which of the following is a proper noun?",
                    options: ["Paris", "city", "mountain", "river"],
                    correct: 0,
                    explanation: "Paris is a proper noun as it names a specific city."
                },
                {
                    question: "Identify the correct verb tense: 'She ___ to the store yesterday.'",
                    options: ["go", "goes", "went", "gone"],
                    correct: 2,
                    explanation: "The past tense 'went' is correct for an action completed in the past."
                },
                {
                    question: "Choose the correct article: '___ university I attend is excellent.'",
                    options: ["A", "An", "The", "No article needed"],
                    correct: 2,
                    explanation: "We use 'the' when referring to a specific university that both speaker and listener know about."
                },
                {
                    question: "Which sentence uses the correct form of there/their/they're?",
                    options: [
                        "Their going to the party.",
                        "They're books are on the table.",
                        "There car is red.",
                        "They're planning to visit tomorrow."
                    ],
                    correct: 3,
                    explanation: "They're is the contraction of 'they are', which is correct in this context."
                },
                {
                    question: "Identify the passive voice sentence:",
                    options: [
                        "John wrote the letter.",
                        "The letter was written by John.",
                        "The letter is beautiful.",
                        "John is writing a letter."
                    ],
                    correct: 1,
                    explanation: "In passive voice, the subject receives the action. 'Was written' indicates passive voice."
                },
                {
                    question: "Which sentence contains a preposition?",
                    options: [
                        "She laughed loudly.",
                        "The cat sleeps.",
                        "He ran through the park.",
                        "They sing beautifully."
                    ],
                    correct: 2,
                    explanation: "'Through' is a preposition showing the relationship between 'ran' and 'park'."
                },
                {
                    question: "Select the sentence with correct subject-verb agreement:",
                    options: [
                        "The group of students were late.",
                        "The group of students was late.",
                        "The students was late.",
                        "The students is late."
                    ],
                    correct: 1,
                    explanation: "'Group' is a singular collective noun, so it takes the singular verb 'was'."
                },
                {
                    question: "Which word is an adverb in this sentence: 'She quickly finished her homework.'?",
                    options: ["She", "quickly", "finished", "homework"],
                    correct: 1,
                    explanation: "'Quickly' modifies the verb 'finished', making it an adverb."
                },
                {
                    question: "Choose the correct comparative form:",
                    options: [
                        "John is more taller than Mike.",
                        "John is tallest than Mike.",
                        "John is taller than Mike.",
                        "John is the taller than Mike."
                    ],
                    correct: 2,
                    explanation: "For most one-syllable adjectives, add '-er' to form the comparative."
                },
                {
                    question: "Which sentence is punctuated correctly?",
                    options: [
                        "Mary said hello",
                        "Mary said, hello.",
                        "Mary said: \"Hello.\"",
                        "Mary said \"Hello\""
                    ],
                    correct: 2,
                    explanation: "Direct quotes need quotation marks and proper punctuation."
                }
            ],
            vocabulary: [
                {
                    question: "What is the antonym of 'benevolent'?",
                    options: ["malevolent", "generous", "kind", "charitable"],
                    correct: 0,
                    explanation: "Malevolent means evil or harmful, which is the opposite of benevolent (kind)."
                },
                {
                    question: "Choose the correct synonym for 'arduous':",
                    options: ["easy", "difficult", "quick", "simple"],
                    correct: 1,
                    explanation: "Arduous means difficult or requiring great effort."
                },
                {
                    question: "What does 'ephemeral' mean?",
                    options: ["lasting", "permanent", "temporary", "solid"],
                    correct: 2,
                    explanation: "Ephemeral means lasting for a very short time, temporary."
                },
                {
                    question: "Select the word that means 'to make amends':",
                    options: ["atone", "attract", "attend", "attain"],
                    correct: 0,
                    explanation: "To atone means to make amends or reparation for a wrong or injury."
                },
                {
                    question: "Which word means 'excessive pride or self-confidence'?",
                    options: ["humility", "hubris", "humor", "harmony"],
                    correct: 1,
                    explanation: "Hubris refers to excessive pride or self-confidence, often leading to downfall."
                },
                {
                    question: "What is the meaning of 'ubiquitous'?",
                    options: ["rare", "present everywhere", "unique", "hidden"],
                    correct: 1,
                    explanation: "Ubiquitous means appearing everywhere or being very common."
                },
                {
                    question: "Choose the synonym for 'verbose':",
                    options: ["concise", "wordy", "brief", "clear"],
                    correct: 1,
                    explanation: "Verbose means using more words than necessary; wordy."
                },
                {
                    question: "What does 'pragmatic' mean?",
                    options: ["emotional", "theoretical", "practical", "artistic"],
                    correct: 2,
                    explanation: "Pragmatic means dealing with things sensibly and realistically."
                },
                {
                    question: "Select the antonym of 'frugal':",
                    options: ["wasteful", "careful", "thrifty", "economical"],
                    correct: 0,
                    explanation: "Frugal means economical, so wasteful is its opposite."
                },
                {
                    question: "What is the meaning of 'ambivalent'?",
                    options: ["decisive", "having mixed feelings", "indifferent", "enthusiastic"],
                    correct: 1,
                    explanation: "Ambivalent means having mixed or contradictory feelings about something."
                }
            ],
            writing: [
                {
                    question: "Which is the most effective topic sentence for a paragraph about climate change?",
                    options: [
                        "Climate change is bad.",
                        "Global warming affects many things.",
                        "Climate change poses significant threats to Earth's ecosystems.",
                        "The weather is different now."
                    ],
                    correct: 2,
                    explanation: "A strong topic sentence should be specific and clearly state the main idea."
                },
                {
                    question: "What is the best way to organize a persuasive essay?",
                    options: [
                        "Introduction, evidence, conclusion",
                        "Introduction, counterarguments, supporting arguments, conclusion",
                        "Evidence, introduction, conclusion",
                        "Supporting arguments, introduction, conclusion"
                    ],
                    correct: 1,
                    explanation: "A well-structured persuasive essay should address counterarguments to strengthen its position."
                },
                {
                    question: "Which transition word best shows contrast?",
                    options: ["Furthermore", "However", "Similarly", "Therefore"],
                    correct: 1,
                    explanation: "'However' is used to show contrast between ideas."
                },
                {
                    question: "What is the purpose of a thesis statement?",
                    options: [
                        "To provide background information",
                        "To state the main argument of the essay",
                        "To conclude the essay",
                        "To list sources"
                    ],
                    correct: 1,
                    explanation: "A thesis statement presents the main argument or point of the essay."
                },
                {
                    question: "Which is NOT a characteristic of academic writing?",
                    options: [
                        "Formal tone",
                        "Personal anecdotes",
                        "Evidence-based arguments",
                        "Clear structure"
                    ],
                    correct: 1,
                    explanation: "Academic writing typically avoids personal anecdotes and maintains objectivity."
                },
                {
                    question: "What is the best way to support an argument in writing?",
                    options: [
                        "Personal opinions",
                        "Emotional appeals",
                        "Factual evidence and research",
                        "Rhetorical questions"
                    ],
                    correct: 2,
                    explanation: "Strong arguments are supported by credible evidence and research."
                },
                {
                    question: "Which is a characteristic of effective conclusion paragraphs?",
                    options: [
                        "Introducing new arguments",
                        "Summarizing main points",
                        "Adding citations",
                        "Including questions"
                    ],
                    correct: 1,
                    explanation: "Conclusions should summarize main points without introducing new arguments."
                },
                {
                    question: "What is the purpose of a topic outline?",
                    options: [
                        "To list references",
                        "To organize ideas before writing",
                        "To check grammar",
                        "To format citations"
                    ],
                    correct: 1,
                    explanation: "An outline helps organize thoughts and structure before writing."
                },
                {
                    question: "Which revision strategy is most effective?",
                    options: [
                        "Immediately submitting after writing",
                        "Only checking spelling",
                        "Reading aloud and getting feedback",
                        "Focusing only on grammar"
                    ],
                    correct: 2,
                    explanation: "Reading aloud and getting feedback helps identify various issues in writing."
                },
                {
                    question: "What is the purpose of a bibliography?",
                    options: [
                        "To make the paper longer",
                        "To list all sources used",
                        "To summarize the paper",
                        "To provide definitions"
                    ],
                    correct: 1,
                    explanation: "A bibliography documents all sources used in research and writing."
                }
            ],
            listening: [
                {
                    question: "What is the main purpose of active listening?",
                    options: [
                        "To wait for your turn to speak",
                        "To understand and engage with the speaker's message",
                        "To think about other things",
                        "To look at the speaker"
                    ],
                    correct: 1,
                    explanation: "Active listening involves fully engaging with and understanding the speaker's message."
                },
                {
                    question: "Which is NOT a good listening practice?",
                    options: [
                        "Maintaining eye contact",
                        "Nodding occasionally",
                        "Interrupting to share your opinion",
                        "Taking brief notes"
                    ],
                    correct: 2,
                    explanation: "Interrupting shows poor listening skills and disrespect for the speaker."
                },
                {
                    question: "What is the best way to confirm understanding while listening?",
                    options: [
                        "Staying silent",
                        "Paraphrasing what was said",
                        "Changing the subject",
                        "Looking at your phone"
                    ],
                    correct: 1,
                    explanation: "Paraphrasing demonstrates active listening and helps confirm understanding."
                },
                {
                    question: "Which nonverbal cue shows active listening?",
                    options: [
                        "Looking at your phone",
                        "Crossing arms",
                        "Nodding and maintaining eye contact",
                        "Fidgeting"
                    ],
                    correct: 2,
                    explanation: "Nodding and eye contact show engagement and attention."
                },
                {
                    question: "What is the purpose of taking notes while listening?",
                    options: [
                        "To look busy",
                        "To record key points for later reference",
                        "To avoid eye contact",
                        "To distract yourself"
                    ],
                    correct: 1,
                    explanation: "Note-taking helps remember important information and shows engagement."
                },
                {
                    question: "Which is an effective listening strategy in a group discussion?",
                    options: [
                        "Dominating the conversation",
                        "Listening only to respond",
                        "Building on others' ideas",
                        "Ignoring quiet participants"
                    ],
                    correct: 2,
                    explanation: "Building on others' ideas shows active listening and engagement."
                },
                {
                    question: "What should you do if you don't understand something?",
                    options: [
                        "Pretend to understand",
                        "Ask for clarification",
                        "Change the subject",
                        "Ignore it"
                    ],
                    correct: 1,
                    explanation: "Asking for clarification helps ensure accurate understanding."
                },
                {
                    question: "Which is a barrier to effective listening?",
                    options: [
                        "Making eye contact",
                        "Environmental distractions",
                        "Taking notes",
                        "Asking questions"
                    ],
                    correct: 1,
                    explanation: "Environmental distractions can interfere with listening comprehension."
                },
                {
                    question: "What is the role of silence in active listening?",
                    options: [
                        "To show disinterest",
                        "To allow processing time",
                        "To avoid participation",
                        "To show disagreement"
                    ],
                    correct: 1,
                    explanation: "Silence gives time to process information and formulate thoughtful responses."
                },
                {
                    question: "Which listening style is most effective for learning?",
                    options: [
                        "Passive listening",
                        "Selective listening",
                        "Critical listening",
                        "Pretend listening"
                    ],
                    correct: 2,
                    explanation: "Critical listening involves analyzing and evaluating information while listening."
                }
            ],
            speaking: [
                {
                    question: "What is the most important aspect of public speaking?",
                    options: [
                        "Speaking quickly",
                        "Using complex vocabulary",
                        "Clear and organized delivery",
                        "Memorizing every word"
                    ],
                    correct: 2,
                    explanation: "Clear and organized delivery ensures the audience can follow and understand the message."
                },
                {
                    question: "Which is an effective way to handle speaking anxiety?",
                    options: [
                        "Speaking very quickly",
                        "Avoiding eye contact",
                        "Deep breathing and preparation",
                        "Reading directly from notes"
                    ],
                    correct: 2,
                    explanation: "Deep breathing helps calm nerves, while preparation builds confidence."
                },
                {
                    question: "What is the best way to conclude a presentation?",
                    options: [
                        "Abruptly stopping",
                        "Summarizing key points and calling to action",
                        "Introducing new information",
                        "Apologizing for any mistakes"
                    ],
                    correct: 1,
                    explanation: "A strong conclusion reinforces main points and provides clear next steps."
                },
                {
                    question: "What is the purpose of vocal variety in speaking?",
                    options: [
                        "To confuse the audience",
                        "To maintain audience engagement",
                        "To speak faster",
                        "To show off"
                    ],
                    correct: 1,
                    explanation: "Varying tone, pace, and volume helps maintain audience interest."
                },
                {
                    question: "Which body language enhances speaking effectiveness?",
                    options: [
                        "Crossing arms",
                        "Natural gestures and movement",
                        "Standing completely still",
                        "Looking at the floor"
                    ],
                    correct: 1,
                    explanation: "Natural gestures and movement enhance message delivery and engagement."
                },
                {
                    question: "What is the best way to address audience questions?",
                    options: [
                        "Ignoring them",
                        "Answering briefly and clearly",
                        "Changing the subject",
                        "Becoming defensive"
                    ],
                    correct: 1,
                    explanation: "Clear, concise answers show respect for audience engagement."
                },
                {
                    question: "How should you adapt your speaking style to your audience?",
                    options: [
                        "Use the same style always",
                        "Consider audience background and needs",
                        "Ignore the audience",
                        "Speak as technically as possible"
                    ],
                    correct: 1,
                    explanation: "Effective speakers adapt their style to their audience's needs and understanding."
                },
                {
                    question: "What is the role of pausing in public speaking?",
                    options: [
                        "To show uncertainty",
                        "To create emphasis and allow processing",
                        "To waste time",
                        "To check notes"
                    ],
                    correct: 1,
                    explanation: "Strategic pauses help emphasize points and give audiences time to process information."
                },
                {
                    question: "Which is most important in impromptu speaking?",
                    options: [
                        "Speaking quickly",
                        "Using complex words",
                        "Organizing thoughts quickly",
                        "Memorizing content"
                    ],
                    correct: 2,
                    explanation: "Quick organization of thoughts helps deliver clear, coherent impromptu speeches."
                },
                {
                    question: "What is the best way to handle speaking mistakes?",
                    options: [
                        "Stop speaking",
                        "Apologize repeatedly",
                        "Continue smoothly",
                        "Leave the stage"
                    ],
                    correct: 2,
                    explanation: "Professional speakers acknowledge and move past mistakes smoothly."
                }
            ]
        };

        this.currentModule = null;
        this.currentQuestionIndex = 0;
        this.userAnswers = new Map();
        this.hasAnswered = false;

        this.learningContent = {
            grammar: {
                theory: `
                    <h4>Grammar Fundamentals</h4>
                    <p>Grammar is the foundation of effective communication. Understanding proper grammar helps you express ideas clearly and professionally. Here are the key components:</p>
                    
                    <h5>1. Parts of Speech</h5>
                    <ul>
                        <li><strong>Nouns:</strong> People, places, things, ideas (e.g., teacher, London, happiness)
                            <ul>
                                <li>Common nouns: General items (book, city)</li>
                                <li>Proper nouns: Specific names (Shakespeare, Paris)</li>
                                <li>Abstract nouns: Ideas/concepts (love, freedom)</li>
                                <li>Collective nouns: Groups (team, family)</li>
                            </ul>
                        </li>
                        <li><strong>Verbs:</strong> Actions or states of being
                            <ul>
                                <li>Action verbs: Physical actions (run, jump, eat)</li>
                                <li>Linking verbs: Connect subject to description (is, seem, become)</li>
                                <li>Helping verbs: Support main verbs (has, will, can)</li>
                            </ul>
                        </li>
                        <li><strong>Adjectives:</strong> Describe nouns
                            <ul>
                                <li>Descriptive: Size, color, shape (tall, blue, round)</li>
                                <li>Possessive: Show ownership (my, his, their)</li>
                                <li>Demonstrative: Point to specific items (this, that)</li>
                            </ul>
                        </li>
                        <li><strong>Adverbs:</strong> Modify verbs, adjectives, or other adverbs
                            <ul>
                                <li>Manner: How something happens (quickly, carefully)</li>
                                <li>Time: When something happens (now, soon, later)</li>
                                <li>Place: Where something happens (here, there, everywhere)</li>
                            </ul>
                        </li>
                        <li><strong>Pronouns:</strong> Replace nouns
                            <ul>
                                <li>Personal: I, you, he, she, it, we, they</li>
                                <li>Possessive: mine, yours, his, hers</li>
                                <li>Relative: who, which, that</li>
                            </ul>
                        </li>
                        <li><strong>Prepositions:</strong> Show relationships
                            <ul>
                                <li>Location: in, on, at, under</li>
                                <li>Time: before, after, during</li>
                                <li>Direction: to, from, across</li>
                            </ul>
                        </li>
                    </ul>

                    <h5>2. Sentence Structure</h5>
                    <ul>
                        <li><strong>Subject-Verb Agreement:</strong> Subjects and verbs must agree in number</li>
                        <li><strong>Tenses:</strong> Past, present, future and their perfect forms</li>
                        <li><strong>Clauses:</strong> Independent and dependent clauses</li>
                        <li><strong>Punctuation:</strong> Proper use of periods, commas, semicolons</li>
                    </ul>
                `,
                examples: `
                    <h4>Grammar Examples</h4>
                    
                    <div class="example-item">
                        <h5>Sentence Structure Examples</h5>
                        <p><strong>Simple Sentence:</strong> The cat sleeps.</p>
                        <p><strong>Compound Sentence:</strong> The cat sleeps, and the dog plays.</p>
                        <p><strong>Complex Sentence:</strong> While the cat sleeps, the dog plays.</p>
                        <p><strong>Compound-Complex Sentence:</strong> While the cat sleeps, the dog plays, and the bird sings.</p>

                        <h5>Subject-Verb Agreement</h5>
                        <p><strong>Correct:</strong> The team is winning. (singular collective noun)</p>
                        <p><strong>Correct:</strong> The players are celebrating. (plural noun)</p>
                        
                        <h5>Tense Usage</h5>
                        <p><strong>Present:</strong> She writes a letter.</p>
                        <p><strong>Past:</strong> She wrote a letter.</p>
                        <p><strong>Future:</strong> She will write a letter.</p>
                        <p><strong>Present Perfect:</strong> She has written a letter.</p>
                    </div>
                `,
                practice: `
                    <h4>Practice Exercises</h4>
                    
                    <div class="practice-item">
                        <h5>Exercise 1: Parts of Speech</h5>
                        <p>Identify the parts of speech in this sentence:</p>
                        <p class="practice-sentence">"The energetic puppy playfully chased the red ball across the green yard."</p>
                        <ul>
                            <li>The - Article</li>
                            <li>energetic - Adjective</li>
                            <li>puppy - Noun</li>
                            <li>playfully - Adverb</li>
                            <li>chased - Verb</li>
                            <li>red - Adjective</li>
                            <li>ball - Noun</li>
                            <li>across - Preposition</li>
                            <li>green - Adjective</li>
                            <li>yard - Noun</li>
                        </ul>

                        <h5>Exercise 2: Sentence Construction</h5>
                        <p>Create sentences using these patterns:</p>
                        <ol>
                            <li>Subject + Verb</li>
                            <li>Subject + Verb + Object</li>
                            <li>Subject + Verb + Object + Prepositional Phrase</li>
                        </ol>
                    </div>
                `
            },
            vocabulary: {
                theory: `
                    <h4>Vocabulary Building Fundamentals</h4>
                    
                    <h5>1. Word Formation</h5>
                    <ul>
                        <li><strong>Root Words:</strong> Basic words that form the base
                            <ul>
                                <li>Latin roots: "dict" (speak), "scrib" (write)</li>
                                <li>Greek roots: "bio" (life), "tele" (far)</li>
                            </ul>
                        </li>
                        <li><strong>Prefixes:</strong> Added to beginning
                            <ul>
                                <li>un- (not): unhappy, unclear</li>
                                <li>pre- (before): preview, predict</li>
                                <li>dis- (not, opposite): disagree, disappear</li>
                                <li>re- (again): rewrite, rebuild</li>
                            </ul>
                        </li>
                        <li><strong>Suffixes:</strong> Added to end
                            <ul>
                                <li>-tion (act/state): creation, action</li>
                                <li>-ment (state/quality): agreement, development</li>
                                <li>-ful (full of): helpful, beautiful</li>
                                <li>-less (without): helpless, careless</li>
                            </ul>
                        </li>
                        <li><strong>Compound Words:</strong> Two words combined
                            <ul>
                                <li>Closed: sunlight, classroom</li>
                                <li>Hyphenated: mother-in-law</li>
                                <li>Open: high school</li>
                            </ul>
                        </li>
                    </ul>

                    <h5>2. Word Relationships</h5>
                    <ul>
                        <li><strong>Synonyms:</strong> Words with similar meanings</li>
                        <li><strong>Antonyms:</strong> Words with opposite meanings</li>
                        <li><strong>Homonyms:</strong> Words that sound alike</li>
                    </ul>
                `,
                examples: `
                    <h4>Vocabulary Examples</h4>
                    
                    <div class="example-item">
                        <h5>Word Formation Examples</h5>
                        <p><strong>Root + Suffix:</strong> teach + er = teacher</p>
                        <p><strong>Prefix + Root:</strong> un + happy = unhappy</p>
                        <p><strong>Compound Words:</strong> sun + light = sunlight</p>

                        <h5>Word Family Examples</h5>
                        <p><strong>Base: Act</strong></p>
                        <ul>
                            <li>action (noun)</li>
                            <li>active (adjective)</li>
                            <li>actively (adverb)</li>
                            <li>activate (verb)</li>
                        </ul>
                    </div>
                `,
                practice: `
                    <h4>Practice Exercises</h4>
                    
                    <div class="practice-item">
                        <h5>Exercise 1: Word Formation</h5>
                        <p>Create new words using prefixes and suffixes:</p>
                        <p>Base word: "care"</p>
                        <ul>
                            <li>Add prefixes: un-, pre-</li>
                            <li>Add suffixes: -ful, -less</li>
                            <li>Combine: un + care + ful</li>
                        </ul>

                        <h5>Exercise 2: Word Relationships</h5>
                        <p>Find synonyms and antonyms for:</p>
                        <ul>
                            <li>happy</li>
                            <li>big</li>
                            <li>fast</li>
                        </ul>
                    </div>
                `
            },
            writing: {
                theory: `
                    <h4>Writing Skills Fundamentals</h4>
                    
                    <h5>1. Essay Structure</h5>
                    <ul>
                        <li><strong>Introduction:</strong>
                            <ul>
                                <li>Hook: Grab reader's attention</li>
                                <li>Background: Context for topic</li>
                                <li>Thesis: Main argument/point</li>
                            </ul>
                        </li>
                        <li><strong>Body Paragraphs:</strong>
                            <ul>
                                <li>Topic sentence: Main idea of paragraph</li>
                                <li>Evidence: Support for ideas</li>
                                <li>Analysis: Explanation of evidence</li>
                                <li>Transitions: Connect paragraphs</li>
                            </ul>
                        </li>
                        <li><strong>Conclusion:</strong>
                            <ul>
                                <li>Restate thesis</li>
                                <li>Summarize main points</li>
                                <li>Call to action/Final thoughts</li>
                            </ul>
                        </li>
                    </ul>

                    <h5>2. Writing Process</h5>
                    <ul>
                        <li>Prewriting: Brainstorming, outlining</li>
                        <li>Drafting: First version</li>
                        <li>Revising: Content improvement</li>
                        <li>Editing: Grammar and mechanics</li>
                        <li>Publishing: Final version</li>
                    </ul>
                `,
                examples: `
                    <h4>Writing Examples</h4>
                    
                    <div class="example-item">
                        <h5>Strong Topic Sentences</h5>
                        <p><strong>Weak:</strong> Dogs are nice.</p>
                        <p><strong>Strong:</strong> Dogs provide invaluable emotional support and companionship to their owners.</p>

                        <h5>Effective Transitions</h5>
                        <p><strong>Addition:</strong> Furthermore, Moreover, Additionally</p>
                        <p><strong>Contrast:</strong> However, Nevertheless, On the other hand</p>
                        <p><strong>Example:</strong> For instance, Specifically, In particular</p>
                    </div>
                `,
                practice: `
                    <h4>Writing Practice</h4>
                    
                    <div class="practice-item">
                        <h5>Exercise: Topic Sentence Development</h5>
                        <p>Improve these weak topic sentences:</p>
                        <p>1. "Social media is popular."</p>
                        <p>2. "Technology changes things."</p>

                        <h5>Exercise: Paragraph Structure</h5>
                        <p>Write a paragraph including:</p>
                        <ul>
                            <li>Topic sentence</li>
                            <li>Supporting evidence</li>
                            <li>Analysis</li>
                            <li>Concluding sentence</li>
                        </ul>
                    </div>
                `
            },
            listening: {
                theory: `
                    <h4>Listening Skills Fundamentals</h4>
                    
                    <h5>1. Active Listening Components</h5>
                    <ul>
                        <li><strong>Focus:</strong>
                            <ul>
                                <li>Give full attention to speaker</li>
                                <li>Minimize distractions</li>
                                <li>Stay mentally engaged</li>
                            </ul>
                        </li>
                        <li><strong>Non-verbal cues:</strong>
                            <ul>
                                <li>Maintain appropriate eye contact</li>
                                <li>Use encouraging nodding</li>
                                <li>Show open body language</li>
                            </ul>
                        </li>
                        <li><strong>Feedback:</strong>
                            <ul>
                                <li>Ask clarifying questions</li>
                                <li>Provide appropriate responses</li>
                                <li>Show understanding through comments</li>
                            </ul>
                        </li>
                    </ul>

                    <h5>2. Listening Barriers</h5>
                    <ul>
                        <li>Environmental distractions</li>
                        <li>Personal biases</li>
                        <li>Emotional interference</li>
                        <li>Cultural differences</li>
                    </ul>
                `,
                examples: `
                    <h4>Listening Examples</h4>
                    
                    <div class="example-item">
                        <h5>Active Listening Techniques</h5>
                        <p><strong>Paraphrasing:</strong> "So what you're saying is..."</p>
                        <p><strong>Clarifying:</strong> "Could you explain more about..."</p>
                        <p><strong>Summarizing:</strong> "Let me make sure I understand..."</p>
                        <p><strong>Empathizing:</strong> "I can understand why you feel..."</p>

                        <h5>Non-verbal Communication</h5>
                        <ul>
                            <li>Facial expressions</li>
                            <li>Body posture</li>
                            <li>Gestures</li>
                            <li>Eye contact</li>
                        </ul>
                    </div>
                `,
                practice: `
                    <h4>Listening Practice</h4>
                    
                    <div class="practice-item">
                        <h5>Exercise: Active Listening</h5>
                        <p>Practice these responses:</p>
                        <p>1. Paraphrase a news article</p>
                        <p>2. Summarize a conversation</p>

                        <h5>Exercise: Identifying Main Ideas</h5>
                        <p>Listen to a short talk and:</p>
                        <ul>
                            <li>Identify key points</li>
                            <li>Note supporting details</li>
                            <li>Ask relevant questions</li>
                        </ul>
                    </div>
                `
            },
            speaking: {
                theory: `
                    <h4>Speaking Skills Fundamentals</h4>
                    
                    <h5>1. Public Speaking Essentials</h5>
                    <ul>
                        <li><strong>Voice:</strong>
                            <ul>
                                <li>Volume: Appropriate for space</li>
                                <li>Pace: Clear and measured</li>
                                <li>Tone: Engaging and confident</li>
                                <li>Pitch: Natural variation</li>
                            </ul>
                        </li>
                        <li><strong>Body Language:</strong>
                            <ul>
                                <li>Posture: Upright and confident</li>
                                <li>Gestures: Natural and purposeful</li>
                                <li>Eye contact: Engage audience</li>
                                <li>Movement: Controlled and meaningful</li>
                            </ul>
                        </li>
                        <li><strong>Organization:</strong>
                            <ul>
                                <li>Clear structure</li>
                                <li>Logical flow</li>
                                <li>Effective transitions</li>
                                <li>Time management</li>
                            </ul>
                        </li>
                    </ul>

                    <h5>2. Speech Preparation</h5>
                    <ul>
                        <li>Research thoroughly</li>
                        <li>Know your audience</li>
                        <li>Practice delivery</li>
                        <li>Prepare visual aids</li>
                    </ul>
                `,
                examples: `
                    <h4>Speaking Examples</h4>
                    
                    <div class="example-item">
                        <h5>Presentation Techniques</h5>
                        <p><strong>Opening:</strong> "Today I'll discuss three key aspects..."</p>
                        <p><strong>Transition:</strong> "Now that we've covered X, let's move to Y..."</p>
                        <p><strong>Emphasis:</strong> "The crucial point to remember is..."</p>
                        <p><strong>Closing:</strong> "In conclusion, we've seen how..."</p>

                        <h5>Handling Q&A</h5>
                        <ul>
                            <li>Listen carefully to questions</li>
                            <li>Repeat questions if needed</li>
                            <li>Answer concisely</li>
                            <li>Thank the questioner</li>
                        </ul>
                    </div>
                `,
                practice: `
                    <h4>Speaking Practice</h4>
                    
                    <div class="practice-item">
                        <h5>Exercise: Presentation Skills</h5>
                        <p>Practice these scenarios:</p>
                        <p>1. Introduce yourself in 1 minute</p>
                        <p>2. Explain a simple concept to a group</p>

                        <h5>Exercise: Voice Control</h5>
                        <ul>
                            <li>Practice varying volume</li>
                            <li>Work on pace control</li>
                            <li>Exercise vocal variety</li>
                            <li>Record and analyze delivery</li>
                        </ul>
                    </div>
                `
            }
        };

        this.initializeEventListeners();
        this.initializeTabs();
    }

    initializeEventListeners() {
        document.querySelectorAll('.start-quiz-btn').forEach(btn => {
            btn.addEventListener('click', () => this.startQuiz(btn.dataset.module));
        });

        document.getElementById('prevBtn').addEventListener('click', () => this.navigateQuestion(-1));
        document.getElementById('nextBtn').addEventListener('click', () => this.navigateQuestion(1));
        document.getElementById('askAIBtn').addEventListener('click', () => this.askAI());
        document.getElementById('resetBtn').addEventListener('click', () => this.resetQuiz());
        document.getElementById('viewResultsBtn').addEventListener('click', () => this.showResults());
    }

    initializeTabs() {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => this.switchTab(btn.dataset.tab));
        });
    }

    switchTab(tabId) {
        // Update active button
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabId);
        });

        // Show selected content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.style.display = content.id === tabId ? 'block' : 'none';
        });

        // Load content if not already loaded
        this.loadTabContent(tabId);
    }

    loadTabContent(tabId) {
        if (!this.currentModule) return;
        
        const contentDiv = document.querySelector(`#${tabId} > div`);
        contentDiv.innerHTML = this.learningContent[this.currentModule][tabId];
    }

    startQuiz(module) {
        this.currentModule = module;
        this.currentQuestionIndex = 0;
        this.userAnswers.clear();

        document.querySelector('.language-modules').style.display = 'none';
        document.querySelector('.quiz-section').style.display = 'block';

        document.getElementById('quizTitle').textContent = 
            `${module.charAt(0).toUpperCase() + module.slice(1)} Quiz`;

        this.loadQuestion();
        this.loadTabContent('theory');
        document.querySelector('.learning-content').style.display = 'block';
    }

    loadQuestion() {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        document.getElementById('questionText').textContent = question.question;

        const optionsContainer = document.querySelector('.options-container');
        optionsContainer.innerHTML = '';

        question.options.forEach((option, index) => {
            const optionElement = document.createElement('div');
            optionElement.className = 'option';
            optionElement.textContent = option;
            
            if (this.userAnswers.has(this.currentQuestionIndex)) {
                optionElement.classList.add('disabled');
                const userAnswer = this.userAnswers.get(this.currentQuestionIndex);
                const correctAnswer = question.correct;
                
                if (index === correctAnswer) {
                    optionElement.classList.add('correct');
                } else if (index === userAnswer && userAnswer !== correctAnswer) {
                    optionElement.classList.add('incorrect');
                }
            }

            optionElement.addEventListener('click', () => this.selectOption(index));
            optionsContainer.appendChild(optionElement);
        });

        this.updateProgress();

        // Hide feedback when loading new question
        document.querySelector('.result-feedback').style.display = 'none';
    }

    selectOption(index) {
        // If already answered, don't allow new selection
        if (this.userAnswers.has(this.currentQuestionIndex)) {
            return;
        }

        this.userAnswers.set(this.currentQuestionIndex, index);
        
        // Get the correct answer
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const correctIndex = question.correct;

        // Update options appearance
        document.querySelectorAll('.option').forEach((option, i) => {
            option.classList.add('disabled');
            if (i === correctIndex) {
                option.classList.add('correct');
            } else if (i === index && index !== correctIndex) {
                option.classList.add('incorrect');
            }
        });

        // Show immediate feedback
        this.showFeedback(index);
        
        // Show view results button if at least one question is answered
        this.hasAnswered = true;
        document.getElementById('viewResultsBtn').style.display = 'flex';
    }

    navigateQuestion(direction) {
        const newIndex = this.currentQuestionIndex + direction;
        if (newIndex >= 0 && newIndex < this.questions[this.currentModule].length) {
            this.currentQuestionIndex = newIndex;
            this.loadQuestion();
        }
    }

    updateProgress() {
        const total = this.questions[this.currentModule].length;
        document.getElementById('questionCounter').textContent = 
            `Question ${this.currentQuestionIndex + 1}/${total}`;

        const progress = ((this.currentQuestionIndex + 1) / total) * 100;
        document.querySelector('.progress').style.width = `${progress}%`;
    }

    askAI() {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const chatInput = document.querySelector('#userInput');
        const sendButton = document.querySelector('#sendBtn');
        const chatToggle = document.querySelector('#chatToggle');

        if (chatInput && sendButton && chatToggle) {
            const prompt = `Please explain this question and its answer:
                Question: ${question.question}
                Correct Answer: ${question.options[question.correct]}
                Explanation: ${question.explanation}`;

            chatInput.value = prompt;
            
            chatInput.dispatchEvent(new Event('input', { bubbles: true }));
            
            // Open chat if not already open
            if (!document.querySelector('.chat-widget.active')) {
                chatToggle.click();
            }

            // Trigger send
            sendButton.click();
        }
    }

    resetQuiz() {
        // Reset all state
        this.currentModule = null;
        this.currentQuestionIndex = 0;
        this.userAnswers.clear();

        // Show tutorials, hide quiz
        document.querySelector('.language-modules').style.display = 'grid';
        document.querySelector('.quiz-section').style.display = 'none';

        // Reset progress bar
        document.querySelector('.progress').style.width = '0%';

        // Optional: Scroll to top of tutorials
        document.querySelector('.tutorial-header').scrollIntoView({ 
            behavior: 'smooth',
            block: 'start'
        });
    }

    showFeedback(selectedIndex) {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const feedbackDiv = document.querySelector('.result-feedback');
        const feedbackText = feedbackDiv.querySelector('.feedback-text');
        const explanationText = feedbackDiv.querySelector('.explanation-text');
        
        const isCorrect = selectedIndex === question.correct;
        
        feedbackDiv.style.display = 'block';
        feedbackDiv.className = `result-feedback ${isCorrect ? 'correct' : 'incorrect'}`;
        
        feedbackText.textContent = isCorrect ? 
            'Correct Answer!' : 
            `Incorrect. The correct answer is: ${question.options[question.correct]}`;
        
        explanationText.textContent = question.explanation;
    }

    showResults() {
        const total = this.questions[this.currentModule].length;
        let correct = 0;
        
        this.userAnswers.forEach((answer, questionIndex) => {
            if (answer === this.questions[this.currentModule][questionIndex].correct) {
                correct++;
            }
        });

        const percentage = (correct / total) * 100;
        
        // Create results modal
        const modal = document.createElement('div');
        modal.className = 'results-modal';
        modal.innerHTML = `
            <div class="results-content">
                <h3>Quiz Results</h3>
                <div class="score-circle">
                    <span class="score-percentage">${percentage.toFixed(1)}%</span>
                    <span class="score-text">${correct} out of ${total}</span>
                </div>
                <button class="close-results">Close</button>
            </div>
        `;

        document.body.appendChild(modal);
        
        // Add close functionality
        modal.querySelector('.close-results').addEventListener('click', () => {
            modal.remove();
        });
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new LanguageSkillsQuiz();
});