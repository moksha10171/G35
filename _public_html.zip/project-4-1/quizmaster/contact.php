<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

session_start();
ini_set('log_errors', 1);
ini_set('error_log', '/home/u291518478/domains/bmreducation.com/public_html/logs/admin_control/education_sec.php');
error_reporting(E_ALL);
ini_set('display_errors', 0);
date_default_timezone_set('Asia/Kolkata');
session_regenerate_id(true);

require '../vendor1/autoload.php';
require_once 'config.php';

use PHPMailer\PHPMailer\PHPMailer;

class ContactHandler {
    private $conn;
    private $table = 'screenscape_contact_messages ';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function processContact($data) {
        try {
            // Save to database
            $query = "INSERT INTO " . $this->table . "
                    (name, email, subject, message)
                    VALUES (:name, :email, :subject, :message)";

            $stmt = $this->conn->prepare($query);
            
            $stmt->bindParam(':name', $data->name);
            $stmt->bindParam(':email', $data->email);
            $stmt->bindParam(':subject', $data->subject);
            $stmt->bindParam(':message', $data->message);

            if(!$stmt->execute()) {
                throw new Exception("Failed to save message");
            }

            // Send confirmation email
            if(!$this->sendConfirmationEmail($data)) {
                throw new Exception("Failed to send confirmation email");
            }

            return true;
        } catch(Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    }

    private function sendConfirmationEmail($data) {
        $mail = new PHPMailer(true);
    
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.hostinger.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'login@bmreducation.com';
            $mail->Password = 'Moksha@10171+10170';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Recipients
            $mail->setFrom('login@bmreducation.com', 'QuizMaster');
            $mail->addAddress($data->email);

            // HTML Content
            $htmlBody = '
            <!DOCTYPE html>
            <html>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                    <div style="background: #4a90e2; color: white; padding: 30px; text-align: center; border-radius: 5px 5px 0 0;">
                        <h1 style="margin: 0; font-size: 24px;">Thank You for Contacting QuizMaster</h1>
                    </div>
                    <div style="background: #ffffff; padding: 30px; border: 1px solid #e0e0e0; border-radius: 0 0 5px 5px;">
                        <p style="margin-bottom: 15px;">Dear ' . htmlspecialchars($data->name) . ',</p>
                        
                        <p style="margin-bottom: 15px;">Thank you for reaching out to us. We have received your message regarding "<strong>' . htmlspecialchars($data->subject) . '</strong>".</p>
                        
                        <p style="margin-bottom: 15px;">Our team will review your inquiry and get back to you as soon as possible. Usually, we respond within 24-48 business hours.</p>
                        
                        <p style="margin-bottom: 10px;">Here\'s a summary of your message:</p>
                        <ul style="margin-bottom: 20px; padding-left: 20px;">
                            <li style="margin-bottom: 5px;"><strong>Subject:</strong> ' . htmlspecialchars($data->subject) . '</li>
                            <li style="margin-bottom: 5px;"><strong>Message:</strong> ' . htmlspecialchars($data->message) . '</li>
                        </ul>
                        
                        <p style="margin-bottom: 10px;">In the meantime, you might find these resources helpful:</p>
                        <ul style="margin-bottom: 20px; padding-left: 20px;">
                            <li style="margin-bottom: 5px;"><a href="https://www.bmreducation.com/quizmaster/faq" style="color: #4a90e2; text-decoration: none;">Frequently Asked Questions</a></li>
                            <li style="margin-bottom: 5px;"><a href="https://www.bmreducation.com/quizmaster/tutorials" style="color: #4a90e2; text-decoration: none;">Learning Resources</a></li>
                            <li style="margin-bottom: 5px;"><a href="https://www.bmreducation.com/quizmaster/courses" style="color: #4a90e2; text-decoration: none;">Available Courses</a></li>
                        </ul>
                        
                        <div style="text-align: center; margin: 30px 0;">
                            <a href="https://www.bmreducation.com/quizmaster" style="display: inline-block; padding: 12px 24px; background: #4a90e2; color: white; text-decoration: none; border-radius: 5px;">Visit QuizMaster</a>
                        </div>
                        
                        <p style="margin-bottom: 20px;">Best Regards,<br>The QuizMaster Team</p>
                        
                        <div style="margin-top: 30px; text-align: center; border-top: 1px solid #eee; padding-top: 20px;">
                            <p style="margin-bottom: 10px;">Follow us on:</p>
                            <a href="#" style="color: #4a90e2; text-decoration: none; margin: 0 10px;">Facebook</a> |
                            <a href="#" style="color: #4a90e2; text-decoration: none; margin: 0 10px;">Twitter</a> |
                            <a href="#" style="color: #4a90e2; text-decoration: none; margin: 0 10px;">LinkedIn</a> |
                            <a href="#" style="color: #4a90e2; text-decoration: none; margin: 0 10px;">Instagram</a>
                        </div>
                    </div>
                   <div style="text-align: center; margin-top: 20px; color: #666; font-size: 12px;">
                <p style="margin-bottom: 5px;">This is an automated response. Please do not reply to this email.</p>
                <p style="margin-bottom: 5px;">&copy; ' . date('Y') . ' QuizMaster. All rights reserved.</p>
                <p style="margin-bottom: 5px;">Presidency University, Bangalore</p>
                <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #eee;">
                    <p style="margin-bottom: 5px; color: #888; font-size: 11px;">BMR EDUCATION V4 Mail Service</p>
                    <p style="margin-bottom: 5px; color: #888; font-size: 11px;">Customer ID: 70981280</p>
                </div>
            </div>
        </div>
    </body>
</html>';
            

            $mail->isHTML(true);
            $mail->Subject = 'Thank You for Contacting QuizMaster';
            $mail->Body = $htmlBody;
            $mail->AltBody = strip_tags(str_replace('<br>', "\n", $htmlBody));

            $mail->send();
            return true;
        } catch (Exception $e) {
            error_log("Email sending failed: " . $mail->ErrorInfo);
            return false;
        }
    }
}

// Handle the incoming request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    try {
        $data = json_decode(file_get_contents("php://input"));
        
        if (!$data || !$data->name || !$data->email || !$data->subject || !$data->message) {
            throw new Exception('Invalid input data');
        }

        $handler = new ContactHandler();
        $result = $handler->processContact($data);

        echo json_encode([
            'success' => $result,
            'message' => $result ? 'Message sent successfully' : 'Failed to send message'
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}
?>