<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('../assets/layout/header.php');
$footer = inancap('../assets/layout/footer.php');
$meta = inancap('../assets/layout/meta.php');
echo $meta;
$descript = 'Quizmaster - TalentSphere';
$title = 'TalentSphere';
echo generateMetaTags($title, $descript, '', '', 'Coding, Courses');
echo $header;
?>
 <link rel="stylesheet" href="quiz.css">
    <main class="quiz-setup-container">
        <!-- Progress Indicator -->
    
        <div class="quiz-setup-header">
            <h1>Customize Your Quiz</h1>
            <p>Select your preferences to start the quiz</p>
        </div>
        <div class="setup-progress">
            <div class="progress-step active">
                <i class="fas fa-folder"></i>
                <span>Select Category</span>
            </div>
            <div class="progress-step">
                <i class="fas fa-cog"></i>
                <span>Configure Quiz</span>
            </div>
            <div class="progress-step">
                <i class="fas fa-play"></i>
                <span>Start Quiz</span>
            </div>
        </div>

        <div class="quiz-setup-content">
            <div class="setup-grid">
                <!-- Category Selection -->
                <div class="setup-card">
                    <h2><i class="fas fa-folder"></i> Select Category</h2>
                    <div class="category-search">
                        <input type="text" id="categorySearch" placeholder="Search categories...">
                     
                    </div>
                    <div class="category-grid">
                        <!-- Categories will be dynamically inserted here -->
                    </div>
                </div>

                <!-- Settings Column -->
                <div class="settings-column">
                    <!-- Difficulty Selection -->
                    <div class="setup-card">
                        <h2><i class="fas fa-layer-group"></i> Difficulty</h2>
                        <div class="difficulty-options">
                            <button class="difficulty-btn" data-difficulty="easy">
                                <i class="fas fa-smile"></i>
                                <div class="difficulty-info">
                                    <span>Easy</span>
                                    <small>Recommended for beginners</small>
                                </div>
                            </button>
                            <button class="difficulty-btn active" data-difficulty="medium">
                                <i class="fas fa-meh"></i>
                                <div class="difficulty-info">
                                    <span>Medium</span>
                                    <small>For intermediate learners</small>
                                </div>
                            </button>
                            <button class="difficulty-btn" data-difficulty="hard">
                                <i class="fas fa-frown"></i>
                                <div class="difficulty-info">
                                    <span>Hard</span>
                                    <small>Challenge yourself</small>
                                </div>
                            </button>
                        </div>
                    </div>

                    <!-- Quiz Configuration -->
                    <div class="setup-card">
                        <h2><i class="fas fa-cog"></i> Settings</h2>
                        <div class="quiz-settings">
                            <div class="setting-item">
                                <label for="questionCount">Number of Questions</label>
                                <div class="setting-input">
                                    <input type="number" id="questionCount" min="5" max="50" value="10">
                                    <div class="input-controls">
                                        <button class="control-btn" data-action="increment">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                        <button class="control-btn" data-action="decrement">
                                            <i class="fas fa-minus"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="setting-item">
                                <label for="timePerQuestion">Time per Question (seconds)</label>
                                <div class="setting-input">
                                    <input type="number" id="timePerQuestion" min="30" max="300" value="60">
                                    <div class="input-controls">
                                        <button class="control-btn" data-action="increment">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                        <button class="control-btn" data-action="decrement">
                                            <i class="fas fa-minus"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="setup-footer">
                <button class="start-quiz-btn" disabled>
                    <i class="fas fa-play"></i>
                    Select a category to start
                </button>
            </div>
        </div>
    </main>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="main.js"></script>
    <script src="definition_index.js"></script>
    <script src="chat.js"></script>
    <script src="quiz-setup.js"></script>
    <script src="newsletter.js"></script>

<?php echo $footer;?>