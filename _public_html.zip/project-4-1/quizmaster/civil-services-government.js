// language-skills.js
class LanguageSkillsQuiz {
    constructor() {
        this.questions = {
            upsc: [
                {
                    question: "Which Article of the Indian Constitution deals with the UPSC?",
                    options: ["Article 315", "Article 320", "Article 324", "Article 330"],
                    correct: 0,
                    explanation: "Article 315 of the Constitution deals with Public Service Commissions for the Union and States."
                },
                {
                    question: "How many papers are there in UPSC Civil Services Preliminary Examination?",
                    options: ["2", "3", "4", "1"],
                    correct: 0,
                    explanation: "UPSC Prelims consists of 2 papers - General Studies Paper I and CSAT Paper II."
                },
                {
                    question: "What is the duration of the IAS training at LBSNAA Mussoorie?",
                    options: ["2 years", "1 year", "6 months", "3 years"],
                    correct: 0,
                    explanation: "The total training period at LBSNAA is approximately 2 years including foundation course."
                },
                {
                    question: "Which of these is not a part of UPSC Mains examination?",
                    options: ["Aptitude Test", "Essay", "General Studies", "Optional Subject"],
                    correct: 0,
                    explanation: "Aptitude Test (CSAT) is only part of Prelims, not Mains examination."
                },
                {
                    question: "What is the maximum age limit for General Category candidates in UPSC CSE?",
                    options: ["32 years", "35 years", "30 years", "37 years"],
                    correct: 0,
                    explanation: "The upper age limit for General Category candidates is 32 years."
                },
                {
                    question: "How many attempts are allowed for General Category candidates?",
                    options: ["6", "4", "9", "3"],
                    correct: 0,
                    explanation: "General Category candidates are allowed 6 attempts at UPSC CSE."
                },
                {
                    question: "Which language is compulsory in UPSC Mains examination?",
                    options: ["English/Hindi", "Sanskrit", "Regional Language", "Any Indian Language"],
                    correct: 0,
                    explanation: "Candidates must qualify in either English or Hindi language paper in Mains."
                },
                {
                    question: "What is the total marks weightage of UPSC Mains examination?",
                    options: ["1750", "2000", "1500", "1250"],
                    correct: 0,
                    explanation: "UPSC Mains examination carries total 1750 marks."
                },
                {
                    question: "Which phase of UPSC CSE carries maximum weightage?",
                    options: ["Mains Written Exam", "Interview", "Prelims", "Optional Papers"],
                    correct: 0,
                    explanation: "Mains written examination carries maximum weightage in final selection."
                },
                {
                    question: "What is the duration of UPSC interview?",
                    options: ["25-30 minutes", "45-60 minutes", "15-20 minutes", "1 hour"],
                    correct: 0,
                    explanation: "The UPSC personality test/interview typically lasts 25-30 minutes."
                }
            ],
            state: [
                {
                    question: "Which exam is known as PCS in Uttar Pradesh?",
                    options: ["UPPSC", "UPSC", "UPSSSC", "UPPCL"],
                    correct: 0,
                    explanation: "UPPSC (Uttar Pradesh Public Service Commission) conducts the PCS exam."
                },
                {
                    question: "How many stages are there in most State Civil Services exams?",
                    options: ["3", "2", "4", "5"],
                    correct: 0,
                    explanation: "Most State Civil Services have 3 stages - Prelims, Mains and Interview."
                },
                {
                    question: "Which state conducts BPSC?",
                    options: ["Bihar", "Bengal", "Bangalore", "Bombay"],
                    correct: 0,
                    explanation: "BPSC is conducted by Bihar Public Service Commission."
                },
                {
                    question: "What is the age limit relaxation for SC/ST in most state services?",
                    options: ["5 years", "3 years", "2 years", "4 years"],
                    correct: 0,
                    explanation: "Most states provide 5 years age relaxation to SC/ST candidates."
                },
                {
                    question: "Which language paper is mandatory in most state PCS exams?",
                    options: ["State Official Language", "Hindi", "English", "Sanskrit"],
                    correct: 0,
                    explanation: "Knowledge of state's official language is mandatory in state PCS exams."
                },
                {
                    question: "What is the typical duration of state civil services training?",
                    options: ["1 year", "2 years", "6 months", "3 years"],
                    correct: 0,
                    explanation: "State civil services training typically lasts about 1 year."
                },
                {
                    question: "Which exam pattern do most state PCS exams follow?",
                    options: ["UPSC Pattern", "Unique Pattern", "University Pattern", "Board Pattern"],
                    correct: 0,
                    explanation: "Most state PCS exams follow UPSC pattern with some modifications."
                },
                {
                    question: "What is the focus of state PCS syllabus?",
                    options: ["State Specific Topics", "National Topics", "International Affairs", "Technical Subjects"],
                    correct: 0,
                    explanation: "State PCS syllabus focuses heavily on state-specific topics and issues."
                },
                {
                    question: "Which state conducts MPPSC?",
                    options: ["Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya"],
                    correct: 0,
                    explanation: "MPPSC is conducted by Madhya Pradesh Public Service Commission."
                },
                {
                    question: "What is the selection ratio in most state PCS exams?",
                    options: ["1:100", "1:50", "1:200", "1:500"],
                    correct: 0,
                    explanation: "The selection ratio in most state PCS is approximately 1:100."
                }
            ],
            ssc: [
                {
                    question: "What is CGL in SSC?",
                    options: ["Combined Graduate Level", "Central Government Level", "Common Graduate Level", "Combined General Level"],
                    correct: 0,
                    explanation: "CGL stands for Combined Graduate Level examination."
                },
                {
                    question: "How many tiers are there in SSC CGL?",
                    options: ["4", "3", "2", "5"],
                    correct: 0,
                    explanation: "SSC CGL has 4 tiers of examination."
                },
                {
                    question: "Which post is NOT offered through SSC CGL?",
                    options: ["IAS Officer", "Tax Assistant", "Auditor", "Statistical Investigator"],
                    correct: 0,
                    explanation: "IAS Officer post is not recruited through SSC CGL."
                },
                {
                    question: "What is the minimum qualification for SSC CGL?",
                    options: ["Graduate", "12th Pass", "Post Graduate", "10th Pass"],
                    correct: 0,
                    explanation: "Graduation is the minimum qualification required for SSC CGL."
                },
                {
                    question: "Which tier of SSC CGL has descriptive paper?",
                    options: ["Tier 3", "Tier 1", "Tier 2", "Tier 4"],
                    correct: 0,
                    explanation: "Tier 3 of SSC CGL consists of descriptive paper."
                },
                {
                    question: "What is CHSL in SSC?",
                    options: ["Combined Higher Secondary Level", "Central High School Level", "Common Higher Secondary Level", "Combined High School Level"],
                    correct: 0,
                    explanation: "CHSL stands for Combined Higher Secondary Level examination."
                },
                {
                    question: "Which mode is used for SSC examinations?",
                    options: ["Computer Based", "Paper Based", "Hybrid", "Oral"],
                    correct: 0,
                    explanation: "SSC conducts Computer Based Tests (CBT)."
                },
                {
                    question: "What is the age limit for SSC CGL (General)?",
                    options: ["18-32 years", "20-30 years", "21-35 years", "18-27 years"],
                    correct: 0,
                    explanation: "The age limit for General category in SSC CGL is 18-32 years."
                },
                {
                    question: "Which section is common in all SSC exams?",
                    options: ["General Intelligence", "Technical Knowledge", "Professional Knowledge", "Subject Knowledge"],
                    correct: 0,
                    explanation: "General Intelligence and Reasoning is common in all SSC exams."
                },
                {
                    question: "What is the negative marking in SSC exams?",
                    options: ["0.25", "0.5", "1", "0.33"],
                    correct: 0,
                    explanation: "SSC exams have 0.25 marks negative marking for each wrong answer."
                }
            ]
        };

        this.currentModule = null;
        this.currentQuestionIndex = 0;
        this.userAnswers = new Map();
        this.hasAnswered = false;

        this.learningContent = {
            upsc: {
                theory: `
                    <h4>UPSC Civil Services Preparation</h4>
                    
                    <h5>1. Exam Structure</h5>
                    <ul>
                        <li>Preliminary Examination (Objective)</li>
                        <li>Main Examination (Written)</li>
                        <li>Personality Test (Interview)</li>
                        <li>Total Duration: 10-12 months</li>
                    </ul>

                    <h5>2. Core Areas</h5>
                    <ul>
                        <li>Indian Polity & Constitution</li>
                        <li>Indian & World Geography</li>
                        <li>Indian Economy & Social Development</li>
                        <li>Environment & Ecology</li>
                        <li>Indian History & Culture</li>
                        <li>Current Affairs</li>
                    </ul>

                    <h5>3. Preparation Strategy</h5>
                    <ul>
                        <li>Systematic Study Plan</li>
                        <li>Regular Newspaper Reading</li>
                        <li>Answer Writing Practice</li>
                        <li>Mock Tests & Reviews</li>
                    </ul>
                `,
                examples: `
                    <h4>UPSC Sample Questions</h4>

                    <h5>1. Polity</h5>
                    <div class="example-box">
                        <p>Question: Which Article of the Constitution deals with the President's Rule in states?</p>
                        <p>Answer: Article 356 deals with provisions in case of failure of constitutional machinery in states.</p>
                    </div>

                    <h5>2. Economy</h5>
                    <div class="example-box">
                        <p>Question: What is Monetary Policy Committee?</p>
                        <p>Answer: MPC is a committee of RBI that decides key interest rates.</p>
                    </div>
                `,
                practice: `
                    <h4>UPSC Practice Questions</h4>

                    <div class="practice-exercise">
                        <h5>1. History & Culture</h5>
                        <div class="question">
                            <p>Practice questions on Ancient, Medieval, Modern India</p>
                            <p>Art, Architecture & Cultural aspects</p>
                        </div>

                        <h5>2. Geography</h5>
                        <div class="question">
                            <p>Physical Geography concepts</p>
                            <p>Indian Geography specifics</p>
                        </div>

                        <div class="tips">
                            <h5>Success Tips:</h5>
                            <ul>
                                <li>Make short notes</li>
                                <li>Regular revision</li>
                                <li>Focus on current affairs</li>
                                <li>Practice answer writing</li>
                            </ul>
                        </div>
                    </div>
                `
            },
            state: {
                theory: `
                    <h4>State Civil Services Preparation</h4>
                    
                    <h5>1. Exam Pattern</h5>
                    <ul>
                        <li>Preliminary Examination</li>
                        <li>Main Examination</li>
                        <li>Interview</li>
                        <li>State Specific Syllabus</li>
                    </ul>

                    <h5>2. Focus Areas</h5>
                    <ul>
                        <li>State History & Culture</li>
                        <li>State Geography & Resources</li>
                        <li>State Administration</li>
                        <li>Local Governance</li>
                        <li>State Economy</li>
                        <li>Current Affairs</li>
                    </ul>

                    <h5>3. Study Approach</h5>
                    <ul>
                        <li>State NCERT Books</li>
                        <li>Local Newspapers</li>
                        <li>State Yearbooks</li>
                        <li>Previous Year Papers</li>
                    </ul>
                `,
                examples: `
                    <h4>State PCS Sample Questions</h4>

                    <h5>1. State Administration</h5>
                    <div class="example-box">
                        <p>Structure of state government</p>
                        <p>Local bodies and their functions</p>
                    </div>

                    <h5>2. State Economy</h5>
                    <div class="example-box">
                        <p>Major industries and economic zones</p>
                        <p>State budget and planning</p>
                    </div>
                `,
                practice: `
                    <h4>State PCS Practice Questions</h4>

                    <div class="practice-exercise">
                        <h5>1. State Specific Topics</h5>
                        <div class="question">
                            <p>State history and cultural heritage</p>
                            <p>Geography and natural resources</p>
                        </div>

                        <h5>2. Administration</h5>
                        <div class="question">
                            <p>State government structure</p>
                            <p>Local governance</p>
                        </div>

                        <div class="tips">
                            <h5>Preparation Tips:</h5>
                            <ul>
                                <li>Focus on state specific topics</li>
                                <li>Regular newspaper reading</li>
                                <li>Previous year analysis</li>
                                <li>Mock tests practice</li>
                            </ul>
                        </div>
                    </div>
                `
            },
            ssc: {
                theory: `
                    <h4>SSC & Banking Preparation</h4>
                    
                    <h5>1. Common Exams</h5>
                    <ul>
                        <li>SSC CGL</li>
                        <li>SSC CHSL</li>
                        <li>Bank PO</li>
                        <li>Bank Clerk</li>
                    </ul>

                    <h5>2. Important Sections</h5>
                    <ul>
                        <li>Quantitative Aptitude</li>
                        <li>Reasoning Ability</li>
                        <li>English Language</li>
                        <li>General Awareness</li>
                        <li>Computer Knowledge</li>
                    </ul>

                    <h5>3. Preparation Tips</h5>
                    <ul>
                        <li>Topic-wise Practice</li>
                        <li>Speed & Accuracy</li>
                        <li>Regular Mock Tests</li>
                        <li>Current Affairs</li>
                    </ul>
                `,
                examples: `
                    <h4>SSC Sample Questions</h4>

                    <h5>1. Quantitative Aptitude</h5>
                    <div class="example-box">
                        <p>Number Series, Arithmetic, Data Interpretation</p>
                        <p>Practice shortcuts and techniques</p>
                    </div>

                    <h5>2. Reasoning</h5>
                    <div class="example-box">
                        <p>Logical puzzles and sequences</p>
                        <p>Verbal and non-verbal reasoning</p>
                    </div>
                `,
                practice: `
                    <h4>SSC Practice Questions</h4>

                    <div class="practice-exercise">
                        <h5>1. English Language</h5>
                        <div class="question">
                            <p>Grammar and vocabulary</p>
                            <p>Reading comprehension</p>
                        </div>

                        <h5>2. General Awareness</h5>
                        <div class="question">
                            <p>Static GK</p>
                            <p>Current affairs</p>
                        </div>

                        <div class="tips">
                            <h5>Exam Tips:</h5>
                            <ul>
                                <li>Time management</li>
                                <li>Accuracy focus</li>
                                <li>Regular practice</li>
                                <li>Section-wise strategy</li>
                            </ul>
                        </div>
                    </div>
                `
            }
        };

        this.initializeEventListeners();
        this.initializeTabs();
    }

    initializeEventListeners() {
        document.querySelectorAll('.start-quiz-btn').forEach(btn => {
            btn.addEventListener('click', () => this.startQuiz(btn.dataset.module));
        });

        document.getElementById('prevBtn').addEventListener('click', () => this.navigateQuestion(-1));
        document.getElementById('nextBtn').addEventListener('click', () => this.navigateQuestion(1));
        document.getElementById('askAIBtn').addEventListener('click', () => this.askAI());
        document.getElementById('resetBtn').addEventListener('click', () => this.resetQuiz());
        document.getElementById('viewResultsBtn').addEventListener('click', () => this.showResults());
    }

    initializeTabs() {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => this.switchTab(btn.dataset.tab));
        });
    }

    switchTab(tabId) {
        // Update active button
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabId);
        });

        // Show selected content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.style.display = content.id === tabId ? 'block' : 'none';
        });

        // Load content if not already loaded
        this.loadTabContent(tabId);
    }

    loadTabContent(tabId) {
        if (!this.currentModule) return;
        
        const contentDiv = document.querySelector(`#${tabId} > div`);
        contentDiv.innerHTML = this.learningContent[this.currentModule][tabId];
    }

    startQuiz(module) {
        this.currentModule = module;
        this.currentQuestionIndex = 0;
        this.userAnswers.clear();

        document.querySelector('.language-modules').style.display = 'none';
        document.querySelector('.quiz-section').style.display = 'block';

        document.getElementById('quizTitle').textContent = 
            `${module.charAt(0).toUpperCase() + module.slice(1)} Quiz`;

        this.loadQuestion();
        this.loadTabContent('theory');
        document.querySelector('.learning-content').style.display = 'block';
    }

    loadQuestion() {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        document.getElementById('questionText').textContent = question.question;

        const optionsContainer = document.querySelector('.options-container');
        optionsContainer.innerHTML = '';

        question.options.forEach((option, index) => {
            const optionElement = document.createElement('div');
            optionElement.className = 'option';
            optionElement.textContent = option;
            
            if (this.userAnswers.has(this.currentQuestionIndex)) {
                optionElement.classList.add('disabled');
                const userAnswer = this.userAnswers.get(this.currentQuestionIndex);
                const correctAnswer = question.correct;
                
                if (index === correctAnswer) {
                    optionElement.classList.add('correct');
                } else if (index === userAnswer && userAnswer !== correctAnswer) {
                    optionElement.classList.add('incorrect');
                }
            }

            optionElement.addEventListener('click', () => this.selectOption(index));
            optionsContainer.appendChild(optionElement);
        });

        this.updateProgress();

        // Hide feedback when loading new question
        document.querySelector('.result-feedback').style.display = 'none';
    }

    selectOption(index) {
        // If already answered, don't allow new selection
        if (this.userAnswers.has(this.currentQuestionIndex)) {
            return;
        }

        this.userAnswers.set(this.currentQuestionIndex, index);
        
        // Get the correct answer
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const correctIndex = question.correct;

        // Update options appearance
        document.querySelectorAll('.option').forEach((option, i) => {
            option.classList.add('disabled');
            if (i === correctIndex) {
                option.classList.add('correct');
            } else if (i === index && index !== correctIndex) {
                option.classList.add('incorrect');
            }
        });

        // Show immediate feedback
        this.showFeedback(index);
        
        // Show view results button if at least one question is answered
        this.hasAnswered = true;
        document.getElementById('viewResultsBtn').style.display = 'flex';
    }

    navigateQuestion(direction) {
        const newIndex = this.currentQuestionIndex + direction;
        if (newIndex >= 0 && newIndex < this.questions[this.currentModule].length) {
            this.currentQuestionIndex = newIndex;
            this.loadQuestion();
        }
    }

    updateProgress() {
        const total = this.questions[this.currentModule].length;
        document.getElementById('questionCounter').textContent = 
            `Question ${this.currentQuestionIndex + 1}/${total}`;

        const progress = ((this.currentQuestionIndex + 1) / total) * 100;
        document.querySelector('.progress').style.width = `${progress}%`;
    }

    askAI() {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const chatInput = document.querySelector('#userInput');
        const sendButton = document.querySelector('#sendBtn');
        const chatToggle = document.querySelector('#chatToggle');

        if (chatInput && sendButton && chatToggle) {
            const prompt = `Please explain this question and its answer:
                Question: ${question.question}
                Correct Answer: ${question.options[question.correct]}
                Explanation: ${question.explanation}`;

            chatInput.value = prompt;
            
            chatInput.dispatchEvent(new Event('input', { bubbles: true }));
            
            // Open chat if not already open
            if (!document.querySelector('.chat-widget.active')) {
                chatToggle.click();
            }

            // Trigger send
            sendButton.click();
        }
    }

    resetQuiz() {
        // Reset all state
        this.currentModule = null;
        this.currentQuestionIndex = 0;
        this.userAnswers.clear();

        // Show tutorials, hide quiz
        document.querySelector('.language-modules').style.display = 'grid';
        document.querySelector('.quiz-section').style.display = 'none';

        // Reset progress bar
        document.querySelector('.progress').style.width = '0%';

        // Optional: Scroll to top of tutorials
        document.querySelector('.tutorial-header').scrollIntoView({ 
            behavior: 'smooth',
            block: 'start'
        });
    }

    showFeedback(selectedIndex) {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const feedbackDiv = document.querySelector('.result-feedback');
        const feedbackText = feedbackDiv.querySelector('.feedback-text');
        const explanationText = feedbackDiv.querySelector('.explanation-text');
        
        const isCorrect = selectedIndex === question.correct;
        
        feedbackDiv.style.display = 'block';
        feedbackDiv.className = `result-feedback ${isCorrect ? 'correct' : 'incorrect'}`;
        
        feedbackText.textContent = isCorrect ? 
            'Correct Answer!' : 
            `Incorrect. The correct answer is: ${question.options[question.correct]}`;
        
        explanationText.textContent = question.explanation;
    }

    showResults() {
        const total = this.questions[this.currentModule].length;
        let correct = 0;
        
        this.userAnswers.forEach((answer, questionIndex) => {
            if (answer === this.questions[this.currentModule][questionIndex].correct) {
                correct++;
            }
        });

        const percentage = (correct / total) * 100;
        
        // Create results modal
        const modal = document.createElement('div');
        modal.className = 'results-modal';
        modal.innerHTML = `
            <div class="results-content">
                <h3>Quiz Results</h3>
                <div class="score-circle">
                    <span class="score-percentage">${percentage.toFixed(1)}%</span>
                    <span class="score-text">${correct} out of ${total}</span>
                </div>
                <button class="close-results">Close</button>
            </div>
        `;

        document.body.appendChild(modal);
        
        // Add close functionality
        modal.querySelector('.close-results').addEventListener('click', () => {
            modal.remove();
        });
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new LanguageSkillsQuiz();
});