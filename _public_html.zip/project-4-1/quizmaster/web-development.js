// language-skills.js
class LanguageSkillsQuiz {
    constructor() {
        this.questions = {
            frontend: [
                {
                    question: "What is React's virtual DOM?",
                    options: ["A direct copy of the real DOM", "A lightweight copy of the real DOM", "A server-side DOM", "A browser plugin"],
                    correct: 1,
                    explanation: "React's virtual DOM is a lightweight JavaScript representation of the actual DOM, used for performance optimization"
                },
                {
                    question: "Which hook is used for side effects in React?",
                    options: ["useEffect", "useState", "useContext", "useReducer"],
                    correct: 0,
                    explanation: "useEffect hook is used to perform side effects like API calls, subscriptions, or DOM mutations"
                },
                {
                    question: "What is Angular's dependency injection?",
                    options: ["A design pattern", "A testing framework", "A routing system", "A state management tool"],
                    correct: 0,
                    explanation: "Dependency injection is a design pattern where components receive dependencies from an external source"
                },
                {
                    question: "What is Vue's reactivity system based on?",
                    options: ["Proxy objects", "Event listeners", "Virtual DOM", "Web workers"],
                    correct: 0,
                    explanation: "Vue 3's reactivity system uses JavaScript Proxy objects to track changes to reactive data"
                },
                {
                    question: "Which CSS property is used for flexbox layouts?",
                    options: ["display: flex", "display: grid", "display: block", "display: inline"],
                    correct: 0,
                    explanation: "display: flex enables flexbox layout mode for container elements"
                },
                {
                    question: "What is the purpose of semantic HTML?",
                    options: ["Better accessibility", "Faster loading", "Better styling", "Better performance"],
                    correct: 0,
                    explanation: "Semantic HTML provides meaning to content structure, improving accessibility and SEO"
                },
                {
                    question: "What is the difference between let and var?",
                    options: ["Block scope vs function scope", "Function scope vs global scope", "No difference", "Syntax only"],
                    correct: 0,
                    explanation: "let has block scope while var has function scope in JavaScript"
                },
                {
                    question: "What is CSS Grid used for?",
                    options: ["Two-dimensional layouts", "One-dimensional layouts", "Animations", "Typography"],
                    correct: 0,
                    explanation: "CSS Grid is designed for two-dimensional layout systems, working on both rows and columns"
                },
                {
                    question: "What is the purpose of TypeScript?",
                    options: ["Static typing", "Database management", "Server deployment", "Image optimization"],
                    correct: 0,
                    explanation: "TypeScript adds static typing to JavaScript to catch errors early in development"
                },
                {
                    question: "What is the role of webpack?",
                    options: ["Module bundling", "Testing", "Deployment", "Version control"],
                    correct: 0,
                    explanation: "Webpack is a module bundler that packages JavaScript applications for production"
                }
            ],
            backend: [
                {
                    question: "What is Node.js event loop?",
                    options: ["Non-blocking I/O model", "Database system", "Frontend framework", "Testing tool"],
                    correct: 0,
                    explanation: "Node.js event loop enables non-blocking I/O operations despite JavaScript being single-threaded"
                },
                {
                    question: "What is Django's ORM used for?",
                    options: ["Database operations", "Frontend rendering", "URL routing", "Authentication"],
                    correct: 0,
                    explanation: "Django's ORM (Object-Relational Mapping) handles database operations using Python code"
                },
                {
                    question: "What is a SQL JOIN?",
                    options: ["Combines rows from tables", "Creates new table", "Deletes data", "Updates records"],
                    correct: 0,
                    explanation: "SQL JOIN clause combines rows from two or more tables based on related columns"
                },
                {
                    question: "What is Express.js middleware?",
                    options: ["Request processing functions", "Database drivers", "Template engines", "Static files"],
                    correct: 0,
                    explanation: "Middleware functions have access to request and response objects and can modify them"
                },
                {
                    question: "What is REST API?",
                    options: ["Architectural style", "Programming language", "Database type", "Frontend framework"],
                    correct: 0,
                    explanation: "REST is an architectural style for designing networked applications"
                },
                {
                    question: "What is MongoDB's advantage?",
                    options: ["Schema flexibility", "ACID compliance", "Join operations", "Stored procedures"],
                    correct: 0,
                    explanation: "MongoDB's document model allows for flexible, schema-less data structures"
                },
                {
                    question: "What is JWT used for?",
                    options: ["Authentication", "Database queries", "File uploads", "Email sending"],
                    correct: 0,
                    explanation: "JSON Web Tokens (JWT) are used for secure authentication and information exchange"
                },
                {
                    question: "What is GraphQL's purpose?",
                    options: ["Query language for APIs", "Database system", "Frontend framework", "Testing tool"],
                    correct: 0,
                    explanation: "GraphQL is a query language for APIs that gives clients precise data control"
                },
                {
                    question: "What is Redis used for?",
                    options: ["Caching", "Authentication", "File storage", "Email service"],
                    correct: 0,
                    explanation: "Redis is an in-memory data structure store used as cache, database, and message broker"
                },
                {
                    question: "What is Docker's main benefit?",
                    options: ["Container isolation", "Code editing", "Database management", "Frontend design"],
                    correct: 0,
                    explanation: "Docker provides consistent environments through container isolation"
                }
            ]
        };

        this.currentModule = null;
        this.currentQuestionIndex = 0;
        this.userAnswers = new Map();
        this.hasAnswered = false;

        this.learningContent = {
            frontend: {
                theory: `
                    <h4>Frontend Development Fundamentals</h4>
                    
                    <h5>1. React.js</h5>
                    <ul>
                        <li><strong>Components and Props</strong>
                            <ul>
                                <li>Functional & Class Components</li>
                                <li>Props passing & validation</li>
                                <li>Component composition</li>
                            </ul>
                        </li>
                        <li><strong>State Management</strong>
                            <ul>
                                <li>useState & useReducer</li>
                                <li>Redux fundamentals</li>
                                <li>Context API patterns</li>
                            </ul>
                        </li>
                        <li><strong>Hooks and Lifecycle</strong>
                            <ul>
                                <li>Common hooks (useEffect, useMemo)</li>
                                <li>Custom hooks</li>
                                <li>Component lifecycle events</li>
                            </ul>
                        </li>
                        <li><strong>Virtual DOM</strong></li>
                        <li><strong>Context API</strong></li>
                    </ul>

                    <h5>2. Angular</h5>
                    <ul>
                        <li><strong>Components and Modules</strong>
                            <ul>
                                <li>Component lifecycle</li>
                                <li>Module organization</li>
                                <li>Dependency injection</li>
                            </ul>
                        </li>
                        <li><strong>Services and DI</strong></li>
                        <li><strong>Templates and Forms</strong>
                            <ul>
                                <li>Template syntax</li>
                                <li>Reactive forms</li>
                                <li>Form validation</li>
                            </ul>
                        </li>
                        <li><strong>RxJS and Observables</strong></li>
                    </ul>

                    <h5>3. Vue.js</h5>
                    <ul>
                        <li><strong>Vue Components</strong>
                            <ul>
                                <li>Single-file components</li>
                                <li>Component registration</li>
                                <li>Props and events</li>
                            </ul>
                        </li>
                        <li><strong>Reactivity System</strong></li>
                        <li><strong>Vuex State Management</strong></li>
                        <li><strong>Vue Router</strong></li>
                    </ul>

                    <h5>4. HTML/CSS/JavaScript</h5>
                    <ul>
                        <li><strong>Semantic HTML5</strong>
                            <ul>
                                <li>Document structure</li>
                                <li>Accessibility best practices</li>
                                <li>SEO optimization</li>
                            </ul>
                        </li>
                        <li><strong>CSS Grid/Flexbox</strong></li>
                        <li><strong>ES6+ Features</strong></li>
                        <li><strong>TypeScript</strong></li>
                    </ul>
                `,
                examples: `
                    <h4>Code Examples</h4>

                    <h5>React Component Example</h5>
                    <pre><code>
import React, { useState } from 'react';

function Counter() {
    const [count, setCount] = useState(0);
    
    return (
        <div>
            <p>Count: {count}</p>
            <button onClick={() => setCount(count + 1)}>
                Increment
            </button>
        </div>
    );
}
                    </code></pre>

                    <h5>Angular Component Example</h5>
                    <pre><code>
@Component({
    selector: 'app-counter',
    template: \`
        <div>
            <p>Count: {{count}}</p>
            <button (click)="increment()">
                Increment
            </button>
        </div>
    \`
})
export class CounterComponent {
    count = 0;
    
    increment() {
        this.count++;
    }
}
                    </code></pre>

                    <h5>Vue Component Example</h5>
                    <pre><code>
<template>
    <div>
        <p>Count: {{ count }}</p>
        <button @click="increment">
            Increment
        </button>
    </div>
</template>

<script>
export default {
    data() {
        return {
            count: 0
        }
    },
    methods: {
        increment() {
            this.count++
        }
    }
}
</script>
                    </code></pre>
                `,
                practice: `
                    <h4>Frontend Practice Exercises</h4>
                    
                    <div class="practice-item">
                        <h5>React Exercise</h5>
                        <p>Build a todo list with:</p>
                        <ul>
                            <li>Add/Remove items</li>
                            <li>Mark as complete</li>
                            <li>Filter tasks</li>
                            <li>Local storage persistence</li>
                            <li>Categories and tags</li>
                        </ul>

                        <h5>CSS Layout Exercise</h5>
                        <p>Create responsive layouts using:</p>
                        <ul>
                            <li>Flexbox</li>
                            <li>Grid</li>
                            <li>Media queries</li>
                            <li>Mobile-first approach</li>
                            <li>CSS animations</li>
                        </ul>
                    </div>
                `
            },
            backend: {
                theory: `
                    <h4>Backend Development Fundamentals</h4>
                    
                    <h5>1. Node.js</h5>
                    <ul>
                        <li><strong>Event Loop</strong>
                            <ul>
                                <li>Asynchronous programming</li>
                                <li>Callbacks and Promises</li>
                                <li>Async/Await patterns</li>
                            </ul>
                        </li>
                        <li><strong>Express.js</strong>
                            <ul>
                                <li>Routing and middleware</li>
                                <li>Error handling</li>
                                <li>Template engines</li>
                            </ul>
                        </li>
                        <li><strong>Middleware</strong></li>
                        <li><strong>REST APIs</strong></li>
                    </ul>

                    <h5>2. Django</h5>
                    <ul>
                        <li><strong>MVT Architecture</strong>
                            <ul>
                                <li>Models and databases</li>
                                <li>Views and URL patterns</li>
                                <li>Template rendering</li>
                            </ul>
                        </li>
                        <li><strong>ORM</strong></li>
                        <li><strong>Forms and Views</strong></li>
                        <li><strong>Authentication</strong></li>
                    </ul>

                    <h5>3. Databases</h5>
                    <ul>
                        <li><strong>SQL Fundamentals</strong>
                            <ul>
                                <li>CRUD operations</li>
                                <li>Joins and relationships</li>
                                <li>Indexing and optimization</li>
                            </ul>
                        </li>
                        <li><strong>MongoDB</strong></li>
                        <li><strong>Redis</strong></li>
                        <li><strong>Database Design</strong></li>
                    </ul>

                    <h5>4. Server Architecture</h5>
                    <ul>
                        <li><strong>API Design</strong></li>
                        <li><strong>Authentication/Authorization</strong></li>
                        <li><strong>Microservices</strong></li>
                        <li><strong>Docker/Containers</strong></li>
                    </ul>
                `,
                examples: `
                    <h4>Backend Code Examples</h4>

                    <h5>Express.js API Example</h5>
                    <pre><code>
const express = require('express');
const app = express();

app.get('/api/users', async (req, res) => {
    try {
        const users = await User.find();
        res.json(users);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/users', async (req, res) => {
    try {
        const user = new User(req.body);
        await user.save();
        res.status(201).json(user);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});
                    </code></pre>

                    <h5>Django View Example</h5>
                    <pre><code>
from django.views import View
from django.http import JsonResponse

class UserView(View):
    def get(self, request):
        users = User.objects.all()
        data = [{"id": user.id, "name": user.name} 
                for user in users]
        return JsonResponse(data, safe=False)

    def post(self, request):
        data = json.loads(request.body)
        user = User.objects.create(**data)
        return JsonResponse({
            "id": user.id,
            "name": user.name
        }, status=201)
                    </code></pre>
                `,
                practice: `
                    <h4>Backend Practice Exercises</h4>
                    
                    <div class="practice-item">
                        <h5>API Development</h5>
                        <p>Create a RESTful API with:</p>
                        <ul>
                            <li>CRUD operations</li>
                            <li>Authentication</li>
                            <li>Data validation</li>
                            <li>Rate limiting</li>
                            <li>API documentation</li>
                            <li>Error handling</li>
                        </ul>

                        <h5>Database Exercise</h5>
                        <p>Design and implement:</p>
                        <ul>
                            <li>Schema design</li>
                            <li>Complex queries</li>
                            <li>Data relationships</li>
                            <li>Indexing strategy</li>
                            <li>Data migration scripts</li>
                            <li>Backup procedures</li>
                        </ul>
                    </div>
                `
            }
        };

        this.initializeEventListeners();
        this.initializeTabs();
    }

    initializeEventListeners() {
        document.querySelectorAll('.start-quiz-btn').forEach(btn => {
            btn.addEventListener('click', () => this.startQuiz(btn.dataset.module));
        });

        document.getElementById('prevBtn').addEventListener('click', () => this.navigateQuestion(-1));
        document.getElementById('nextBtn').addEventListener('click', () => this.navigateQuestion(1));
        document.getElementById('askAIBtn').addEventListener('click', () => this.askAI());
        document.getElementById('resetBtn').addEventListener('click', () => this.resetQuiz());
        document.getElementById('viewResultsBtn').addEventListener('click', () => this.showResults());
    }

    initializeTabs() {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => this.switchTab(btn.dataset.tab));
        });
    }

    switchTab(tabId) {
        // Update active button
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabId);
        });

        // Show selected content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.style.display = content.id === tabId ? 'block' : 'none';
        });

        // Load content if not already loaded
        this.loadTabContent(tabId);
    }

    loadTabContent(tabId) {
        if (!this.currentModule) return;
        
        const contentDiv = document.querySelector(`#${tabId} > div`);
        contentDiv.innerHTML = this.learningContent[this.currentModule][tabId];
    }

    startQuiz(module) {
        this.currentModule = module;
        this.currentQuestionIndex = 0;
        this.userAnswers.clear();

        document.querySelector('.language-modules').style.display = 'none';
        document.querySelector('.quiz-section').style.display = 'block';

        document.getElementById('quizTitle').textContent = 
            `${module.charAt(0).toUpperCase() + module.slice(1)} Quiz`;

        this.loadQuestion();
        this.loadTabContent('theory');
        document.querySelector('.learning-content').style.display = 'block';
    }

    loadQuestion() {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        document.getElementById('questionText').textContent = question.question;

        const optionsContainer = document.querySelector('.options-container');
        optionsContainer.innerHTML = '';

        question.options.forEach((option, index) => {
            const optionElement = document.createElement('div');
            optionElement.className = 'option';
            optionElement.textContent = option;
            
            if (this.userAnswers.has(this.currentQuestionIndex)) {
                optionElement.classList.add('disabled');
                const userAnswer = this.userAnswers.get(this.currentQuestionIndex);
                const correctAnswer = question.correct;
                
                if (index === correctAnswer) {
                    optionElement.classList.add('correct');
                } else if (index === userAnswer && userAnswer !== correctAnswer) {
                    optionElement.classList.add('incorrect');
                }
            }

            optionElement.addEventListener('click', () => this.selectOption(index));
            optionsContainer.appendChild(optionElement);
        });

        this.updateProgress();

        // Hide feedback when loading new question
        document.querySelector('.result-feedback').style.display = 'none';
    }

    selectOption(index) {
        // If already answered, don't allow new selection
        if (this.userAnswers.has(this.currentQuestionIndex)) {
            return;
        }

        this.userAnswers.set(this.currentQuestionIndex, index);
        
        // Get the correct answer
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const correctIndex = question.correct;

        // Update options appearance
        document.querySelectorAll('.option').forEach((option, i) => {
            option.classList.add('disabled');
            if (i === correctIndex) {
                option.classList.add('correct');
            } else if (i === index && index !== correctIndex) {
                option.classList.add('incorrect');
            }
        });

        // Show immediate feedback
        this.showFeedback(index);
        
        // Show view results button if at least one question is answered
        this.hasAnswered = true;
        document.getElementById('viewResultsBtn').style.display = 'flex';
    }

    navigateQuestion(direction) {
        const newIndex = this.currentQuestionIndex + direction;
        if (newIndex >= 0 && newIndex < this.questions[this.currentModule].length) {
            this.currentQuestionIndex = newIndex;
            this.loadQuestion();
        }
    }

    updateProgress() {
        const total = this.questions[this.currentModule].length;
        document.getElementById('questionCounter').textContent = 
            `Question ${this.currentQuestionIndex + 1}/${total}`;

        const progress = ((this.currentQuestionIndex + 1) / total) * 100;
        document.querySelector('.progress').style.width = `${progress}%`;
    }

    askAI() {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const chatInput = document.querySelector('#userInput');
        const sendButton = document.querySelector('#sendBtn');
        const chatToggle = document.querySelector('#chatToggle');

        if (chatInput && sendButton && chatToggle) {
            const prompt = `Please explain this question and its answer:
                Question: ${question.question}
                Correct Answer: ${question.options[question.correct]}
                Explanation: ${question.explanation}`;

            chatInput.value = prompt;
            
            chatInput.dispatchEvent(new Event('input', { bubbles: true }));
            
            // Open chat if not already open
            if (!document.querySelector('.chat-widget.active')) {
                chatToggle.click();
            }

            // Trigger send
            sendButton.click();
        }
    }

    resetQuiz() {
        // Reset all state
        this.currentModule = null;
        this.currentQuestionIndex = 0;
        this.userAnswers.clear();

        // Show tutorials, hide quiz
        document.querySelector('.language-modules').style.display = 'grid';
        document.querySelector('.quiz-section').style.display = 'none';

        // Reset progress bar
        document.querySelector('.progress').style.width = '0%';

        // Optional: Scroll to top of tutorials
        document.querySelector('.tutorial-header').scrollIntoView({ 
            behavior: 'smooth',
            block: 'start'
        });
    }

    showFeedback(selectedIndex) {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const feedbackDiv = document.querySelector('.result-feedback');
        const feedbackText = feedbackDiv.querySelector('.feedback-text');
        const explanationText = feedbackDiv.querySelector('.explanation-text');
        
        const isCorrect = selectedIndex === question.correct;
        
        feedbackDiv.style.display = 'block';
        feedbackDiv.className = `result-feedback ${isCorrect ? 'correct' : 'incorrect'}`;
        
        feedbackText.textContent = isCorrect ? 
            'Correct Answer!' : 
            `Incorrect. The correct answer is: ${question.options[question.correct]}`;
        
        explanationText.textContent = question.explanation;
    }

    showResults() {
        const total = this.questions[this.currentModule].length;
        let correct = 0;
        
        this.userAnswers.forEach((answer, questionIndex) => {
            if (answer === this.questions[this.currentModule][questionIndex].correct) {
                correct++;
            }
        });

        const percentage = (correct / total) * 100;
        
        // Create results modal
        const modal = document.createElement('div');
        modal.className = 'results-modal';
        modal.innerHTML = `
            <div class="results-content">
                <h3>Quiz Results</h3>
                <div class="score-circle">
                    <span class="score-percentage">${percentage.toFixed(1)}%</span>
                    <span class="score-text">${correct} out of ${total}</span>
                </div>
                <button class="close-results">Close</button>
            </div>
        `;

        document.body.appendChild(modal);
        
        // Add close functionality
        modal.querySelector('.close-results').addEventListener('click', () => {
            modal.remove();
        });
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new LanguageSkillsQuiz();
});