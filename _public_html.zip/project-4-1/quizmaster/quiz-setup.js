// Constants
const QUIZ_CONFIG_KEY = 'quizConfig';
const MIN_QUESTIONS = 5;
const MIN_TIME_PER_QUESTION = 30;
const MAX_TIME_PER_QUESTION = 300;

// Category Metadata
const CATEGORIES = {
    Linux: { count: 99, icon: 'fab fa-linux', color: '#FCC624', difficulty: { easy: 40, medium: 39, hard: 20 } },
    BASH: { count: 77, icon: 'fas fa-terminal', color: '#4EAA25', difficulty: { easy: 30, medium: 27, hard: 20 } },
    PHP: { count: 180, icon: 'fab fa-php', color: '#777BB4', difficulty: { easy: 70, medium: 80, hard: 30 } },
    Docker: { count: 166, icon: 'fab fa-docker', color: '#2496ED', difficulty: { easy: 60, medium: 76, hard: 30 } },
    HTML: { count: 141, icon: 'fab fa-html5', color: '#E34F26', difficulty: { easy: 50, medium: 61, hard: 30 } },
    Postgres: { count: 205, icon: 'fas fa-database', color: '#336791', difficulty: { easy: 80, medium: 85, hard: 40 } },
    MySQL: { count: 262, icon: 'fas fa-database', color: '#4479A1', difficulty: { easy: 100, medium: 112, hard: 50 } },
    Laravel: { count: 114, icon: 'fab fa-laravel', color: '#FF2D20', difficulty: { easy: 44, medium: 50, hard: 20 } },
    Kubernetes: { count: 136, icon: 'fas fa-dharmachakra', color: '#326CE5', difficulty: { easy: 46, medium: 60, hard: 30 } },
    JavaScript: { count: 326, icon: 'fab fa-js', color: '#F7DF1E', difficulty: { easy: 126, medium: 150, hard: 50 } },
    Python: { count: 521, icon: 'fab fa-python', color: '#3776AB', difficulty: { easy: 200, medium: 221, hard: 100 } },
    Openshift: { count: 200, icon: 'fas fa-ship', color: '#EE0000', difficulty: { easy: 70, medium: 90, hard: 40 } },
    Terraform: { count: 26, icon: 'fas fa-cloud', color: '#7B42BC', difficulty: { easy: 10, medium: 11, hard: 5 } },
    React: { count: 106, icon: 'fab fa-react', color: '#61DAFB', difficulty: { easy: 40, medium: 46, hard: 20 } },
    Django: { count: 557, icon: 'fab fa-python', color: '#092E20', difficulty: { easy: 200, medium: 257, hard: 100 } },
    cPanel: { count: 73, icon: 'fas fa-server', color: '#FF6C2C', difficulty: { easy: 30, medium: 33, hard: 10 } },
    Ubuntu: { count: 526, icon: 'fab fa-ubuntu', color: '#E95420', difficulty: { easy: 200, medium: 226, hard: 100 } },
    nodeJS: { count: 1074, icon: 'fab fa-node-js', color: '#339933', difficulty: { easy: 400, medium: 474, hard: 200 } },
    WordPress: { count: 322, icon: 'fab fa-wordpress', color: '#21759B', difficulty: { easy: 122, medium: 150, hard: 50 } },
    'Next.js': { count: 299, icon: 'fab fa-react', color: '#000000', difficulty: { easy: 100, medium: 149, hard: 50 } },
    VueJS: { count: 1350, icon: 'fab fa-vuejs', color: '#4FC08D', difficulty: { easy: 500, medium: 650, hard: 200 } },
    'Apache Kafka': { count: 342, icon: 'fas fa-stream', color: '#231F20', difficulty: { easy: 122, medium: 160, hard: 60 } }
};

class QuizSetup {
    constructor() {
        this.initializeElements();
        this.initializeState();
        this.setupEventListeners();
        this.renderCategories();
    }

    initializeElements() {
        this.elements = {
            categorySearch: document.getElementById('categorySearch'),
            categoryGrid: document.querySelector('.category-grid'),
            difficultyBtns: document.querySelectorAll('.difficulty-btn'),
            questionCountInput: document.getElementById('questionCount'),
            timePerQuestionInput: document.getElementById('timePerQuestion'),
            startQuizBtn: document.querySelector('.start-quiz-btn'),
            progressSteps: document.querySelectorAll('.progress-step')
        };
    }

    initializeState() {
        const savedConfig = localStorage.getItem(QUIZ_CONFIG_KEY);
        this.state = {
            quizConfig: savedConfig ? JSON.parse(savedConfig) : {
                category: '',
                difficulty: 'medium',
                questionCount: 10,
                timePerQuestion: 60,
                tags: []
            },
            searchQuery: '',
            filteredCategories: []
        };
    }

    setupEventListeners() {
        // Category search
        this.elements.categorySearch?.addEventListener('input', this.handleCategorySearch.bind(this));

        // Difficulty selection
        this.elements.difficultyBtns?.forEach(btn => {
            btn.addEventListener('click', this.handleDifficultyChange.bind(this));
        });

        // Input controls
        this.setupInputControls();

        // Start quiz button
        this.elements.startQuizBtn?.addEventListener('click', this.handleStartQuiz.bind(this));

        // Keyboard shortcuts
        document.addEventListener('keydown', this.handleKeyboardShortcuts.bind(this));
    }

    handleCategorySearch(event) {
        const searchQuery = event.target.value.toLowerCase();
        this.state.searchQuery = searchQuery;
        this.renderCategories();
    }

    renderCategories() {
        if (!this.elements.categoryGrid) return;
        
        this.elements.categoryGrid.innerHTML = '';
        const categoriesGrid = document.createElement('div');
        categoriesGrid.className = 'categories-grid';

        // Filter and render categories
        Object.entries(CATEGORIES)
            .filter(([name]) => 
                name.toLowerCase().includes(this.state.searchQuery.toLowerCase()))
            .forEach(([name, meta]) => {
                const categoryBtn = this.createCategoryButton(name, meta);
                categoriesGrid.appendChild(categoryBtn);
            });

        this.elements.categoryGrid.appendChild(categoriesGrid);
    }

    createCategoryButton(name, meta) {
        const btn = document.createElement('button');
        btn.className = 'category-btn';
        if (name === this.state.quizConfig.category) {
            btn.classList.add('active');
        }

        const difficultyStats = this.getDifficultyStats(meta.difficulty);
        
        btn.innerHTML = `
            <div class="category-icon">
                <i class="${meta.icon}" style="color: ${meta.color}"></i>
            </div>
            <div class="category-info">
                <span class="category-name">${name}</span>
                <div class="difficulty-distribution">
                    ${difficultyStats}
                </div>
                <small>${meta.count} questions</small>
            </div>
        `;
        
        btn.addEventListener('click', () => this.handleCategorySelect(name));
        return btn;
    }

    setupInputControls() {
        const inputs = {
            questionCount: this.elements.questionCountInput,
            timePerQuestion: this.elements.timePerQuestionInput
        };

        Object.entries(inputs).forEach(([key, input]) => {
            if (!input) return;

            const controls = input.parentElement.querySelector('.input-controls');
            if (!controls) return;

            controls.querySelectorAll('.control-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const action = btn.dataset.action;
                    const currentValue = parseInt(input.value);
                    
                    if (action === 'increment') {
                        input.value = Math.min(currentValue + 1, key === 'questionCount' ? 50 : MAX_TIME_PER_QUESTION);
                    } else {
                        input.value = Math.max(currentValue - 1, key === 'questionCount' ? MIN_QUESTIONS : MIN_TIME_PER_QUESTION);
                    }

                    this.handleConfigChange(key, input.value);
                });
            });

            input.addEventListener('change', () => {
                this.handleConfigChange(key, input.value);
            });
        });
    }

    handleDifficultyChange(event) {
        const difficulty = event.currentTarget.dataset.difficulty;
        this.elements.difficultyBtns.forEach(btn => btn.classList.remove('active'));
        event.currentTarget.classList.add('active');
        this.state.quizConfig.difficulty = difficulty;
        this.updateStartButton();
    }

    handleConfigChange(key, value) {
        this.state.quizConfig[key] = parseInt(value);
        this.validateAndUpdateUI();
    }

    validateAndUpdateUI() {
        const errors = this.validateQuizConfig();
        this.elements.startQuizBtn.disabled = errors.length > 0;
        this.updateStartButton();
    }

    validateQuizConfig() {
        const errors = [];
        const { questionCount, timePerQuestion, category } = this.state.quizConfig;

        if (!category) {
            errors.push('Please select a category');
        }

        if (questionCount < MIN_QUESTIONS || questionCount > 50) {
            errors.push(`Question count must be between ${MIN_QUESTIONS} and 50`);
        }

        if (timePerQuestion < MIN_TIME_PER_QUESTION || timePerQuestion > MAX_TIME_PER_QUESTION) {
            errors.push(`Time per question must be between ${MIN_TIME_PER_QUESTION} and ${MAX_TIME_PER_QUESTION} seconds`);
        }

        return errors;
    }

    updateStartButton() {
        const btn = this.elements.startQuizBtn;
        if (!btn) return;

        if (this.state.quizConfig.category) {
            btn.innerHTML = '<i class="fas fa-play"></i> Start Quiz';
            btn.disabled = false;
        } else {
            btn.innerHTML = '<i class="fas fa-hand-pointer"></i> Select a category to start';
            btn.disabled = true;
        }
    }

    handleKeyboardShortcuts(event) {
        // Add keyboard shortcuts if needed
    }

    showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${message}`;
        
        const existingError = document.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }

        this.elements.startQuizBtn.parentElement.appendChild(errorDiv);
        setTimeout(() => errorDiv.remove(), 5000);
    }

    async prepareQuiz() {
        // Simulate API call
        return new Promise(resolve => setTimeout(resolve, 1000));
    }

    async handleStartQuiz() {
        try {
            const errors = this.validateQuizConfig();
            if (errors.length > 0) {
                throw new Error(errors.join('\n'));
            }

            this.elements.startQuizBtn.disabled = true;
            this.elements.startQuizBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Preparing Quiz...';

            // Save configuration
            localStorage.setItem(QUIZ_CONFIG_KEY, JSON.stringify(this.state.quizConfig));

            // Simulate API call to prepare quiz
            await this.prepareQuiz();

            // Redirect to quiz page
            window.location.href = 'take-quiz';
        } catch (error) {
            this.showError(error.message);
            this.elements.startQuizBtn.disabled = false;
            this.updateStartButton();
        }
    }

    getDifficultyStats(difficulty) {
        const total = difficulty.easy + difficulty.medium + difficulty.hard;
        return `
            <div class="difficulty-bars">
                <div class="diff-bar easy" style="width: ${(difficulty.easy/total * 100)}%"></div>
                <div class="diff-bar medium" style="width: ${(difficulty.medium/total * 100)}%"></div>
                <div class="diff-bar hard" style="width: ${(difficulty.hard/total * 100)}%"></div>
            </div>
        `;
    }

    handleCategorySelect(name) {
        this.state.quizConfig.category = name;
        this.renderCategories(); // Re-render to show active state
        this.updateStartButton();
        
        // Update progress steps
        this.elements.progressSteps.forEach((step, index) => {
            if (index === 0) step.classList.add('completed');
        });
    }
}

// Initialize quiz setup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new QuizSetup();
}); 