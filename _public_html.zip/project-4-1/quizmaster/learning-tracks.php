<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('../assets/layout/header.php');
$footer = inancap('../assets/layout/footer.php');
$meta = inancap('../assets/layout/meta.php');
echo $meta;
$descript = 'Quizmaster - TalentSphere';
$title = 'TalentSphere';
echo generateMetaTags($title, $descript, '', '', 'Coding, Courses');
echo $header;
?>
    <link rel="stylesheet" href="learning-tracks.css">
    <style>
        
/* Tutorials Section */
.tutorials {
    padding: 8rem 5%;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
}

.tutorials-container {
    max-width: 1400px;
    margin: 0 auto;
}

.tutorial-category {
    margin-bottom: 4rem;
}

.tutorial-category h3 {
    color: var(--secondary-color);
    font-size: 1.8rem;
    margin-bottom: 2rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    padding-bottom: 0.5rem;
    border-bottom: 2px solid var(--primary-color);
}

.tutorial-category h3 i {
    color: var(--primary-color);
}

.tutorial-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
}

.tutorial-card {
    background: white;
    border-radius: 15px;
    padding: 2rem;
    box-shadow: var(--box-shadow);
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.tutorial-card:hover {
    transform: translateY(-5px);
}

.tutorial-icon {
    width: 70px;
    height: 70px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 1.5rem;
}

/* Custom colors for different tutorial icons */
.python { background: linear-gradient(45deg, #4B8BBE, #306998); }
.java { background: linear-gradient(45deg, #f89820, #e76f00); }
.frontend { background: linear-gradient(45deg, #61DAFB, #764ABC); }
.backend { background: linear-gradient(45deg, #68A063, #3C873A); }
.quantitative { background: linear-gradient(45deg, #FF6B6B, #ee5253); }
.logical { background: linear-gradient(45deg, #48dbfb, #0abde3); }
.english { background: linear-gradient(45deg, #1dd1a1, #10ac84); }
.communication { background: linear-gradient(45deg, #ff9f43, #feca57); }

.tutorial-icon i {
    font-size: 2rem;
    color: white;
}

.tutorial-card h4 {
    color: var(--secondary-color);
    font-size: 1.4rem;
    margin-bottom: 1rem;
}

.tutorial-card p {
    color: #666;
    margin-bottom: 1.5rem;
    font-size: 0.95rem;
}

.tutorial-features {
    list-style: none;
    margin-bottom: 2rem;
}

.tutorial-features li {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 0.8rem;
    color: #555;
    font-size: 0.9rem;
}

.tutorial-features li i {
    color: var(--primary-color);
}

.start-learning-btn {
    width: 100%;
    padding: 1rem;
    background: var(--primary-color);
    color: white;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.start-learning-btn:hover {
    background: var(--secondary-color);
    transform: translateY(-2px);
}

/* Responsive Design */
@media (max-width: 1024px) {
    .tutorial-category h3 {
        font-size: 1.6rem;
    }
    
    .tutorial-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 768px) {
    .tutorials {
        padding: 3rem 3%;
    }

    .tutorial-grid {
        grid-template-columns: 1fr;
        gap: 1.5rem;
    }

    .tutorial-category {
        margin-bottom: 2.5rem;
    }

    .tutorial-card {
        max-width: 500px;
        margin: 0 auto;
    }
}

@media (max-width: 480px) {
    .tutorial-category h3 {
        font-size: 1.4rem;
    }

    .tutorial-card {
        padding: 1.5rem;
    }

    .tutorial-icon {
        width: 60px;
        height: 60px;
    }

    .tutorial-icon i {
        font-size: 1.75rem;
    }
}
.category-link{
    text-decoration:none;
}

.exam-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
}
    
@media (max-width: 768px) {
    .exam-grid {
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1.5rem;
    }
}
    </style>
    <section class="tutorials">
        <div class="section-header">
            <h2>Popular Competitive Exams</h2>
            <p>Prepare for top competitive exams with our comprehensive study materials</p>
        </div>
        <div class="exam-grid">
            <!-- Engineering & Technology -->
            <div class="tutorial-category">
                <a href="engineering-technology" class="category-link">
                    <div class="tutorial-card">
                        <div class="tutorial-icon frontend">
                            <i class="fas fa-cogs"></i>
                        </div>
                        <h4>Engineering & Technology</h4>
                        <p>Prepare for GATE, IES and other engineering exams</p>
                        <button class="start-learning-btn">View Course</button>
                    </div>
                </a>
            </div>

            <!-- Management & MBA -->
            <div class="tutorial-category">
                <a href="management-mba" class="category-link">
                    <div class="tutorial-card">
                        <div class="tutorial-icon quantitative">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <h4>Management & MBA</h4>
                        <p>Prepare for CAT, GMAT and other management exams</p>
                        <button class="start-learning-btn">View Course</button>
                    </div>
                </a>
            </div>

            <!-- Civil Services -->
            <div class="tutorial-category">
                <a href="civil-services-government" class="category-link">
                    <div class="tutorial-card">
                        <div class="tutorial-icon english">
                            <i class="fas fa-landmark"></i>
                        </div>
                        <h4>Civil Services & Government</h4>
                        <p>Prepare for UPSC, Bank PO and other government exams</p>
                        <button class="start-learning-btn">View Course</button>
                    </div>
                </a>
            </div>

            <!-- International English Tests -->
            <div class="tutorial-category">
                <a href="international-english" class="category-link">
                    <div class="tutorial-card">
                        <div class="tutorial-icon english">
                            <i class="fas fa-language"></i>
                        </div>
                        <h4>International English Tests</h4>
                        <p>Prepare for IELTS, TOEFL and other English proficiency tests</p>
                        <button class="start-learning-btn">View Course</button>
                    </div>
                </a>
            </div>
        </div>
    </section>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="main.js"></script>
    <script src="definition_index.js"></script>
    <script src="chat.js"></script>
    <script src="newsletter.js"></script>

<?php echo $footer;?>