
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuizMaster - Taking Quiz</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="quiz.css">
    <link rel="stylesheet" href="take-quiz.css">
    <link href="/project-4-1/assets/styles/chat_20.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Quiz Loader -->
    <div class="quiz-loader" id="quizLoader">
        <div class="loader-content">
            <i class="fas fa-spinner fa-spin"></i>
            <p>Loading your quiz...</p>
        </div>
    </div>

    <!-- Quiz Interface -->
    <div class="quiz-interface" id="quizInterface" style="display: none;">
        <!-- Quiz Header -->
        <header class="quiz-header">
            <div class="quiz-info">
                <h1 id="quizTitle"></h1>
                <div class="quiz-meta">
                    <span><i class="fas fa-layer-group"></i> <span id="difficulty"></span></span>
                    <span><i class="fas fa-clock"></i> Time: <span id="timer">00:00</span></span>
                    <span><i class="fas fa-question-circle"></i> Question: <span id="questionNumber">0/0</span></span>
                </div>
            </div>
            <div class="progress-container">
                <div class="progress-bar">
                    <div class="progress" id="quizProgress"></div>
                </div>
                <div class="progress-stats">
                    <span class="answered"><i class="fas fa-check-circle"></i> Answered: <span id="answeredCount">0</span></span>
                    <span class="flagged"><i class="fas fa-flag"></i> Flagged: <span id="flaggedCount">0</span></span>
                    <span class="remaining"><i class="fas fa-question"></i> Remaining: <span id="remainingCount">0</span></span>
                </div>
            </div>
        </header>

        <!-- Question Container -->
        <div class="question-container" role="main">
            <div class="question-header">
                <span class="question-number" id="currentQuestionLabel" aria-live="polite">Question 1</span>
            </div>
            
            <div class="question-content">
                <p id="questionText" role="heading" aria-level="2"></p>
                <div class="options-grid" id="optionsGrid" role="radiogroup" aria-labelledby="questionText">
                    <!-- Options will be dynamically added here -->
                </div>
            </div>

            <!-- Quiz Navigation -->
            <footer class="quiz-footer">
                <div class="navigation-buttons">
                    <button class="nav-btn" id="prevBtn" disabled aria-label="Previous question">
                        <i class="fas fa-arrow-left" aria-hidden="true"></i> Previous
                    </button>
                    <button class="nav-btn primary" id="nextBtn" aria-label="Next question">
                        Next <i class="fas fa-arrow-right" aria-hidden="true"></i>
                    </button>
                </div>
                <button class="submit-btn" id="submitBtn" aria-label="Submit quiz">
                    <i class="fas fa-check-circle" aria-hidden="true"></i> Submit Quiz
                </button>
            </footer>
        </div>
    </div>

    <!-- Quiz Result Modal -->
    <div id="resultModal" class="modal">
        <div class="modal-content">
            <button class="chat-toggle" id="chatToggle">
                <i class="fas fa-comments"></i>
            </button>
            <div class="results-header">
                <h2>Quiz Results</h2>
                <p>Here's how you performed</p>
            </div>

            <!-- Score Circle -->
            <div class="score-container">
                <div class="score-circle">
                    <div class="score-inner">
                        <span class="score-text">85%</span>
                        <span class="score-label">Score</span>
                    </div>
                </div>
            </div>
 <div class="definition-info">
    <div class="info-message">
        <div class="info-icon">
            <i class="fas fa-lightbulb"></i>
        </div>
        <div class="info-content">
            <h4>Pro Tip</h4>
            <p>Select any word or text to get instant definitions and AI-powered explanations to enhance your learnin!</p>
        </div>
    </div>
</div>
            <!-- Stats Grid -->
            <div class="results-stats">
                <div class="stat-card">
                    <i class="fas fa-check-circle"></i>
                    <div class="stat-info">
                        <span class="stat-label">Correct Answers</span>
                        <span class="stat-value correct">17/20</span>
                    </div>
                </div>
                <!-- Add more stat cards -->
            </div>

            <!-- Analysis Section -->
            <div class="analysis-section">
                <div class="analysis-header">
                    <i class="fas fa-chart-line"></i>
                    <h3>Performance Analysis</h3>
                </div>
                <div class="performance-breakdown">
                    <div class="chart-container">
                        <canvas id="performanceChart"></canvas>
                    </div>
                </div>
                <br>
                <div class="analysis-header">
                    <h4>Topic Breakdown</h4>
                </div>
                    
                <div class="performance-breakdown">
                        <div class="chart-container">
                            <canvas id="topicsChart"></canvas>
                        </div>
                    </div>
                    <br>
                    <div class="analysis-header">
                        <h4>Time Analysis</h4>
                    </div>
                <div class="performance-breakdown">
                        <div class="chart-container">
                            <canvas id="timeChart"></canvas>
                        </div>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="results-actions">
                <button class="action-btn review" id="reviewBtn">
                    <i class="fas fa-eye"></i>
                    Review Answers
                </button>
                <button class="action-btn share" id="shareBtn">
                    <i class="fas fa-share-alt"></i>
                    Share Results
                </button>
                <button class="action-btn download" id="downloadBtn">
                    <i class="fas fa-download"></i>
                    Download Certificate
                </button>
            </div>

           
        </div>
    </div>
    
    <div class="chat-widget" id="chatWidget">
        <!-- Header -->
        <div class="chat-header">
            <div class="chat-title">
                <i class="fas fa-clapperboard-play"></i>
                <h3>Assistant</h3>
            </div>
            <div class="chat-actions">
                <button class="new-chat-btn" aria-label="New Chat">
                    <i class="fas fa-plus"></i>
                </button>
                <button class="minimize-btn" aria-label="Close Chat">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>

        <!-- Messages Area -->
        <div class="chat-body" id="chatMessages">
            <div class="message bot-message">
                <div class="message-content">
                    <p>👋 Hello! How can I assist you today?</p>
                    <span class="time">Now</span>
                </div>
            </div>
        </div>

        <!-- Fixed Bottom Section -->
        <div class="chat-bottom">
            <div class="chat-suggestions">
                <button data-query="Courses">Courses</button>
                <button data-query="Quizzes">Quizzes</button>
                <button data-query="About US">About US</button>
            </div>
            
            <div class="chat-input">
                <div class="input-actions">
                    <button class="upload-btn" aria-label="Upload File">
                        <i class="fas fa-paperclip"></i>
                    </button>
                    <button class="voice-btn" aria-label="Voice Input">
                        <i class="fas fa-microphone"></i>
                    </button>
                </div>
                <input type="text" id="userInput" placeholder="Type your message...">
                <button class="send-btn" id="sendBtn" disabled>
                    <i class="fas fa-paper-plane"></i>
                </button>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="definition.js"></script>
    <script src="take-quiz.js"></script>
    <script src="chat.js"></script>
    <div id="scriptsec"></div>
</body>
</html> 