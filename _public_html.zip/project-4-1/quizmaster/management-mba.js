// language-skills.js
class LanguageSkillsQuiz {
    constructor() {
        this.questions = {
            cat: [
                {
                    question: "What is CAT?",
                    options: ["Common Admission Test", "Computer Aptitude Test", "Common Aptitude Test", "Central Admission Test"],
                    correct: 0,
                    explanation: "CAT stands for Common Admission Test, the premier MBA entrance exam in India conducted by IIMs."
                },
                {
                    question: "Which section is NOT part of CAT?",
                    options: ["General Knowledge", "Quantitative Ability", "Verbal Ability", "Data Interpretation"],
                    correct: 0,
                    explanation: "CAT does not have a General Knowledge section. It tests QA, VA&RC, and DILR."
                },
                {
                    question: "What is the duration of CAT exam?",
                    options: ["180 minutes", "120 minutes", "240 minutes", "150 minutes"],
                    correct: 0,
                    explanation: "CAT exam duration is 180 minutes (3 hours) with sectional time limits."
                },
                {
                    question: "Which IIM conducts CAT 2023?",
                    options: ["IIM Lucknow", "IIM Ahmedabad", "IIM Bangalore", "IIM Calcutta"],
                    correct: 0,
                    explanation: "IIM Lucknow is the conducting institute for CAT 2023."
                },
                {
                    question: "What is the exam mode for CAT?",
                    options: ["Computer Based Test", "Paper Based Test", "Hybrid Mode", "Online Proctored"],
                    correct: 0,
                    explanation: "CAT is conducted as a Computer Based Test (CBT)."
                },
                {
                    question: "What is the marking scheme in CAT?",
                    options: ["3 marks for correct, -1 for incorrect", "4 marks for correct, -1 for incorrect", "2 marks for correct, -0.5 for incorrect", "1 mark for correct, no negative"],
                    correct: 0,
                    explanation: "CAT follows 3 marks for correct and -1 mark for incorrect answers."
                },
                {
                    question: "Which section typically has the highest cutoff?",
                    options: ["Quantitative Ability", "Verbal Ability", "Data Interpretation", "Logical Reasoning"],
                    correct: 0,
                    explanation: "Quantitative Ability section typically has the highest sectional cutoff in CAT."
                },
                {
                    question: "What is the validity of CAT score?",
                    options: ["1 year", "2 years", "3 years", "5 years"],
                    correct: 0,
                    explanation: "CAT score is valid for one year only."
                },
                {
                    question: "How many IIMs accept CAT score?",
                    options: ["20", "15", "10", "25"],
                    correct: 0,
                    explanation: "All 20 IIMs accept CAT score for their MBA admissions."
                },
                {
                    question: "What is the percentile system in CAT?",
                    options: ["99.99 percentile system", "100 percentile system", "90 percentile system", "95 percentile system"],
                    correct: 0,
                    explanation: "CAT follows a 99.99 percentile system for ranking candidates."
                }
            ],
            gmat: [
                {
                    question: "What is the full form of GMAT?",
                    options: ["Graduate Management Admission Test", "General Management Aptitude Test", "Global Management Admission Test", "Graduate Management Aptitude Test"],
                    correct: 0,
                    explanation: "GMAT stands for Graduate Management Admission Test."
                },
                {
                    question: "What is the total score range in GMAT?",
                    options: ["200-800", "0-1000", "0-500", "100-700"],
                    correct: 0,
                    explanation: "GMAT total scores range from 200 to 800."
                },
                {
                    question: "Which organization conducts GMAT?",
                    options: ["GMAC", "ETS", "Pearson", "Princeton"],
                    correct: 0,
                    explanation: "GMAT is conducted by Graduate Management Admission Council (GMAC)."
                },
                {
                    question: "What is the validity of GMAT score?",
                    options: ["5 years", "3 years", "2 years", "1 year"],
                    correct: 0,
                    explanation: "GMAT scores are valid for 5 years from the test date."
                },
                {
                    question: "Which section comes first in GMAT?",
                    options: ["Analytical Writing Assessment", "Quantitative", "Verbal", "Integrated Reasoning"],
                    correct: 0,
                    explanation: "The Analytical Writing Assessment (AWA) is the first section of GMAT."
                },
                {
                    question: "What is the duration of GMAT?",
                    options: ["3 hours 7 minutes", "4 hours", "2 hours 30 minutes", "3 hours 30 minutes"],
                    correct: 0,
                    explanation: "GMAT exam duration is 3 hours and 7 minutes."
                },
                {
                    question: "How many times can you take GMAT in a year?",
                    options: ["5 times", "3 times", "Unlimited", "Once"],
                    correct: 0,
                    explanation: "You can take GMAT up to 5 times in a rolling 12-month period."
                },
                {
                    question: "What is the waiting period between two GMAT attempts?",
                    options: ["16 days", "30 days", "45 days", "60 days"],
                    correct: 0,
                    explanation: "You must wait 16 calendar days between GMAT attempts."
                },
                {
                    question: "Which section has no negative marking?",
                    options: ["AWA", "Quantitative", "Verbal", "All have negative marking"],
                    correct: 0,
                    explanation: "The Analytical Writing Assessment (AWA) has no negative marking."
                },
                {
                    question: "What is the score range for AWA?",
                    options: ["0-6", "0-8", "0-10", "0-5"],
                    correct: 0,
                    explanation: "AWA scores range from 0 to 6 in half-point increments."
                }
            ],
            xat: [
                {
                    question: "What is XAT?",
                    options: ["Xavier Aptitude Test", "Xavier Admission Test", "Xavier Assessment Test", "Xavier Achievement Test"],
                    correct: 0,
                    explanation: "XAT stands for Xavier Aptitude Test, conducted by XLRI."
                },
                {
                    question: "Which institute conducts XAT?",
                    options: ["XLRI Jamshedpur", "XIM Bhubaneswar", "XIMB", "Xavier University"],
                    correct: 0,
                    explanation: "XAT is conducted by XLRI Jamshedpur."
                },
                {
                    question: "What is unique about XAT?",
                    options: ["Decision Making Section", "Technical Section", "Domain Knowledge", "Programming Section"],
                    correct: 0,
                    explanation: "XAT uniquely includes a Decision Making section unlike other MBA entrance exams."
                },
                {
                    question: "What is the duration of XAT?",
                    options: ["3 hours 10 minutes", "2 hours", "4 hours", "3 hours"],
                    correct: 0,
                    explanation: "XAT duration is 3 hours and 10 minutes."
                },
                {
                    question: "How many sections are there in XAT?",
                    options: ["4", "3", "5", "2"],
                    correct: 0,
                    explanation: "XAT has 4 sections: VA&LR, DM, QA&DI, and GK."
                },
                {
                    question: "What is the marking scheme in XAT?",
                    options: ["Positive and Negative", "Only Positive", "No marking", "Only Negative"],
                    correct: 0,
                    explanation: "XAT follows both positive and negative marking scheme."
                },
                {
                    question: "How many times is XAT conducted in a year?",
                    options: ["Once", "Twice", "Thrice", "Four times"],
                    correct: 0,
                    explanation: "XAT is conducted only once a year, usually in January."
                },
                {
                    question: "What is the mode of XAT exam?",
                    options: ["Computer Based", "Paper Based", "Hybrid", "Online Proctored"],
                    correct: 0,
                    explanation: "XAT is conducted in Computer Based Test (CBT) mode."
                },
                {
                    question: "Which section is optional in XAT?",
                    options: ["General Knowledge", "Decision Making", "Quantitative Ability", "Verbal Ability"],
                    correct: 0,
                    explanation: "The General Knowledge section is optional in XAT."
                },
                {
                    question: "What is the validity of XAT score?",
                    options: ["1 year", "2 years", "3 years", "5 years"],
                    correct: 0,
                    explanation: "XAT score is valid for one year only."
                }
            ]
        };

        this.currentModule = null;
        this.currentQuestionIndex = 0;
        this.userAnswers = new Map();
        this.hasAnswered = false;

        this.learningContent = {
            cat: {
                theory: `
                    <h4>CAT Exam Preparation</h4>
                    
                    <h5>1. Exam Pattern</h5>
                    <ul>
                        <li>Duration: 3 hours</li>
                        <li>Sections: QA, VARC, DILR</li>
                        <li>Total Questions: ~76</li>
                        <li>Marking: +3 for correct, -1 for incorrect</li>
                    </ul>

                    <h5>2. Important Topics</h5>
                    <ul>
                        <li>Quantitative Ability: Arithmetic, Algebra, Geometry</li>
                        <li>Verbal Ability: Reading Comprehension, Grammar</li>
                        <li>Data Interpretation: Charts, Graphs, Tables</li>
                        <li>Logical Reasoning: Puzzles, Sequences</li>
                    </ul>

                    <h5>3. Preparation Strategy</h5>
                    <ul>
                        <li>Regular Mock Tests</li>
                        <li>Sectional Practice</li>
                        <li>Time Management Skills</li>
                        <li>Concept Building</li>
                    </ul>
                `,
                examples: `
                    <h4>CAT Sample Questions</h4>

                    <h5>1. Quantitative Ability</h5>
                    <div class="example-box">
                        <p>If a² + b² = 25 and ab = 12, find the value of (a + b)²</p>
                        <p>Solution: (a + b)² = a² + b² + 2ab = 25 + 24 = 49</p>
                    </div>

                    <h5>2. Verbal Ability</h5>
                    <div class="example-box">
                        <p>Reading Comprehension passage with inference-based questions</p>
                    </div>
                `,
                practice: `
                    <h4>CAT Practice Questions</h4>

                    <div class="practice-exercise">
                        <h5>1. Data Interpretation</h5>
                        <div class="question">
                            <p>Analyze the given pie chart showing market share distribution</p>
                            <p>Practice calculating percentages and comparing values</p>
                        </div>

                        <h5>2. Logical Reasoning</h5>
                        <div class="question">
                            <p>Solve arrangement puzzles and sequence problems</p>
                            <p>Practice with different types of logical patterns</p>
                        </div>

                        <div class="tips">
                            <h5>Success Tips:</h5>
                            <ul>
                                <li>Focus on accuracy first, speed later</li>
                                <li>Practice with timed sections</li>
                                <li>Analyze mock test performance</li>
                                <li>Learn shortcuts and techniques</li>
                            </ul>
                        </div>
                    </div>
                `
            },
            gmat: {
                theory: `
                    <h4>GMAT Exam Preparation</h4>
                    
                    <h5>1. Test Structure</h5>
                    <ul>
                        <li>Duration: 3 hours 7 minutes</li>
                        <li>Sections: AWA, IR, Quant, Verbal</li>
                        <li>Score Range: 200-800</li>
                        <li>Adaptive Testing Format</li>
                    </ul>

                    <h5>2. Key Areas</h5>
                    <ul>
                        <li>Analytical Writing Assessment</li>
                        <li>Integrated Reasoning</li>
                        <li>Quantitative Reasoning</li>
                        <li>Verbal Reasoning</li>
                    </ul>

                    <h5>3. Study Plan</h5>
                    <ul>
                        <li>Official GMAT Resources</li>
                        <li>Practice Tests</li>
                        <li>Error Analysis</li>
                        <li>Timing Strategy</li>
                    </ul>
                `,
                examples: `
                    <h4>GMAT Sample Questions</h4>

                    <h5>1. Sentence Correction</h5>
                    <div class="example-box">
                        <p>Identify grammar errors and improve sentence structure</p>
                    </div>

                    <h5>2. Problem Solving</h5>
                    <div class="example-box">
                        <p>Mathematical reasoning and calculation questions</p>
                    </div>
                `,
                practice: `
                    <h4>GMAT Practice Questions</h4>

                    <div class="practice-exercise">
                        <h5>1. Critical Reasoning</h5>
                        <div class="question">
                            <p>Analyze arguments and identify assumptions</p>
                            <p>Practice strengthening/weakening arguments</p>
                        </div>

                        <h5>2. Data Sufficiency</h5>
                        <div class="question">
                            <p>Evaluate information adequacy</p>
                            <p>Practice with various problem types</p>
                        </div>

                        <div class="tips">
                            <h5>Exam Tips:</h5>
                            <ul>
                                <li>Master test-taking strategies</li>
                                <li>Time management is crucial</li>
                                <li>Understand scoring algorithm</li>
                                <li>Regular mock tests</li>
                            </ul>
                        </div>
                    </div>
                `
            },
            xat: {
                theory: `
                    <h4>XAT Exam Preparation</h4>
                    
                    <h5>1. Exam Format</h5>
                    <ul>
                        <li>Duration: 3 hours 10 minutes</li>
                        <li>Sections: VA&LR, DM, QA&DI, GK</li>
                        <li>Computer Based Test</li>
                        <li>Negative Marking</li>
                    </ul>

                    <h5>2. Unique Features</h5>
                    <ul>
                        <li>Decision Making Section</li>
                        <li>Essay Writing</li>
                        <li>General Knowledge</li>
                        <li>Integrated Questions</li>
                    </ul>

                    <h5>3. Preparation Approach</h5>
                    <ul>
                        <li>Section-wise Practice</li>
                        <li>Mock Tests</li>
                        <li>Current Affairs</li>
                        <li>Case Studies</li>
                    </ul>
                `,
                examples: `
                    <h4>XAT Sample Questions</h4>

                    <h5>1. Decision Making</h5>
                    <div class="example-box">
                        <p>Business scenario analysis and ethical dilemmas</p>
                    </div>

                    <h5>2. Quantitative Ability</h5>
                    <div class="example-box">
                        <p>Mathematical and analytical problems</p>
                    </div>
                `,
                practice: `
                    <h4>XAT Practice Questions</h4>

                    <div class="practice-exercise">
                        <h5>1. Verbal Ability</h5>
                        <div class="question">
                            <p>Reading comprehension and vocabulary</p>
                            <p>Grammar and language usage</p>
                        </div>

                        <h5>2. General Knowledge</h5>
                        <div class="question">
                            <p>Current affairs and business news</p>
                            <p>Static GK questions</p>
                        </div>

                        <div class="tips">
                            <h5>Preparation Tips:</h5>
                            <ul>
                                <li>Focus on decision making skills</li>
                                <li>Read business newspapers</li>
                                <li>Practice time management</li>
                                <li>Analyze previous year papers</li>
                            </ul>
                        </div>
                    </div>
                `
            }
        };

        this.initializeEventListeners();
        this.initializeTabs();
    }

    initializeEventListeners() {
        document.querySelectorAll('.start-quiz-btn').forEach(btn => {
            btn.addEventListener('click', () => this.startQuiz(btn.dataset.module));
        });

        document.getElementById('prevBtn').addEventListener('click', () => this.navigateQuestion(-1));
        document.getElementById('nextBtn').addEventListener('click', () => this.navigateQuestion(1));
        document.getElementById('askAIBtn').addEventListener('click', () => this.askAI());
        document.getElementById('resetBtn').addEventListener('click', () => this.resetQuiz());
        document.getElementById('viewResultsBtn').addEventListener('click', () => this.showResults());
    }

    initializeTabs() {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => this.switchTab(btn.dataset.tab));
        });
    }

    switchTab(tabId) {
        // Update active button
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabId);
        });

        // Show selected content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.style.display = content.id === tabId ? 'block' : 'none';
        });

        // Load content if not already loaded
        this.loadTabContent(tabId);
    }

    loadTabContent(tabId) {
        if (!this.currentModule) return;
        
        const contentDiv = document.querySelector(`#${tabId} > div`);
        contentDiv.innerHTML = this.learningContent[this.currentModule][tabId];
    }

    startQuiz(module) {
        this.currentModule = module;
        this.currentQuestionIndex = 0;
        this.userAnswers.clear();

        document.querySelector('.language-modules').style.display = 'none';
        document.querySelector('.quiz-section').style.display = 'block';

        document.getElementById('quizTitle').textContent = 
            `${module.charAt(0).toUpperCase() + module.slice(1)} Quiz`;

        this.loadQuestion();
        this.loadTabContent('theory');
        document.querySelector('.learning-content').style.display = 'block';
    }

    loadQuestion() {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        document.getElementById('questionText').textContent = question.question;

        const optionsContainer = document.querySelector('.options-container');
        optionsContainer.innerHTML = '';

        question.options.forEach((option, index) => {
            const optionElement = document.createElement('div');
            optionElement.className = 'option';
            optionElement.textContent = option;
            
            if (this.userAnswers.has(this.currentQuestionIndex)) {
                optionElement.classList.add('disabled');
                const userAnswer = this.userAnswers.get(this.currentQuestionIndex);
                const correctAnswer = question.correct;
                
                if (index === correctAnswer) {
                    optionElement.classList.add('correct');
                } else if (index === userAnswer && userAnswer !== correctAnswer) {
                    optionElement.classList.add('incorrect');
                }
            }

            optionElement.addEventListener('click', () => this.selectOption(index));
            optionsContainer.appendChild(optionElement);
        });

        this.updateProgress();

        // Hide feedback when loading new question
        document.querySelector('.result-feedback').style.display = 'none';
    }

    selectOption(index) {
        // If already answered, don't allow new selection
        if (this.userAnswers.has(this.currentQuestionIndex)) {
            return;
        }

        this.userAnswers.set(this.currentQuestionIndex, index);
        
        // Get the correct answer
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const correctIndex = question.correct;

        // Update options appearance
        document.querySelectorAll('.option').forEach((option, i) => {
            option.classList.add('disabled');
            if (i === correctIndex) {
                option.classList.add('correct');
            } else if (i === index && index !== correctIndex) {
                option.classList.add('incorrect');
            }
        });

        // Show immediate feedback
        this.showFeedback(index);
        
        // Show view results button if at least one question is answered
        this.hasAnswered = true;
        document.getElementById('viewResultsBtn').style.display = 'flex';
    }

    navigateQuestion(direction) {
        const newIndex = this.currentQuestionIndex + direction;
        if (newIndex >= 0 && newIndex < this.questions[this.currentModule].length) {
            this.currentQuestionIndex = newIndex;
            this.loadQuestion();
        }
    }

    updateProgress() {
        const total = this.questions[this.currentModule].length;
        document.getElementById('questionCounter').textContent = 
            `Question ${this.currentQuestionIndex + 1}/${total}`;

        const progress = ((this.currentQuestionIndex + 1) / total) * 100;
        document.querySelector('.progress').style.width = `${progress}%`;
    }

    askAI() {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const chatInput = document.querySelector('#userInput');
        const sendButton = document.querySelector('#sendBtn');
        const chatToggle = document.querySelector('#chatToggle');

        if (chatInput && sendButton && chatToggle) {
            const prompt = `Please explain this question and its answer:
                Question: ${question.question}
                Correct Answer: ${question.options[question.correct]}
                Explanation: ${question.explanation}`;

            chatInput.value = prompt;
            
            chatInput.dispatchEvent(new Event('input', { bubbles: true }));
            
            // Open chat if not already open
            if (!document.querySelector('.chat-widget.active')) {
                chatToggle.click();
            }

            // Trigger send
            sendButton.click();
        }
    }

    resetQuiz() {
        // Reset all state
        this.currentModule = null;
        this.currentQuestionIndex = 0;
        this.userAnswers.clear();

        // Show tutorials, hide quiz
        document.querySelector('.language-modules').style.display = 'grid';
        document.querySelector('.quiz-section').style.display = 'none';

        // Reset progress bar
        document.querySelector('.progress').style.width = '0%';

        // Optional: Scroll to top of tutorials
        document.querySelector('.tutorial-header').scrollIntoView({ 
            behavior: 'smooth',
            block: 'start'
        });
    }

    showFeedback(selectedIndex) {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const feedbackDiv = document.querySelector('.result-feedback');
        const feedbackText = feedbackDiv.querySelector('.feedback-text');
        const explanationText = feedbackDiv.querySelector('.explanation-text');
        
        const isCorrect = selectedIndex === question.correct;
        
        feedbackDiv.style.display = 'block';
        feedbackDiv.className = `result-feedback ${isCorrect ? 'correct' : 'incorrect'}`;
        
        feedbackText.textContent = isCorrect ? 
            'Correct Answer!' : 
            `Incorrect. The correct answer is: ${question.options[question.correct]}`;
        
        explanationText.textContent = question.explanation;
    }

    showResults() {
        const total = this.questions[this.currentModule].length;
        let correct = 0;
        
        this.userAnswers.forEach((answer, questionIndex) => {
            if (answer === this.questions[this.currentModule][questionIndex].correct) {
                correct++;
            }
        });

        const percentage = (correct / total) * 100;
        
        // Create results modal
        const modal = document.createElement('div');
        modal.className = 'results-modal';
        modal.innerHTML = `
            <div class="results-content">
                <h3>Quiz Results</h3>
                <div class="score-circle">
                    <span class="score-percentage">${percentage.toFixed(1)}%</span>
                    <span class="score-text">${correct} out of ${total}</span>
                </div>
                <button class="close-results">Close</button>
            </div>
        `;

        document.body.appendChild(modal);
        
        // Add close functionality
        modal.querySelector('.close-results').addEventListener('click', () => {
            modal.remove();
        });
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new LanguageSkillsQuiz();
});