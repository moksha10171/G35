<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('../assets/layout/header.php');
$footer = inancap('../assets/layout/footer.php');
$meta = inancap('../assets/layout/meta.php');
echo $meta;
$descript = 'Quizmaster - TalentSphere';
$title = 'TalentSphere';
echo generateMetaTags($title, $descript, '', '', 'Coding, Courses');
echo $header;
?>
    <main class="about-container">
        <section class="hero-section">
            <div class="hero-content">
                <h1>About QuizMaster</h1>
                <p>Empowering learners worldwide through interactive education</p>
            </div>
        </section>

        <section class="mission-section">
            <div class="section-content">
                <h2>Our Mission</h2>
                <p>To provide accessible, engaging, and effective learning experiences through innovative quiz-based education.</p>
                <div class="mission-grid">
                    <div class="mission-card">
                        <i class="fas fa-graduation-cap"></i>
                        <h3>Quality Education</h3>
                        <p>Delivering high-quality educational content across various subjects</p>
                    </div>
                    <div class="mission-card">
                        <i class="fas fa-users"></i>
                        <h3>Community Learning</h3>
                        <p>Building a supportive community of learners and educators</p>
                    </div>
                    <div class="mission-card">
                        <i class="fas fa-chart-line"></i>
                        <h3>Continuous Growth</h3>
                        <p>Supporting personal and professional development</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="team-section">
            <div class="section-content">
                <h2>Our Team</h2>
                <p>Meet the passionate individuals behind QuizMaster</p>
                <div class="team-grid">
                    <!-- Add team member cards here -->
                    <div class="team-card">
                        <img src="john-smith.jpg" alt="Team Member Name">
                        <h3>John Doe</h3>
                        <p>Founder & CEO</p>
                    </div>
                    <div class="team-card">
                        <img src="james-anderson.jpg" alt="Team Member Name">
                        <h3>Jane Smith</h3>
                        <p>Chief Technology Officer</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="values-section">
            <div class="section-content">
                <h2>Our Values</h2>
                <div class="values-grid">
                    <div class="value-card">
                        <i class="fas fa-lightbulb"></i>
                        <h3>Innovation</h3>
                        <p>Constantly improving our platform with cutting-edge technology</p>
                    </div>
                    <div class="value-card">
                        <i class="fas fa-handshake"></i>
                        <h3>Integrity</h3>
                        <p>Maintaining high standards of honesty and transparency</p>
                    </div>
                    <div class="value-card">
                        <i class="fas fa-heart"></i>
                        <h3>Passion</h3>
                        <p>Dedicated to making learning enjoyable and effective</p>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="main.js"></script>
    <script src="definition_index.js"></script>
    <script src="chat.js"></script>
    <script src="newsletter.js"></script>

<?php echo $footer;?>