<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('../assets/layout/header.php');
$footer = inancap('../assets/layout/footer.php');
$meta = inancap('../assets/layout/meta.php');
echo $meta;
$descript = 'Quizmaster - TalentSphere';
$title = 'TalentSphere';
echo generateMetaTags($title, $descript, '', '', 'Coding, Courses');
echo $header;
?>
    <link rel="stylesheet" href="language-skills.css">
    <main class="language-tutorial-container">
        <section class="tutorial-header">
            <h1>Engineering & Technology Skills Tutorial</h1>
            <p>Master essential Engineering & Technology skills with interactive lessons and quizzes</p>
        </section>

       
        <section class="language-modules">
            <div class="module-card">
                <div class="module-header">
                    <i class="fas fa-cogs"></i>
                    <h2>GATE Preparation</h2>
                </div>
                <div class="module-content">
                    <ul class="topic-list">
                        <li>Engineering Mathematics</li>
                        <li>Digital Logic</li>
                        <li>Computer Organization</li>
                        <li>Programming & Data Structures</li>
                    </ul>
                    <button class="start-quiz-btn" data-module="gate">Start Learning</button>
                </div>
            </div>

            <div class="module-card">
                <div class="module-header">
                    <i class="fas fa-laptop-code"></i>
                    <h2>IES Training</h2>
                </div>
                <div class="module-content">
                    <ul class="topic-list">
                        <li>General Studies</li>
                        <li>Engineering Mechanics</li>
                        <li>Thermodynamics</li>
                        <li>Engineering Materials</li>
                    </ul>
                    <button class="start-quiz-btn" data-module="ies">Start Learning</button>
                </div>
            </div>

            <div class="module-card">
                <div class="module-header">
                    <i class="fas fa-microchip"></i>
                    <h2>PSU Engineering</h2>
                </div>
                <div class="module-content">
                    <ul class="topic-list">
                        <li>Technical Aptitude</li>
                        <li>Core Engineering</li>
                        <li>Reasoning Skills</li>
                        <li>Interview Preparation</li>
                    </ul>
                    <button class="start-quiz-btn" data-module="psu">Start Learning</button>
                </div>
            </div>
        </section>
        <!-- Quiz Section -->
        <section class="quiz-section" style="display: none;">
            <div class="quiz-container">
                <div class="quiz-header">
                    <div class="quiz-header-content">
                        <h3 id="quizTitle">Grammar Quiz</h3>
                        <div class="quiz-progress">
                            <span id="questionCounter">Question 1/10</span>
                            <div class="progress-bar">
                                <div class="progress"></div>
                            </div>
                        </div>
                    </div>
                    <button id="viewResultsBtn" class="view-results-btn" style="display: none;">
                        <i class="fas fa-chart-bar"></i>
                        View Results
                    </button>
                </div>

                <div class="question-container">
                    <p id="questionText"></p>
                    <div class="options-container"></div>
                </div>

                <div class="result-feedback" style="display: none;">
                    <div class="feedback-header">
                        <div class="feedback-icons">
                            <i class="fas fa-check-circle correct-icon"></i>
                            <i class="fas fa-times-circle incorrect-icon"></i>
                        </div>
                        <span class="feedback-text"></span>
                    </div>
                    <div class="explanation-text"></div>
                </div>

                <div class="quiz-actions">
                    <button id="prevBtn">Previous</button>
                    <button id="nextBtn">Next</button>
                    <button id="askAIBtn">Ask AI</button>
                    <button id="resetBtn" class="reset-btn">
                        <i class="fas fa-arrow-left"></i>
                        Back to Tutorials
                    </button>
                </div>

                <div class="learning-content">
                    <h3>Learning Resources</h3>
                    <div class="content-tabs">
                        <button class="tab-btn active" data-tab="theory">Theory</button>
                        <button class="tab-btn" data-tab="examples">Examples</button>
                        <button class="tab-btn" data-tab="practice">Practice</button>
                    </div>
                    
                    <div class="tab-content" id="theory">
                        <div class="theory-content">
                            <!-- Content will be loaded dynamically -->
                        </div>
                    </div>
                    
                    <div class="tab-content" id="examples" style="display: none;">
                        <div class="examples-content">
                            <!-- Content will be loaded dynamically -->
                        </div>
                    </div>
                    
                    <div class="tab-content" id="practice" style="display: none;">
                        <div class="practice-exercises">
                            <!-- Content will be loaded dynamically -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="engineering-technology.js"></script>
    <script src="definition_index.js"></script>
    <script src="chat.js"></script>
    <script src="newsletter.js"></script>
    <script src="main.js"></script>
    <script src="newsletter.js"></script>

<?php echo $footer;?>