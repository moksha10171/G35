<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('../assets/layout/header.php');
$footer = inancap('../assets/layout/footer.php');
$meta = inancap('../assets/layout/meta.php');
echo $meta;
$descript = 'Quizmaster - TalentSphere';
$title = 'TalentSphere';
echo generateMetaTags($title, $descript, '', '', 'Coding, Courses');
echo $header;
?>
    <link rel="stylesheet" href="compiler-quiz.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <div class="compiler-container">
        <div class="compiler-header">
            <h2>Code Compiler</h2>
            <div class="header-actions">
                <button id="askAIBtn" class="ai-btn">
                    <i class="fas fa-robot"></i> Ask AI
                </button>
                <button id="solutionBtn" class="solution-btn">
                    <i class="fas fa-lightbulb"></i> View Solution
                </button>
                <button id="reviewBtn" class="review-btn">
                    <i class="fas fa-check-double"></i> Review Code
                </button>
            </div>
        </div>

        <div class="compiler-body">
            <div class="question-nav">
                <button id="prevBtn" class="nav-btn">
                    <i class="fas fa-arrow-left"></i> Previous
                </button>
                <span class="question-counter">Question 1/10</span>
                <button id="nextBtn" class="nav-btn">
                    Next <i class="fas fa-arrow-right"></i>
                </button>
            </div>

            <div class="question-display">
                <p id="questionText"></p>
                <p class="hint-text" id="hintText"></p>
            </div>

            <div class="split-view">
                <div class="editor-section">
                    <div class="output-header">
                        <h3>Input</h3>
                    </div>
                    <div class="editor-container">
                        <div id="codeEditor" class="editor active"></div>
                    </div>
                </div>

                <div class="output-section">
                    <div class="output-header">
                        <h3>Output</h3>
                        <div class="output-actions">
                            <button id="runBtn" class="run-btn">
                                <i class="fas fa-play"></i> Run Code
                            </button>
                        </div>
                    </div>
                    <iframe id="outputFrame" class="output-frame"></iframe>
                </div>
            </div>
        </div>
    </div>
   
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/xml/xml.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/css/css.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/javascript/javascript.min.js"></script>
    <script src="compiler-quiz.js"></script>
    <script src="definition_index.js"></script>
    <script src="chat.js"></script>
    <script src="main.js"></script>

<?php echo $footer;?>