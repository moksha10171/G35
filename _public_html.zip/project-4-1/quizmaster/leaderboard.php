<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('../assets/layout/header.php');
$footer = inancap('../assets/layout/footer.php');
$meta = inancap('../assets/layout/meta.php');
echo $meta;
$descript = 'Quizmaster - TalentSphere';
$title = 'TalentSphere';
echo generateMetaTags($title, $descript, '', '', 'Coding, Courses');
echo $header;
?>
    <main class="leaderboard-container">
        <div class="leaderboard-header">
            <h1>Global Leaderboard</h1>
            <p>See how you rank against other quiz masters</p>
            
            <div class="leaderboard-filters">
                <select id="categoryFilter" class="filter-select">
                    <option value="all">All Categories</option>
                    <option value="python">Python</option>
                    <option value="javascript">JavaScript</option>
                    <!-- Add more categories -->
                </select>
                
                <select id="timeFilter" class="filter-select">
                    <option value="all-time">All Time</option>
                    <option value="this-month">This Month</option>
                    <option value="this-week">This Week</option>
                    <option value="today">Today</option>
                </select>
            </div>
        </div>

        <div class="leaderboard-content">
            <!-- Top 3 Winners Section -->
            <div class="top-winners">
                <!-- Second Place -->
                <div class="winner second-place">
                    <div class="position"><i class="fas fa-medal"></i> 2</div>
                    <div class="avatar">
                        <img src="path/to/avatar2.jpg" alt="Second Place">
                    </div>
                    <div class="name">Sarah Johnson</div>
                    <div class="score">980 pts</div>
                </div>

                <!-- First Place -->
                <div class="winner first-place">
                    <div class="position"><i class="fas fa-crown"></i> 1</div>
                    <div class="avatar">
                        <img src="path/to/avatar1.jpg" alt="First Place">
                    </div>
                    <div class="name">John Doe</div>
                    <div class="score">1250 pts</div>
                </div>

                <!-- Third Place -->
                <div class="winner third-place">
                    <div class="position"><i class="fas fa-medal"></i> 3</div>
                    <div class="avatar">
                        <img src="path/to/avatar3.jpg" alt="Third Place">
                    </div>
                    <div class="name">Mike Smith</div>
                    <div class="score">850 pts</div>
                </div>
            </div>

            <!-- Rankings Table -->
            <div class="rankings-table">
                <div class="table-header">
                    <div class="rank">Rank</div>
                    <div class="player">Player</div>
                    <div class="category">Category</div>
                    <div class="quizzes">Quizzes</div>
                    <div class="accuracy">Accuracy</div>
                    <div class="time">Time Spent</div>
                    <div class="points">Points</div>
                </div>
                
                <div class="table-body">
                    <!-- Table rows will be populated by JavaScript -->
                </div>
            </div>

            <!-- Pagination -->
            <div class="pagination">
                <button class="page-btn" data-page="prev"><i class="fas fa-chevron-left"></i></button>
                <div class="page-numbers">
                    <button class="page-btn active">1</button>
                    <button class="page-btn">2</button>
                    <button class="page-btn">3</button>
                    <span class="ellipsis">...</span>
                    <button class="page-btn">10</button>
                </div>
                <button class="page-btn" data-page="next"><i class="fas fa-chevron-right"></i></button>
            </div>
        </div>
    </main>

    <script src="main.js"></script>
    <script src="leaderboard.js"></script>
    <script src="newsletter.js"></script>

<?php echo $footer;?>