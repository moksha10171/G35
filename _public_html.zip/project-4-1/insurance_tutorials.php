<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('assets/layout/header.php');
$footer = inancap('assets/layout/footer.php');
$meta = inancap('assets/layout/meta.php');
echo $meta;
$descript = 'Insurance Professional Tutorials - Comprehensive Insurance Training';
$title = 'Insurance Professional Tutorials';
echo generateMetaTags($title, $descript, '', '', 'Insurance Training, Property Insurance, Casualty Insurance, Life Insurance, Health Insurance');
echo $header;
?>

<main id="main-content">
    <!-- Tutorial Hero Section -->
    <section class="tutorial-hero">
        <div class="container">
            <div class="hero-content">
                <span class="category-badge">Insurance Professional</span>
                <h1>Insurance Professional Training</h1>
                <p>Master comprehensive insurance concepts, industry practices, and professional skills with our detailed tutorials.</p>
            </div>
        </div>
    </section>

    <!-- Tutorial Navigation -->
    <section class="tutorial-navigation">
        <div class="container">
            <nav class="course-nav">
                <ul>
                    <li><a href="#property-casualty">Property & Casualty</a></li>
                    <li><a href="#life-health">Life & Health</a></li>
                    <li><a href="#risk-management">Risk Management</a></li>
                    <li><a href="#claims">Claims Processing</a></li>
                </ul>
            </nav>
        </div>
    </section>

    <!-- Tutorial Categories -->
    <section class="tutorial-categories">
        <div class="container">
            <!-- Property & Casualty Section -->
            <div id="property-casualty" class="tutorial-section">
                <div class="section-header">
                    <h2>Property & Casualty Insurance</h2>
                    <p>Learn about property and casualty insurance fundamentals and advanced concepts.</p>
                </div>
                
                <div class="tutorials-grid">
                    <!-- Tutorial Cards -->
                    <div class="tutorial-card" data-aos="fade-up" data-aos-delay="100">
                        <div class="card-header">
                            <i class="fas fa-home"></i>
                            <h3>Property Insurance Basics</h3>
                        </div>
                        <div class="card-content">
                            <p>Understanding fundamental concepts of property insurance coverage.</p>
                            <ul class="tutorial-topics">
                                <li>Types of Property Insurance</li>
                                <li>Coverage Components</li>
                                <li>Policy Exclusions</li>
                                <li>Valuation Methods</li>
                            </ul>
                            <a href="/tutorials/property-insurance-basics" class="btn-tutorial">Start Learning</a>
                        </div>
                    </div>

                    <div class="tutorial-card" data-aos="fade-up" data-aos-delay="200">
                        <div class="card-header">
                            <i class="fas fa-car"></i>
                            <h3>Auto Insurance</h3>
                        </div>
                        <div class="card-content">
                            <p>Comprehensive guide to auto insurance policies and coverage.</p>
                            <ul class="tutorial-topics">
                                <li>Liability Coverage</li>
                                <li>Collision Coverage</li>
                                <li>Comprehensive Coverage</li>
                                <li>Policy Endorsements</li>
                            </ul>
                            <a href="/tutorials/auto-insurance" class="btn-tutorial">Start Learning</a>
                        </div>
                    </div>

                    <div class="tutorial-card" data-aos="fade-up" data-aos-delay="300">
                        <div class="card-header">
                            <i class="fas fa-building"></i>
                            <h3>Commercial Property Insurance</h3>
                        </div>
                        <div class="card-content">
                            <p>Learn about commercial property coverage and risk assessment.</p>
                            <ul class="tutorial-topics">
                                <li>Business Property Coverage</li>
                                <li>Business Interruption</li>
                                <li>Equipment Breakdown</li>
                                <li>Commercial Liability</li>
                            </ul>
                            <div class="progress-indicator" data-progress="0">
                                <div class="progress-bar">
                                    <div class="progress-fill"></div>
                                </div>
                                <span class="progress-text">0% Complete</span>
                            </div>
                            <a href="/tutorials/commercial-property" class="btn-tutorial" data-tutorial="commercial-property">Start Learning</a>
                        </div>
                    </div>

                    <div class="tutorial-card" data-aos="fade-up" data-aos-delay="400">
                        <div class="card-header">
                            <i class="fas fa-umbrella"></i>
                            <h3>Liability Insurance</h3>
                        </div>
                        <div class="card-content">
                            <p>Master liability insurance concepts and coverage types.</p>
                            <ul class="tutorial-topics">
                                <li>General Liability</li>
                                <li>Professional Liability</li>
                                <li>Product Liability</li>
                                <li>Umbrella Coverage</li>
                            </ul>
                            <div class="progress-indicator" data-progress="0">
                                <div class="progress-bar">
                                    <div class="progress-fill"></div>
                                </div>
                                <span class="progress-text">0% Complete</span>
                            </div>
                            <a href="/tutorials/liability-insurance" class="btn-tutorial" data-tutorial="liability">Start Learning</a>
                        </div>
                    </div>

                    <!-- Add more Property & Casualty tutorial cards -->
                </div>
            </div>

            <!-- Life & Health Section -->
            <div id="life-health" class="tutorial-section">
                <div class="section-header">
                    <h2>Life & Health Insurance</h2>
                    <p>Explore life and health insurance products and regulations.</p>
                </div>
                
                <div class="tutorials-grid">
                    <div class="tutorial-card" data-aos="fade-up" data-aos-delay="100">
                        <div class="card-header">
                            <i class="fas fa-heartbeat"></i>
                            <h3>Health Insurance Fundamentals</h3>
                        </div>
                        <div class="card-content">
                            <p>Understanding health insurance policies and coverage types.</p>
                            <ul class="tutorial-topics">
                                <li>Types of Health Plans</li>
                                <li>Coverage Benefits</li>
                                <li>Network Providers</li>
                                <li>Claims Processing</li>
                            </ul>
                            <a href="/tutorials/health-insurance-fundamentals" class="btn-tutorial">Start Learning</a>
                        </div>
                    </div>

                    <div class="tutorial-card" data-aos="fade-up" data-aos-delay="200">
                        <div class="card-header">
                            <i class="fas fa-user-shield"></i>
                            <h3>Life Insurance Products</h3>
                        </div>
                        <div class="card-content">
                            <p>Comprehensive guide to life insurance products and planning.</p>
                            <ul class="tutorial-topics">
                                <li>Term Life Insurance</li>
                                <li>Whole Life Insurance</li>
                                <li>Universal Life</li>
                                <li>Estate Planning</li>
                            </ul>
                            <div class="progress-indicator" data-progress="0">
                                <div class="progress-bar">
                                    <div class="progress-fill"></div>
                                </div>
                                <span class="progress-text">0% Complete</span>
                            </div>
                            <a href="/tutorials/life-insurance" class="btn-tutorial" data-tutorial="life">Start Learning</a>
                        </div>
                    </div>

                    <!-- Add more Life & Health tutorial cards -->
                </div>
            </div>

            <!-- Risk Management Section -->
            <div id="risk-management" class="tutorial-section">
                <div class="section-header">
                    <h2>Risk Management</h2>
                    <p>Learn advanced risk management techniques and strategies.</p>
                </div>
                
                <div class="tutorials-grid">
                    <div class="tutorial-card" data-aos="fade-up" data-aos-delay="100">
                        <div class="card-header">
                            <i class="fas fa-chart-line"></i>
                            <h3>Risk Assessment</h3>
                        </div>
                        <div class="card-content">
                            <p>Master risk assessment methodologies and tools.</p>
                            <ul class="tutorial-topics">
                                <li>Risk Identification</li>
                                <li>Risk Analysis</li>
                                <li>Risk Evaluation</li>
                                <li>Risk Treatment</li>
                            </ul>
                            <div class="progress-indicator" data-progress="0">
                                <div class="progress-bar">
                                    <div class="progress-fill"></div>
                                </div>
                                <span class="progress-text">0% Complete</span>
                            </div>
                            <a href="/tutorials/risk-assessment" class="btn-tutorial" data-tutorial="risk-assessment">Start Learning</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Claims Processing Section -->
            <div id="claims" class="tutorial-section">
                <div class="section-header">
                    <h2>Claims Processing & Management</h2>
                    <p>Master the art of efficient claims processing and learn industry-standard practices.</p>
                </div>
                
                <div class="tutorials-grid">
                    <div class="tutorial-card" data-aos="fade-up" data-aos-delay="100">
                        <div class="card-header">
                            <i class="fas fa-file-invoice-dollar"></i>
                            <h3>Claims Processing Fundamentals</h3>
                        </div>
                        <div class="card-content">
                            <p>Learn the essential steps and procedures in insurance claims processing.</p>
                            <ul class="tutorial-topics">
                                <li>Claims Intake Process</li>
                                <li>Documentation Requirements</li>
                                <li>Coverage Verification</li>
                                <li>Initial Assessment</li>
                            </ul>
                            <div class="progress-indicator" data-progress="0">
                                <div class="progress-bar">
                                    <div class="progress-fill"></div>
                                </div>
                                <span class="progress-text">0% Complete</span>
                            </div>
                            <a href="/tutorials/claims-fundamentals" class="btn-tutorial" data-tutorial="claims-basics">Start Learning</a>
                        </div>
                    </div>

                    <div class="tutorial-card" data-aos="fade-up" data-aos-delay="200">
                        <div class="card-header">
                            <i class="fas fa-calculator"></i>
                            <h3>Claims Investigation & Evaluation</h3>
                        </div>
                        <div class="card-content">
                            <p>Master techniques for thorough claims investigation and accurate evaluation.</p>
                            <ul class="tutorial-topics">
                                <li>Investigation Methods</li>
                                <li>Damage Assessment</li>
                                <li>Liability Determination</li>
                                <li>Settlement Calculation</li>
                            </ul>
                            <div class="progress-indicator" data-progress="0">
                                <div class="progress-bar">
                                    <div class="progress-fill"></div>
                                </div>
                                <span class="progress-text">0% Complete</span>
                            </div>
                            <a href="/tutorials/claims-investigation" class="btn-tutorial" data-tutorial="claims-investigation">Start Learning</a>
                        </div>
                    </div>

                    <div class="tutorial-card" data-aos="fade-up" data-aos-delay="300">
                        <div class="card-header">
                            <i class="fas fa-handshake"></i>
                            <h3>Settlement Negotiations</h3>
                        </div>
                        <div class="card-content">
                            <p>Learn effective negotiation strategies for fair claim settlements.</p>
                            <ul class="tutorial-topics">
                                <li>Negotiation Techniques</li>
                                <li>Settlement Options</li>
                                <li>Dispute Resolution</li>
                                <li>Documentation & Closure</li>
                            </ul>
                            <div class="progress-indicator" data-progress="0">
                                <div class="progress-bar">
                                    <div class="progress-fill"></div>
                                </div>
                                <span class="progress-text">0% Complete</span>
                            </div>
                            <a href="/tutorials/settlement-negotiations" class="btn-tutorial" data-tutorial="settlements">Start Learning</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Progress Tracking -->
    <section class="progress-section">
        <div class="container">
            <div class="progress-wrapper">
                <h2>Your Learning Progress</h2>
                <div class="progress-stats">
                    <div class="progress-item">
                        <span class="progress-label">Completed Tutorials</span>
                        <div class="progress-bar">
                            <div class="progress" style="width: 45%"></div>
                        </div>
                        <span class="progress-value">45%</span>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php echo $footer; ?> 