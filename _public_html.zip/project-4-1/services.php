<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('assets/layout/header.php');
$footer = inancap('assets/layout/footer.php');
$meta = inancap('assets/layout/meta.php');
echo $meta;
$descript = 'TalentSphere Services - Innovative Solutions for Insurance Hiring';
$title = 'TalentSphere Services - Innovative Solutions for Insurance Hiring';
echo generateMetaTags($title, $descript, '', '', 'Coding, Courses');
echo $header;
?>
    <main id="main-content">
        <!-- Hero Section -->
        <section class="services-hero">
            <div class="container">
                <div class="hero-content">
                    <span class="hero-tag">Our Services</span>
                    <h1>Comprehensive Insurance Recruitment Solutions</h1>
                    <p>Transform your hiring process with our AI-powered platform and expert services</p>
                    <div class="hero-cta">
                        <a href="#contact" class="btn btn-primary">Get Started</a>
                        <a href="#services" class="btn btn-secondary">Explore Services</a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Core Services Section -->
        <section id="services" class="core-services">
            <div class="container">
                <div class="section-header">
                    <span class="section-tag">What We Offer</span>
                    <h2>Our Core Services</h2>
                    <p>Discover our comprehensive suite of recruitment solutions designed for the insurance industry</p>
                </div>

                <div class="services-grid">
                    <!-- Talent Acquisition -->
                    <div class="service-card" data-aos="fade-up">
                        <div class="service-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <h3>Talent Acquisition</h3>
                        <p>Strategic recruitment solutions tailored for insurance professionals</p>
                        <ul class="service-features">
                            <li><i class="fas fa-check"></i> AI-Powered Matching</li>
                            <li><i class="fas fa-check"></i> Custom Screening Process</li>
                            <li><i class="fas fa-check"></i> Industry-Specific Assessment</li>
                        </ul>
                        <a href="#" class="service-link">Learn More <i class="fas fa-arrow-right"></i></a>
                    </div>

                    <!-- Compliance Management -->
                    <div class="service-card" data-aos="fade-up" data-aos-delay="100">
                        <div class="service-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h3>Compliance Management</h3>
                        <p>Ensure regulatory compliance throughout the hiring process</p>
                        <ul class="service-features">
                            <li><i class="fas fa-check"></i> License Verification</li>
                            <li><i class="fas fa-check"></i> Background Checks</li>
                            <li><i class="fas fa-check"></i> Regulatory Updates</li>
                        </ul>
                        <a href="#" class="service-link">Learn More <i class="fas fa-arrow-right"></i></a>
                    </div>

                    <!-- Training & Development -->
                    <div class="service-card" data-aos="fade-up" data-aos-delay="200">
                        <div class="service-icon">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <h3>Training & Development</h3>
                        <p>Comprehensive training programs for insurance professionals</p>
                        <ul class="service-features">
                            <li><i class="fas fa-check"></i> Skill Enhancement</li>
                            <li><i class="fas fa-check"></i> Certification Programs</li>
                            <li><i class="fas fa-check"></i> Ongoing Support</li>
                        </ul>
                        <a href="#" class="service-link">Learn More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Process Section -->
        <section class="process-section">
            <div class="container">
                <div class="section-header">
                    <span class="section-tag">How It Works</span>
                    <h2>Our Recruitment Process</h2>
                    <p>A streamlined approach to finding the perfect match for your organization</p>
                </div>

                <div class="process-steps">
                    <div class="step-card" data-aos="fade-right">
                        <div class="step-number">01</div>
                        <h3>Initial Consultation</h3>
                        <p>We understand your specific needs and requirements</p>
                    </div>

                    <div class="step-card" data-aos="fade-right" data-aos-delay="100">
                        <div class="step-number">02</div>
                        <h3>Candidate Sourcing</h3>
                        <p>AI-powered matching to find ideal candidates</p>
                    </div>

                    <div class="step-card" data-aos="fade-right" data-aos-delay="200">
                        <div class="step-number">03</div>
                        <h3>Screening & Assessment</h3>
                        <p>Thorough evaluation of candidates' qualifications</p>
                    </div>

                    <div class="step-card" data-aos="fade-right" data-aos-delay="300">
                        <div class="step-number">04</div>
                        <h3>Placement & Support</h3>
                        <p>Successful placement and ongoing assistance</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Contact Section -->
        <section id="contact" class="contact-section">
            <div class="container">
                <div class="contact-wrapper">
                    <div class="contact-content">
                        <span class="section-tag">Get Started</span>
                        <h2>Transform Your Hiring Process Today</h2>
                        <p>Schedule a consultation with our recruitment experts</p>
                        <div class="contact-info">
                            <div class="info-item">
                                <i class="fas fa-phone"></i>
                                <span>+1 (555) 123-4567</span>
                            </div>
                            <div class="info-item">
                                <i class="fas fa-envelope"></i>
                                <span>contact@talentsphere.com</span>
                            </div>
                        </div>
                    </div>
                    <form class="contact-form">
                        <div class="form-group">
                            <input type="text" placeholder="Your Name" required>
                        </div>
                        <div class="form-group">
                            <input type="email" placeholder="Your Email" required>
                        </div>
                        <div class="form-group">
                            <select required>
                                <option value="">Select Service</option>
                                <option value="talent-acquisition">Talent Acquisition</option>
                                <option value="compliance">Compliance Management</option>
                                <option value="training">Training & Development</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <textarea placeholder="Your Message" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Send Message</button>
                    </form>
                </div>
            </div>
        </section>
    </main>
<?php echo $footer;?>