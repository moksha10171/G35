<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('assets/layout/header.php');
$footer = inancap('assets/layout/footer.php');
$meta = inancap('assets/layout/meta.php');
echo $meta;
$descript = 'Master Essential Employment Skills - Career Development Program';
$title = 'Employment Skills Training';
echo generateMetaTags($title, $descript, '', '', 'Employment Skills, Career Development, Professional Growth');
echo $header;
?>

<main class="employment-skills-hub" data-category="employment-skills">
    <!-- Enhanced Hero Section -->
    <section class="category-hero employment-hero">
        <div class="container">
            <div class="hero-content">
                <div class="hero-text">
                    <h1>Master Essential Employment Skills</h1>
                    <p class="hero-subtitle">Transform your career journey with comprehensive professional development resources</p>
                    <div class="hero-actions">
                        <a href="#skill-tracks" class="btn-primary">Explore Skill Tracks</a>
                        <a href="#assessment" class="btn-secondary">Take Skill Assessment</a>
                    </div>
                </div>
                <div class="hero-stats">
                    <div class="stat-card">
                        <span class="stat-number">25+</span>
                        <span class="stat-label">Skill Courses</span>
                    </div>
                    <div class="stat-card">
                        <span class="stat-number">10k+</span>
                        <span class="stat-label">Success Stories</span>
                    </div>
                    <div class="stat-card">
                        <span class="stat-number">98%</span>
                        <span class="stat-label">Success Rate</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Skill Tracks Section -->
    <section id="skill-tracks" class="skill-tracks">
        <div class="container">
            <div class="section-header">
                <h2>Career Development Tracks</h2>
                <p>Choose your specialized learning path based on your career goals</p>
            </div>

            <div class="tracks-grid">
                <!-- Career Preparation Track -->
                <div class="track-card">
                    <div class="track-header">
                        <div class="track-icon">
                            <i class="fas fa-rocket"></i>
                        </div>
                        <div class="track-meta">
                            <h3>Career Launch</h3>
                            <span class="duration">8 Weeks</span>
                        </div>
                    </div>
                    <div class="track-content">
                        <ul class="track-modules">
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <span>Professional Resume Building</span>
                            </li>
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <span>Interview Mastery</span>
                            </li>
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <span>Personal Branding</span>
                            </li>
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <span>Job Search Strategies</span>
                            </li>
                        </ul>
                        <div class="track-footer">
                            <a href="/tracks/career-launch" class="btn-track">Start Track</a>
                            <span class="track-price">$199</span>
                        </div>
                    </div>
                    <div class="track-progress">
                        <div class="progress-bar">
                            <div class="progress" style="width: 0%"></div>
                        </div>
                        <span class="progress-text">0% Complete</span>
                    </div>
                </div>

                <!-- Professional Growth Track -->
                <div class="track-card featured">
                    <div class="track-header">
                        <div class="track-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div class="track-meta">
                            <h3>Professional Excellence</h3>
                            <span class="duration">12 Weeks</span>
                        </div>
                    </div>
                    <div class="track-content">
                        <ul class="track-modules">
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <span>Leadership Development</span>
                            </li>
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <span>Business Communication</span>
                            </li>
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <span>Project Management</span>
                            </li>
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <span>Strategic Thinking</span>
                            </li>
                        </ul>
                        <div class="track-footer">
                            <a href="/tracks/professional-excellence" class="btn-track">Start Track</a>
                            <span class="track-price">$299</span>
                        </div>
                    </div>
                    <div class="track-progress">
                        <div class="progress-bar">
                            <div class="progress" style="width: 0%"></div>
                        </div>
                        <span class="progress-text">0% Complete</span>
                    </div>
                </div>

                <!-- Career Transition Track -->
                <div class="track-card">
                    <div class="track-header">
                        <div class="track-icon">
                            <i class="fas fa-sync-alt"></i>
                        </div>
                        <div class="track-meta">
                            <h3>Career Transition</h3>
                            <span class="duration">10 Weeks</span>
                        </div>
                    </div>
                    <div class="track-content">
                        <ul class="track-modules">
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <span>Skills Assessment</span>
                            </li>
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <span>Industry Analysis</span>
                            </li>
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <span>Networking Strategies</span>
                            </li>
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <span>Career Planning</span>
                            </li>
                        </ul>
                        <div class="track-footer">
                            <a href="/tracks/career-transition" class="btn-track">Start Track</a>
                            <span class="track-price">$249</span>
                        </div>
                    </div>
                    <div class="track-progress">
                        <div class="progress-bar">
                            <div class="progress" style="width: 0%"></div>
                        </div>
                        <span class="progress-text">0% Complete</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Featured Workshops Section -->
    <section class="featured-workshops">
        <div class="container">
            <div class="section-header">
                <h2>Live Workshops</h2>
                <p>Interactive sessions with industry experts</p>
            </div>

            <div class="workshops-slider">
                <!-- Workshop Cards -->
                <div class="workshop-card">
                    <div class="workshop-date">
                        <span class="month">JUN</span>
                        <span class="day">15</span>
                    </div>
                    <div class="workshop-details">
                        <h3>Interview Success Masterclass</h3>
                        <p>Master behavioral interviews and salary negotiations</p>
                        <div class="workshop-meta">
                            <span><i class="fas fa-clock"></i> 2 hours</span>
                            <span><i class="fas fa-users"></i> 50 spots</span>
                        </div>
                        <a href="#register" class="btn-workshop">Register Now</a>
                    </div>
                    <div class="workshop-badge">
                        <span>Live</span>
                    </div>
                </div>
                <!-- Add more workshop cards -->
            </div>
        </div>
    </section>

    <!-- Success Stories Section -->
    <section class="success-stories">
        <div class="container">
            <div class="section-header">
                <h2>Success Stories</h2>
                <p>Real outcomes from our learners</p>
            </div>

            <div class="stories-grid">
                <!-- Success Story Cards -->
                <div class="story-card">
                    <div class="story-image">
                        <img src="/assets/images/success-stories/story1.jpg" alt="Success Story">
                    </div>
                    <div class="story-content">
                        <blockquote>
                            "The career transition program helped me successfully switch industries and increase my salary by 40%."
                        </blockquote>
                        <div class="story-author">
                            <strong>Sarah Johnson</strong>
                            <span>Marketing to Tech</span>
                        </div>
                    </div>
                    <div class="story-metrics">
                        <span><i class="fas fa-briefcase"></i> Career Change</span>
                        <span><i class="fas fa-chart-line"></i> 40% Salary Increase</span>
                    </div>
                </div>
                <!-- Add more success stories -->
            </div>
        </div>
    </section>

    <!-- Career Resources Section -->
    <section class="career-resources">
        <div class="container">
            <div class="resources-grid">
                <div class="resource-card">
                    <i class="fas fa-file-alt"></i>
                    <h3>Resume Templates</h3>
                    <p>Industry-specific resume templates</p>
                    <a href="#templates">Access Templates</a>
                </div>
                <!-- Add more resource cards -->
            </div>
        </div>
    </section>
</main>

<!-- Add custom styles -->
<link href="/assets/styles/employment-skills.css" rel="stylesheet">
<!-- Add custom scripts -->
<script src="/assets/js/employment-skills.js"></script>

<?php echo $footer; ?> 