<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('assets/layout/header.php');
$footer = inancap('assets/layout/footer.php');
$meta = inancap('assets/layout/meta.php');
echo $meta;
$descript = 'TalentSphere - Connecting Talent with Opportunity';
$title = 'TalentSphere';
echo generateMetaTags($title, $descript, '', '', 'Coding, Courses');
echo $header;
?>
<main>
        <section class="hero">
            <div class="container">
                <div class="hero-content">
                    <h1>Revolutionize Your Hiring Process</h1>
                    <p>Connect with top-tier agents and streamline recruitment in the insurance industry</p>
                    <div class="hero-cta">
                        <a href="#" class="btn btn-primary btn-large">Get Started</a>
                        <a href="#" class="btn btn-secondary btn-large">Learn More</a>
                    </div>
                </div>
                <div class="hero-image">
                    <img src="/project-4-1/assets/images/insurance.png" alt="TalentSphere hiring process illustration">
                </div>
            </div>
        </section>

        <section class="stats-section">
            <div class="container">
                <div class="stats-header">
                    <span class="stats-tag">Our Impact in Numbers</span>
                    <h2>Transforming Insurance Recruitment</h2>
                    <p>Our achievements in connecting talented professionals with outstanding opportunities</p>
                </div>
                
                <div class="stats-grid">
                    <div class="stat-card" data-aos="fade-up">
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <span class="stat-number">5000+</span>
                        <h3 class="stat-label">Professionals Placed</h3>
                        <p class="stat-description">Successfully matched with their ideal roles</p>
                    </div>
                    
                    <div class="stat-card" data-aos="fade-up" data-aos-delay="100">
                        <div class="stat-icon">
                            <i class="fas fa-building"></i>
                        </div>
                        <span class="stat-number">200+</span>
                        <h3 class="stat-label">Partner Companies</h3>
                        <p class="stat-description">Leading insurance firms trust us</p>
                    </div>
                    
                    <div class="stat-card" data-aos="fade-up" data-aos-delay="200">
                        <div class="stat-icon">
                            <i class="fas fa-globe"></i>
                        </div>
                        <span class="stat-number">20+</span>
                        <h3 class="stat-label">Countries</h3>
                        <p class="stat-description">Global presence and reach</p>
                    </div>
                    
                    <div class="stat-card" data-aos="fade-up" data-aos-delay="300">
                        <div class="stat-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <span class="stat-number">95%</span>
                        <h3 class="stat-label">Success Rate</h3>
                        <p class="stat-description">Placement satisfaction rate</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="features">
            <div class="container">
                <div class="features-header">
                    <span class="features-tag">Platform Benefits</span>
                    <h2>Why Choose Our Platform?</h2>
                    <p class="features-subtitle">Discover how our comprehensive suite of tools revolutionizes insurance recruitment</p>
                </div>

                <div class="features-wrapper">
                    <div class="features-grid">
                        <div class="feature-card">
                            <div class="feature-icon-wrapper">
                                <div class="feature-icon">
                                    <i class="fas fa-robot"></i>
                                </div>
                            </div>
                            <div class="feature-content">
                                <h3>AI-Powered Matching</h3>
                                <p>Smart algorithms that match candidates based on skills, experience, and cultural fit.</p>
                                <ul class="feature-list">
                                    <li><i class="fas fa-check"></i> Precision matching</li>
                                    <li><i class="fas fa-check"></i> Behavioral analysis</li>
                                    <li><i class="fas fa-check"></i> Skills verification</li>
                                </ul>
                            </div>
                        </div>

                        <div class="feature-card">
                            <div class="feature-icon-wrapper">
                                <div class="feature-icon">
                                    <i class="fas fa-chart-line"></i>
                                </div>
                            </div>
                            <div class="feature-content">
                                <h3>Advanced Analytics</h3>
                                <p>Comprehensive insights and reporting tools for data-driven decisions.</p>
                                <ul class="feature-list">
                                    <li><i class="fas fa-check"></i> Real-time metrics</li>
                                    <li><i class="fas fa-check"></i> Performance tracking</li>
                                    <li><i class="fas fa-check"></i> Custom reports</li>
                                </ul>
                            </div>
                        </div>

                        <div class="feature-card">
                            <div class="feature-icon-wrapper">
                                <div class="feature-icon">
                                    <i class="fas fa-shield-alt"></i>
                                </div>
                            </div>
                            <div class="feature-content">
                                <h3>Compliance Management</h3>
                                <p>Stay compliant with automated checks and documentation management.</p>
                                <ul class="feature-list">
                                    <li><i class="fas fa-check"></i> Automated verification</li>
                                    <li><i class="fas fa-check"></i> Document tracking</li>
                                    <li><i class="fas fa-check"></i> Audit trails</li>
                                </ul>
                            </div>
                        </div>

                        <div class="feature-card">
                            <div class="feature-icon-wrapper">
                                <div class="feature-icon">
                                    <i class="fas fa-bolt"></i>
                                </div>
                            </div>
                            <div class="feature-content">
                                <h3>Fast Implementation</h3>
                                <p>Quick setup and integration with your existing HR systems.</p>
                                <ul class="feature-list">
                                    <li><i class="fas fa-check"></i> Easy onboarding</li>
                                    <li><i class="fas fa-check"></i> System integration</li>
                                    <li><i class="fas fa-check"></i> 24/7 support</li>
                                </ul>
                            </div>
                        </div>

                        <div class="feature-card">
                            <div class="feature-icon-wrapper">
                                <div class="feature-icon">
                                    <i class="fas fa-users"></i>
                                </div>
                            </div>
                            <div class="feature-content">
                                <h3>Talent Pool Access</h3>
                                <p>Access to pre-screened insurance professionals and industry experts.</p>
                                <ul class="feature-list">
                                    <li><i class="fas fa-check"></i> Verified profiles</li>
                                    <li><i class="fas fa-check"></i> Skill assessment</li>
                                    <li><i class="fas fa-check"></i> Direct messaging</li>
                                </ul>
                            </div>
                        </div>

                        <div class="feature-card">
                            <div class="feature-icon-wrapper">
                                <div class="feature-icon">
                                    <i class="fas fa-clock"></i>
                                </div>
                            </div>
                            <div class="feature-content">
                                <h3>Time Efficiency</h3>
                                <p>Streamlined processes that save time and reduce hiring cycles.</p>
                                <ul class="feature-list">
                                    <li><i class="fas fa-check"></i> Automated screening</li>
                                    <li><i class="fas fa-check"></i> Quick scheduling</li>
                                    <li><i class="fas fa-check"></i> Bulk actions</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="features-cta">
                    <a href="#" class="btn-primary">
                        Explore All Features
                        <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </section>

        <section class="key-benefits">
    <div class="container">
        <div class="section-header">
            <span class="section-subtitle">Our Impact</span>
            <h2>Transforming Insurance Recruitment</h2>
            <p class="section-description">Experience the power of data-driven recruitment solutions designed specifically for the insurance industry.</p>
        </div>

        <div class="benefits-grid">
            <div class="benefit-card">
                <div class="benefit-stats">
                    <div class="stat-number">85%</div>
                    <div class="stat-label">Faster Hiring</div>
                </div>
                <div class="benefit-content">
                    <h3>Accelerated Recruitment</h3>
                    <p>Reduce your time-to-hire significantly with our AI-powered matching system and streamlined processes.</p>
                    <ul class="benefit-list">
                        <li><i class="fas fa-check"></i> Smart candidate matching</li>
                        <li><i class="fas fa-check"></i> Automated screening</li>
                        <li><i class="fas fa-check"></i> Quick onboarding</li>
                    </ul>
                </div>
            </div>

            <div class="benefit-card">
                <div class="benefit-stats">
                    <div class="stat-number">95%</div>
                    <div class="stat-label">Retention Rate</div>
                </div>
                <div class="benefit-content">
                    <h3>Better Candidate Fit</h3>
                    <p>Find candidates who align perfectly with your company culture and role requirements.</p>
                    <ul class="benefit-list">
                        <li><i class="fas fa-check"></i> Cultural alignment</li>
                        <li><i class="fas fa-check"></i> Skill matching</li>
                        <li><i class="fas fa-check"></i> Experience verification</li>
                    </ul>
                </div>
            </div>

            <div class="benefit-card">
                <div class="benefit-stats">
                    <div class="stat-number">60%</div>
                    <div class="stat-label">Cost Reduction</div>
                </div>
                <div class="benefit-content">
                    <h3>Cost Efficiency</h3>
                    <p>Significantly reduce your recruitment costs while improving the quality of hires.</p>
                    <ul class="benefit-list">
                        <li><i class="fas fa-check"></i> Reduced advertising costs</li>
                        <li><i class="fas fa-check"></i> Streamlined process</li>
                        <li><i class="fas fa-check"></i> Better ROI</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="benefits-cta">
            <a href="#" class="btn-primary">
                Explore All Benefits
                <i class="fas fa-arrow-right"></i>
            </a>
        </div>
    </div>
</section>
        <section class="how-it-works">
            <div class="container">
                <h2>How It Works</h2>
                <div class="steps">
                    <div class="step-card">
                        <div class="step-number">1</div>
                        <h3>Create Your Profile</h3>
                        <p>Set up your company profile and job requirements with our intuitive platform.</p>
                    </div>
                    <div class="step-card">
                        <div class="step-number">2</div>
                        <h3>Browse Qualified Agents</h3>
                        <p>Explore our extensive database of pre-screened, qualified insurance agents.</p>
                    </div>
                    <div class="step-card">
                        <div class="step-number">3</div>
                        <h3>Schedule Interviews</h3>
                        <p>Easily schedule and conduct interviews through our streamlined platform.</p>
                    </div>
                    <div class="step-card">
                        <div class="step-number">4</div>
                        <h3>Make Informed Decisions</h3>
                        <p>Use our advanced tools and insights to make the best hiring decisions.</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="learning-categories">
            <div class="container">
                <div class="categories-header">
                    <span class="categories-tag">Educational Paths</span>
                    <h2>Learning Categories for Insurance Professionals</h2>
                    <p class="categories-subtitle">Comprehensive training programs designed to enhance your insurance career</p>
                </div>

                <div class="categories-grid">
                    <div class="category-card">
                        <div class="category-icon-wrapper">
                            <div class="category-icon">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                        </div>
                        <div class="category-content">
                            <h3>Property & Casualty</h3>
                            <p>Master property and casualty insurance fundamentals, risk assessment, and claims handling.</p>
                            <ul class="category-features">
                                <li><i class="fas fa-check-circle"></i> Risk Assessment</li>
                                <li><i class="fas fa-check-circle"></i> Claims Processing</li>
                                <li><i class="fas fa-check-circle"></i> Policy Management</li>
                            </ul>
                            <div class="category-meta">
                                <span class="course-count"><i class="fas fa-book"></i> 24 Courses</span>
                                <span class="duration"><i class="fas fa-clock"></i> 48 Hours</span>
                            </div>
                            <a href="#" class="category-btn">
                                Explore Courses
                                <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>

                    <div class="category-card">
                        <div class="category-icon-wrapper">
                            <div class="category-icon">
                                <i class="fas fa-heartbeat"></i>
                            </div>
                        </div>
                        <div class="category-content">
                            <h3>Life & Health</h3>
                            <p>Comprehensive training in life insurance, health coverage, and retirement planning.</p>
                            <ul class="category-features">
                                <li><i class="fas fa-check-circle"></i> Policy Types</li>
                                <li><i class="fas fa-check-circle"></i> Benefits Analysis</li>
                                <li><i class="fas fa-check-circle"></i> Coverage Planning</li>
                            </ul>
                            <div class="category-meta">
                                <span class="course-count"><i class="fas fa-book"></i> 32 Courses</span>
                                <span class="duration"><i class="fas fa-clock"></i> 56 Hours</span>
                            </div>
                            <a href="#" class="category-btn">
                                Explore Courses
                                <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>

                    <div class="category-card">
                        <div class="category-icon-wrapper">
                            <div class="category-icon">
                                <i class="fas fa-chart-line"></i>
                            </div>
                        </div>
                        <div class="category-content">
                            <h3>Risk Management</h3>
                            <p>Learn advanced risk assessment techniques and mitigation strategies.</p>
                            <ul class="category-features">
                                <li><i class="fas fa-check-circle"></i> Risk Analysis</li>
                                <li><i class="fas fa-check-circle"></i> Compliance</li>
                                <li><i class="fas fa-check-circle"></i> Strategy Planning</li>
                            </ul>
                            <div class="category-meta">
                                <span class="course-count"><i class="fas fa-book"></i> 28 Courses</span>
                                <span class="duration"><i class="fas fa-clock"></i> 52 Hours</span>
                            </div>
                            <a href="#" class="category-btn">
                                Explore Courses
                                <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="categories-cta">
                    <a href="#" class="btn-view-all">
                        View All Categories
                        <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </section>
    </main>
<?php echo $footer;?>