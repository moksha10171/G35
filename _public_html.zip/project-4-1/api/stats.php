<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

try {
    // Check authentication
    if (empty($_SESSION['session_new_project'])) {
        throw new Exception('Unauthorized access', 401);
    }

    $userId = $_SESSION['user_id'];
    $stats = [];

    // Get applications stats
    $applicationStats = $conn->prepare("
        SELECT 
            COUNT(*) as total_applications,
            SUM(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) as recent_applications
        FROM job_applications 
        WHERE user_id = ?
    ");
    $applicationStats->bind_param("i", $userId);
    $applicationStats->execute();
    $appResult = $applicationStats->get_result()->fetch_assoc();

    // Calculate percentage change
    $weeklyChange = calculatePercentageChange(
        $appResult['recent_applications'],
        $appResult['total_applications'] - $appResult['recent_applications']
    );

    $stats['applications'] = [
        'total' => $appResult['total_applications'],
        'change' => $weeklyChange,
        'period' => 'week'
    ];

    // Get profile views
    $viewStats = $conn->prepare("
        SELECT COUNT(*) as total_views
        FROM profile_views 
        WHERE profile_id = ? AND viewed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");
    $viewStats->bind_param("i", $userId);
    $viewStats->execute();
    $viewResult = $viewStats->get_result()->fetch_assoc();

    $stats['profile_views'] = [
        'total' => $viewResult['total_views'],
        'period' => 'month'
    ];

    echo json_encode([
        'success' => true,
        'data' => $stats
    ]);

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

function calculatePercentageChange($new, $old) {
    if ($old == 0) return 100;
    return round((($new - $old) / $old) * 100, 1);
}
?> 