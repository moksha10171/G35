<?php
require_once '../config/database.php';
require_once '../middleware/auth.php';

header('Content-Type: application/json');

class JobFetcher {
    private $conn;
    
    public function __construct($db) {
        $this->conn = $db;
    }

    public function fetchJobs($filters = []) {
        try {
            $page = max(1, intval($filters['page'] ?? 1));
            $limit = 12;
            $offset = ($page - 1) * $limit;
            
            $query = "
                SELECT 
                    j.*,
                    c.name as company_name,
                    c.logo as company_logo,
                    c.rating as company_rating,
                    GROUP_CONCAT(DISTINCT js.skill) as skills
                FROM jobs j
                LEFT JOIN companies c ON j.company_id = c.id
                LEFT JOIN job_skills js ON j.id = js.job_id
                WHERE j.status = 'Active'
            ";
            
            $params = [];
            $types = "";  // For parameter types
            
            // Search filter
            if (!empty($filters['search'])) {
                $query .= " AND (j.title LIKE ? OR j.description LIKE ? OR c.name LIKE ?)";
                $searchTerm = "%{$filters['search']}%";
                $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm]);
                $types .= "sss";
            }

            // Job Type Filter
            if (!empty($filters['job_type']) && is_array($filters['job_type'])) {
                $placeholders = str_repeat('?,', count($filters['job_type']) - 1) . '?';
                $query .= " AND j.job_type IN ($placeholders)";
                $params = array_merge($params, $filters['job_type']);
                $types .= str_repeat('s', count($filters['job_type']));
            }

            // Experience Level Filter
            if (!empty($filters['experience']) && is_array($filters['experience'])) {
                $placeholders = str_repeat('?,', count($filters['experience']) - 1) . '?';
                $query .= " AND j.experience_level IN ($placeholders)";
                $params = array_merge($params, $filters['experience']);
                $types .= str_repeat('s', count($filters['experience']));
            }

            // Skills Filter
            if (!empty($filters['skills']) && is_array($filters['skills'])) {
                $skillCount = count($filters['skills']);
                $query .= " AND EXISTS (
                    SELECT 1 FROM job_skills js 
                    WHERE js.job_id = j.id 
                    AND js.skill IN (" . str_repeat('?,', $skillCount - 1) . "?)
                )";
                $params = array_merge($params, $filters['skills']);
                $types .= str_repeat('s', $skillCount);
            }

            // Location filter
            if (!empty($filters['location'])) {
                $query .= " AND j.location LIKE ?";
                $params[] = "%{$filters['location']}%";
                $types .= "s";
            }

            // Salary range filter
            if (!empty($filters['salary_min'])) {
                $query .= " AND j.salary_max >= ?";
                $params[] = floatval($filters['salary_min']);
                $types .= "d";
            }

            // Add GROUP BY before LIMIT
            $query .= " GROUP BY j.id";

            // Add ORDER BY based on sort parameter
            switch ($filters['sort'] ?? 'recent') {
                case 'salary':
                    $query .= " ORDER BY j.salary_max DESC";
                    break;
                case 'relevance':
                    // For relevance, we can combine multiple factors
                    if (!empty($filters['search'])) {
                        $query .= " ORDER BY 
                            (CASE 
                                WHEN j.title LIKE ? THEN 3
                                WHEN j.description LIKE ? THEN 2
                                WHEN c.name LIKE ? THEN 1
                                ELSE 0
                            END) DESC,
                            j.posted_date DESC";
                        $searchTerm = "%{$filters['search']}%";
                        $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm]);
                        $types .= "sss";
                    } else {
                        $query .= " ORDER BY j.posted_date DESC";
                    }
                    break;
                case 'recent':
                default:
                    $query .= " ORDER BY j.posted_date DESC";
                    break;
            }

            $query .= " LIMIT ?, ?";
            $params[] = $offset;
            $params[] = $limit;
            $types .= "ii";  // integer types for LIMIT and OFFSET

            $stmt = $this->conn->prepare($query);
            
            if (!empty($params)) {
                // Bind parameters with their types
                $stmt->bindParam(1, $params[0], PDO::PARAM_INT);
                for ($i = 0; $i < count($params); $i++) {
                    $paramType = $types[$i] === 'i' ? PDO::PARAM_INT : 
                               ($types[$i] === 'd' ? PDO::PARAM_STR : PDO::PARAM_STR);
                    $stmt->bindValue($i + 1, $params[$i], $paramType);
                }
            }
            
            $stmt->execute();
            $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Format job data
            foreach ($jobs as &$job) {
                $job['skills'] = $job['skills'] ? explode(',', $job['skills']) : [];
                $job['salary_min'] = number_format($job['salary_min'], 0);
                $job['salary_max'] = number_format($job['salary_max'], 0);
            }

            // Get total count for pagination
            $countQuery = str_replace(
                ['SELECT j.*, c.name', 'LIMIT ?, ?'], 
                ['SELECT COUNT(DISTINCT j.id)', ''], 
                $query
            );
            
            $stmtCount = $this->conn->prepare($countQuery);
            
            // Remove last two parameters (LIMIT and OFFSET) for count query
            array_pop($params);
            array_pop($params);
            
            if (!empty($params)) {
                for ($i = 0; $i < count($params); $i++) {
                    $paramType = $types[$i] === 'i' ? PDO::PARAM_INT : 
                               ($types[$i] === 'd' ? PDO::PARAM_STR : PDO::PARAM_STR);
                    $stmtCount->bindValue($i + 1, $params[$i], $paramType);
                }
            }
            
            $stmtCount->execute();
            $total = $stmtCount->fetchColumn();

            return [
                'jobs' => $jobs,
                'total' => $total,
                'pages' => ceil($total / $limit)
            ];
        } catch (Exception $e) {
            error_log("Job Fetch Error: " . $e->getMessage());
            throw new Exception("Error fetching jobs: " . $e->getMessage());
        }
    }
}

// API Endpoint Handler
try {
    $database = new Database();
    $db = $database->getConnection();
    
    $jobFetcher = new JobFetcher($db);
    
    $filters = [
        'search' => $_GET['search'] ?? '',
        'job_type' => $_GET['job_type'] ?? '',
        'experience' => $_GET['experience'] ?? '',
        'location' => $_GET['location'] ?? '',
        'salary_min' => $_GET['salary_min'] ?? '',
        'page' => $_GET['page'] ?? 1
    ];
    
    $result = $jobFetcher->fetchJobs($filters);
    
    echo json_encode([
        'success' => true,
        'data' => $result
    ]);
    
} catch (Exception $e) {
    error_log("API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
} 