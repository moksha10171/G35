<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

try {
    if (empty($_SESSION['session_new_project'])) {
        throw new Exception('Unauthorized access', 401);
    }

    $userId = $_SESSION['user_id'];
    $limit = isset($_GET['limit']) ? min(intval($_GET['limit']), 50) : 10;

    $activityQuery = $conn->prepare("
        SELECT 
            a.id,
            a.type,
            a.details,
            a.created_at,
            j.title as job_title,
            c.name as company_name
        FROM user_activities a
        LEFT JOIN jobs j ON a.job_id = j.id
        LEFT JOIN companies c ON j.company_id = c.id
        WHERE a.user_id = ?
        ORDER BY a.created_at DESC
        LIMIT ?
    ");
    
    $activityQuery->bind_param("ii", $userId, $limit);
    $activityQuery->execute();
    $result = $activityQuery->get_result();

    $activities = [];
    while ($row = $result->fetch_assoc()) {
        $activities[] = [
            'id' => $row['id'],
            'type' => $row['type'],
            'details' => $row['details'],
            'job_title' => $row['job_title'],
            'company_name' => $row['company_name'],
            'created_at' => $row['created_at']
        ];
    }

    echo json_encode([
        'success' => true,
        'data' => $activities
    ]);

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?> 