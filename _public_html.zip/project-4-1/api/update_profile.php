<?php
session_start();
header('Content-Type: application/json');

class ProfileUpdater {
    private $conn;
    private $uploadDir = '../uploads/profile_images/';
    private $allowedImageTypes = ['image/jpeg', 'image/png', 'image/webp'];
    private $maxImageSize = 5242880; // 5MB

    public function __construct() {
        try {
            $this->conn = new mysqli('localhost', 'u291518478_project1', 'Moksha@10170+10171', 'u291518478_project1');
            
            if ($this->conn->connect_error) {
                throw new Exception('Database connection failed');
            }
            
            $this->conn->set_charset("utf8mb4");
            
            if (!file_exists($this->uploadDir)) {
                mkdir($this->uploadDir, 0755, true);
            }
        } catch (Exception $e) {
            throw new Exception('Initialization failed: ' . $e->getMessage());
        }
    }

    public function handleProfileUpdate() {
        try {
            // Verify session and CSRF token
            $this->validateSession();

            // Get user data
            $userData = $this->getUserData($_SESSION['session_new_project']);
            if (!$userData) {
                throw new Exception('User not found');
            }

            // Handle image upload if present
            $imagePath = null;
            if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] !== UPLOAD_ERR_NO_FILE) {
                $imagePath = $this->handleImageUpload($_FILES['profile_image']);
            }

            // Sanitize and validate input data
            $data = $this->sanitizeInputs([
                'name' => $_POST['name'] ?? '',
                'phone' => $_POST['phone'] ?? '',
                'location' => $_POST['location'] ?? '',
                'title' => $_POST['title'] ?? '',
                'company' => $_POST['company'] ?? '',
                'bio' => $_POST['bio'] ?? ''
            ]);

            // Validate the data
            $this->validateInputs($data);

            // Begin transaction
            $this->conn->begin_transaction();

            try {
                // Update users table
                $this->updateUserInfo($userData['id'], $data['name'], $imagePath);

                // Update or insert into user_profiles table
                $this->updateUserProfile($userData['id'], $data);

                // Commit transaction
                $this->conn->commit();

                return [
                    'success' => true,
                    'message' => 'Profile updated successfully'
                ];

            } catch (Exception $e) {
                $this->conn->rollback();
                throw new Exception('Failed to update profile: ' . $e->getMessage());
            }

        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    private function validateSession() {
        if (!isset($_SESSION['session_new_project'])) {
            throw new Exception('Authentication required');
        }

        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            throw new Exception('Invalid security token');
        }
    }

    private function getUserData($sessionId) {
        $stmt = $this->conn->prepare("
            SELECT u.id, u.email 
            FROM session_access sa
            JOIN users u ON sa.email = u.email COLLATE utf8mb4_unicode_ci
            WHERE sa.session_id = ?
            AND sa.timeid > ?
        ");

        if (!$stmt) {
            throw new Exception('Database error');
        }

        $currentTime = time() - (24 * 60 * 60);
        $stmt->bind_param("si", $sessionId, $currentTime);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $user = $result->fetch_assoc();
        $stmt->close();
        
        return $user;
    }

    private function handleImageUpload($file) {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('Image upload failed');
        }

        if ($file['size'] > $this->maxImageSize) {
            throw new Exception('Image size must be less than 5MB');
        }

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        if (!in_array($mimeType, $this->allowedImageTypes)) {
            throw new Exception('Invalid image type. Allowed types: JPG, PNG, WebP');
        }

        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid('profile_') . '_' . time() . '.' . $extension;
        $uploadPath = '../uploads/profile_images/'. $filename;

        if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
            throw new Exception('Failed to save image');
        }

        return $filename;
    }

    private function sanitizeInputs($data) {
        return array_map(function($value) {
            return htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
        }, $data);
    }

    private function validateInputs($data) {
        if (empty($data['name']) || strlen($data['name']) > 25) {
            throw new Exception('Name is required and must be less than 25 characters');
        }

        if (!empty($data['phone']) && !preg_match('/^[0-9+\-\s()]{10,15}$/', $data['phone'])) {
            throw new Exception('Invalid phone number format');
        }

        if (empty($data['title'])) {
            throw new Exception('Job title is required');
        }

        if (empty($data['company'])) {
            throw new Exception('Company is required');
        }

        return true;
    }

    private function updateUserInfo($userId, $name, $imagePath = null) {
        $query = "UPDATE users SET name = ? COLLATE utf8mb4_unicode_ci";
        $params = [$name];
        $types = "s";

        if ($imagePath) {
            $query .= ", image = ? COLLATE utf8mb4_unicode_ci";
            $params[] = $imagePath;
            $types .= "s";
        }

        $query .= " WHERE id = ?";
        $params[] = $userId;
        $types .= "i";

        $stmt = $this->conn->prepare($query);
        if (!$stmt) {
            throw new Exception('Failed to prepare user update statement');
        }

        $stmt->bind_param($types, ...$params);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to update user information');
        }
        
        $stmt->close();
    }

    private function updateUserProfile($userId, $data) {
        // First check if profile exists
        $stmt = $this->conn->prepare("SELECT user_id FROM user_profiles WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $exists = $result->num_rows > 0;
        $stmt->close();

        if ($exists) {
            // Update existing profile
            $stmt = $this->conn->prepare("
                UPDATE user_profiles 
                SET phone = ?, location = ?, title = ?, company = ?, bio = ?
                WHERE user_id = ?
            ");
        } else {
            // Insert new profile
            $stmt = $this->conn->prepare("
                INSERT INTO user_profiles 
                (user_id, phone, location, title, company, bio)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
        }

        if (!$stmt) {
            throw new Exception('Failed to prepare profile update statement');
        }

        $stmt->bind_param("sssssi", 
            $data['phone'],
            $data['location'],
            $data['title'],
            $data['company'],
            $data['bio'],
            $userId
        );

        if (!$stmt->execute()) {
            throw new Exception('Failed to update profile information');
        }
        $stmt->close();
    }

    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }
}

try {
    $profileUpdater = new ProfileUpdater();
    $result = $profileUpdater->handleProfileUpdate();
    
    echo json_encode($result);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
} 