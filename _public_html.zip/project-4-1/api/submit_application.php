<?php
session_start();
header('Content-Type: application/json');

class ApplicationHandler {
    private $conn;
    private $uploadDir = '../uploads/resumes/';
    private $allowedTypes = [
        'application/pdf' => 'pdf',
        'application/msword' => 'doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx'
    ];
    
    public function __construct() {
        $this->conn = new mysqli('localhost', 'u291518478_project1', 'Moksha@10170+10171', 'u291518478_project1');
        
        if ($this->conn->connect_error) {
            throw new Exception('Database connection failed');
        }
        
        $this->conn->set_charset("utf8mb4");
        $this->conn->query("SET collation_connection = utf8mb4_unicode_ci");
        
        if (!file_exists($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }
    }
    
    public function handleApplication() {
        if (!isset($_SESSION['session_new_project'])) {
            throw new Exception('Authentication required');
        }

        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            throw new Exception('Invalid security token');
        }

        if (!isset($_POST['job_id']) || !isset($_FILES['resume'])) {
            throw new Exception('Missing required fields');
        }

        $stmt = $this->conn->prepare("
            SELECT u.id, u.email 
            FROM session_access sa
            JOIN users u ON sa.email COLLATE utf8mb4_unicode_ci = u.email COLLATE utf8mb4_unicode_ci
            WHERE sa.session_id = ?
            AND sa.timeid > ?
        ");
        
        if (!$stmt) {
            throw new Exception('Database error: ' . $this->conn->error);
        }

        $currentTime = time() - (24 * 60 * 60);
        $sessionId = $_SESSION['session_new_project'];
        $stmt->bind_param("si", $sessionId, $currentTime);
        
        if (!$stmt->execute()) {
            throw new Exception('Database error: ' . $stmt->error);
        }

        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();

        if (!$user) {
            throw new Exception('User not authenticated');
        }

        $stmt = $this->conn->prepare("
            SELECT id FROM job_applications 
            WHERE job_id = ? AND user_id = ?
        ");
        
        if (!$stmt) {
            throw new Exception('Database error: ' . $this->conn->error);
        }

        $jobId = $_POST['job_id'];
        $userId = $user['id'];
        $stmt->bind_param("ii", $jobId, $userId);
        
        if (!$stmt->execute()) {
            throw new Exception('Database error: ' . $stmt->error);
        }

        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $stmt->close();
            throw new Exception('You have already applied for this job');
        }
        $stmt->close();

        $file = $_FILES['resume'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('File upload failed');
        }

        if ($file['size'] > 5 * 1024 * 1024) {
            throw new Exception('File size must be less than 5MB');
        }

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        if (!array_key_exists($mimeType, $this->allowedTypes)) {
            throw new Exception('Invalid file type. Only PDF and DOC/DOCX files are allowed');
        }

        $extension = $this->allowedTypes[$mimeType];
        $filename = uniqid('resume_') . '.' . $extension;
        $uploadPath = $this->uploadDir . $filename;

        if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
            throw new Exception('Failed to save resume file');
        }

        $stmt = $this->conn->prepare("
            INSERT INTO job_applications 
            (job_id, user_id, resume_path, cover_letter, status, applied_date) 
            VALUES (?, ?, ?, ?, 'Pending', NOW())
        ");

        if (!$stmt) {
            unlink($uploadPath);
            throw new Exception('Database error: ' . $this->conn->error);
        }

        $coverLetter = $_POST['cover_letter'] ?? '';
        $stmt->bind_param("iiss", $jobId, $userId, $filename, $coverLetter);

        if (!$stmt->execute()) {
            unlink($uploadPath);
            throw new Exception('Failed to submit application: ' . $stmt->error);
        }

        $stmt->close();
        return true;
    }

    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }
}

try {
    $handler = new ApplicationHandler();
    $result = $handler->handleApplication();
    
    echo json_encode([
        'success' => true,
        'message' => 'Application submitted successfully'
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
} 