<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

try {
    if (empty($_SESSION['session_new_project'])) {
        throw new Exception('Unauthorized access', 401);
    }

    $data = json_decode(file_get_contents('php://input'), true);
    $query = $data['query'] ?? '';

    if (empty($query)) {
        throw new Exception('Search query is required', 400);
    }

    $results = [];
    $searchTerm = "%{$query}%";

    // Search jobs
    $jobStmt = $conn->prepare("
        SELECT id, title, company_name, 'job' as type 
        FROM jobs 
        WHERE title LIKE ? OR description LIKE ? 
        LIMIT 5
    ");
    $jobStmt->bind_param("ss", $searchTerm, $searchTerm);
    $jobStmt->execute();
    $jobResults = $jobStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $results = array_merge($results, $jobResults);

    // Search companies
    $companyStmt = $conn->prepare("
        SELECT id, name as title, description, 'company' as type 
        FROM companies 
        WHERE name LIKE ? OR description LIKE ? 
        LIMIT 5
    ");
    $companyStmt->bind_param("ss", $searchTerm, $searchTerm);
    $companyStmt->execute();
    $companyResults = $companyStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $results = array_merge($results, $companyResults);

    echo json_encode([
        'success' => true,
        'data' => $results
    ]);

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?> 