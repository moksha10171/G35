<?php
require_once '../config/database.php';
require_once '../middleware/auth.php';

header('Content-Type: application/json');

class JobDetailsFetcher {
    private $conn;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    public function fetchJobDetails($jobId) {
        try {
            $query = "
                SELECT 
                    j.*,
                    c.name as company_name,
                    c.logo as company_logo,
                    c.description as company_description,
                    c.rating as company_rating,
                    c.employee_count,
                    c.website,
                    GROUP_CONCAT(DISTINCT js.skill) as skills
                FROM jobs j
                LEFT JOIN companies c ON j.company_id = c.id
                LEFT JOIN job_skills js ON j.id = js.job_id
                WHERE j.id = :jobId AND j.status = 'Active'
                GROUP BY j.id";

            $stmt = $this->conn->prepare($query);
            if (!$stmt) {
                throw new Exception('Failed to prepare statement');
            }

            // Use PDO parameter binding
            $stmt->bindParam(':jobId', $jobId, PDO::PARAM_INT);
            
            if (!$stmt->execute()) {
                throw new Exception('Failed to execute query');
            }

            $job = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$job) {
                throw new Exception('Job not found');
            }

            // Convert skills string to array if exists
            if ($job['skills']) {
                $job['skills'] = explode(',', $job['skills']);
            } else {
                $job['skills'] = [];
            }

            // Decode JSON fields if they exist
            if (isset($job['requirements'])) {
                $job['requirements'] = json_decode($job['requirements'], true);
            }
            if (isset($job['benefits'])) {
                $job['benefits'] = json_decode($job['benefits'], true);
            }

            return $job;

        } catch (Exception $e) {
            error_log("Job Details Error: " . $e->getMessage());
            throw new Exception('Error fetching job details: ' . $e->getMessage());
        }
    }
}

try {
    if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
        throw new Exception('Invalid job ID');
    }
    
    $database = new Database();
    $db = $database->getConnection();
    
    $fetcher = new JobDetailsFetcher($db);
    $job = $fetcher->fetchJobDetails((int)$_GET['id']);
    
    echo json_encode([
        'success' => true,
        'data' => [
            'id' => $job['id'],
            'title' => $job['title'],
            'company_name' => $job['company_name'],
            'company_logo' => $job['company_logo'],
            'company_rating' => $job['rating'],
            'company_description' => $job['company_description'],
            'employee_count' => $job['employee_count'],
            'website' => $job['website'],
            'description' => $job['description'],
            'requirements' => json_decode($job['requirements']),
            'benefits' => json_decode($job['benefits']),
            'posted_date' => $job['posted_date'],
            'required_skills' => json_decode($job['required_skills']),
            // ... other fields ...
        ]
    ]);
    
} catch (Exception $e) {
    error_log("API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
} 