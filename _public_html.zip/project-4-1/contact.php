<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('assets/layout/header.php');
$footer = inancap('assets/layout/footer.php');
$meta = inancap('assets/layout/meta.php');
echo $meta;
$descript = 'Contact TalentSphere - Get in Touch';
$title = 'Contact TalentSphere - Get in Touch';
echo generateMetaTags($title, $descript, '', '', 'Coding, Courses');
echo $header;
?>
    <main id="main-content">
        <!-- Contact Hero Section -->
        <section class="contact-hero">
            <div class="container">
                <div class="hero-content">
                    <span class="hero-tag">Contact Us</span>
                    <h1>Let's Start a Conversation</h1>
                    <p>Have questions? We're here to help and provide the support you need</p>
                </div>
            </div>
        </section>

        <!-- Contact Info Section -->
        <section class="contact-info-section">
            <div class="container">
                <div class="contact-info-grid">
                    <div class="contact-info-card" data-aos="fade-up">
                        <div class="info-icon">
                            <i class="fas fa-phone"></i>
                        </div>
                        <h3>Call Us</h3>
                        <p>We're available Monday to Friday, 9am - 6pm EST</p>
                        <a href="tel:+1234567890" class="info-link">+1 (234) 567-890</a>
                    </div>

                    <div class="contact-info-card" data-aos="fade-up" data-aos-delay="100">
                        <div class="info-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <h3>Email Us</h3>
                        <p>We'll respond to your email within 24 hours</p>
                        <a href="mailto:contact@talentsphere.com" class="info-link">contact@talentsphere.com</a>
                    </div>

                    <div class="contact-info-card" data-aos="fade-up" data-aos-delay="200">
                        <div class="info-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <h3>Visit Us</h3>
                        <p>Presidency University</p>
                        <span class="info-text">Bangalore, KA</span>
                    </div>
                </div>
            </div>
        </section>

        <!-- Contact Form Section -->
        <section class="contact-form-section">
            <div class="container">
                <div class="contact-wrapper">
                    <div class="form-content">
                        <div class="section-header">
                            <span class="section-tag">Get in Touch</span>
                            <h2>Send Us a Message</h2>
                            <p>Fill out the form below and we'll get back to you shortly</p>
                        </div>
                        <form id="contact-form" class="contact-form">
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="name">Full Name</label>
                                    <input type="text" id="name" name="name" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email Address</label>
                                    <input type="email" id="email" name="email" required>
                                </div>
                                <div class="form-group">
                                    <label for="phone">Phone Number</label>
                                    <input type="tel" id="phone" name="phone">
                                </div>
                                <div class="form-group">
                                    <label for="subject">Subject</label>
                                    <select id="subject" name="subject" required>
                                        <option value="">Select a subject</option>
                                        <option value="general">General Inquiry</option>
                                        <option value="support">Technical Support</option>
                                        <option value="partnership">Partnership</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>
                                <div class="form-group full-width">
                                    <label for="message">Message</label>
                                    <textarea id="message" name="message" rows="6" required></textarea>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">
                                Send Message
                                <i class="fas fa-arrow-right"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </section>

        <!-- Map Section -->
        <section class="map-section">
            <div class="container">
                <div class="map-wrapper">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3884.8898838082414!2d77.53262117454958!3d13.169342360513152!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae21be4090284d%3A0x383b9f4a79f661bd!2sPRESIDENCY%20UNIVERSITY%2C%20Ittagallpura%2C%20Karnataka%20560089!5e0!3m2!1sen!2sin!4v1731649837364!5m2!1sen!2sin"
                        width="100%" 
                        height="450" 
                        style="border:0;" 
                        allowfullscreen="" 
                        loading="lazy">
                    </iframe>
                </div>
            </div>
        </section>
    </main>
<?php echo $footer;?>