<?php
session_start();
ini_set('log_errors', 1);
ini_set('error_log', '/home/u291518478/domains/bmreducation.in/public_html/project-4-1/logs/error.log');
error_reporting(E_ALL);
ini_set('display_errors', 0);
date_default_timezone_set('Asia/Kolkata');
session_regenerate_id(true);

$ist_zone = new DateTimeZone('Asia/Kolkata');
$date = new DateTime('now', $ist_zone);
$Registered_on = $date->format('Y-m-d H:i:s');
$client = $_SERVER['HTTP_USER_AGENT'];
$Browser = end(explode(" ", $client));
$Operating_system = explode(";", $client)[1] ?? "";
$id = $_SERVER['REMOTE_ADDR'];
$time = time();
function isWithinTenMinutes($time_id) {
    $current_time = time(); // Get the current timestamp
    $time_difference = $current_time - $time_id;

    // Check if the difference is within 0 to 600 seconds (10 minutes)
    return $time_difference >= 0 && $time_difference <= 600;
}
$ist_zone = new DateTimeZone('Asia/Kolkata');
$date = new DateTime('now', $ist_zone);
$Registered_on = $date->format('Y-m-d H:i:s');
$client = $_SERVER['HTTP_USER_AGENT'];
$Operating_system = explode(";", $client)[1] ?? "";
$Browser = end(explode(" ", $client));
$id = $_SERVER['REMOTE_ADDR'];
$time = time();

$data_api = file_get_contents("http://ip-api.com/json/{$id}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,currency,isp,org,as,query");
$row_api = json_decode($data_api, true);

$isMob = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "mobile"));
$isTab = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "tablet"));
$isWin = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "windows"));
$isAndroid = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "android"));
$isIPhone = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "iphone"));
$isIPad = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "ipad"));
$isIOS = $isIPhone || $isIPad;

$device_platform = $isMob ? ($isTab ? 'Tablet' : 'Mobile') : 'Desktop';
$device_type = $isIOS ? 'iOS' : ($isAndroid ? 'ANDROID' : ($isWin ? 'WINDOWS' : 'OTHER'));

    function generateRandomString($length) {
        $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        return substr(str_shuffle($characters), 0, $length);
    }
function generateReferralCode($conn) {
    do {
        $code = generateRandomString(3) . random_int(10, 99) . generateRandomString(3) . random_int(1, 9) . generateRandomString(1) . random_int(10, 99);
        $result = $conn->query("SELECT uid FROM users WHERE uid = '$code'");
    } while ($result->num_rows > 0);
    return $code;
}
    function generateToken($email) {
        return md5(time()) . md5($email);
    }

    function generateOTP() {
        return rand(100000, 999999);
    }

    function generateMailID() {
        return random_int(1, 9) . generateRandomString(3) . random_int(10, 99) . generateRandomString(1) . random_int(10, 99) . generateRandomString(2) . random_int(10, 99);
    }
    
    
if ($_SERVER['REQUEST_METHOD'] === 'GET' && $_SERVER['SERVER_NAME'] === 'www.bmreducation.in') {
if (
    $_SERVER['REQUEST_METHOD'] === 'GET' &&
    isset($_GET['auth']) &&
    !empty($_GET['auth'])
) {
    try {
        $conn = new mysqli('localhost', 'u291518478_project1', 'Moksha@10170+10171', 'u291518478_project1');
        if ($conn->connect_error) {
            throw new Exception("Database connection failed");
        }
        $stmtauth = $conn->prepare("SELECT * FROM registration_details WHERE token = ?");
        $stmtauth->bind_param("s", $_GET['auth']);
        $stmtauth->execute();
        $resultauth = $stmtauth->get_result();

        if ($resultauth->num_rows > 0) {
            $rowauth = $resultauth->fetch_assoc();
        $email = $rowauth['email'];
        $hashedPassword = $rowauth['password'];
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 0) {
            if(isWithinTenMinutes($rowauth['timeid'])){
            $stmtrv = $conn->prepare("DELETE FROM registration_details WHERE email = ?");
            $stmtrv->bind_param("s", $email);
            $stmtrv->execute();
                $six_digit_random_number = generateReferralCode($conn);
             $stmt = $conn->prepare("INSERT INTO users (name, email, uid, registered_time, password, timeid) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("ssssss", $rowauth['name'], $email, $six_digit_random_number, $Registered_on, $hashedPassword, $time);
                if ($stmt->execute()) {
            header('Location: https://www.bmreducation.in/project-4-1/login');
                }else {
            error_log("Invalid Request.");
            echo json_encode(['status' => 'failed', 'response' => 'User not found.']);
        }
            } else {
            error_log("Link Expired.");
            echo json_encode(['status' => 'failed', 'response' => 'Link Expired.']);
        }
        } else {
            error_log("Invalid Request.");
            echo json_encode(['status' => 'failed', 'response' => 'User not found.']);
        }
        } else {
            error_log("Invalid Request.");
            echo json_encode(['status' => 'failed', 'response' => 'User not found.']);
        }
    } catch (Exception $e) {
        error_log($e->getMessage());
        echo json_encode(['status' => 'failed', 'response' => 'An error occurred. Please try again later']);
    } finally {
        if (isset($conn)) {
            $conn->close();
        }
    }
} else {
    error_log("Invalid Request.");
    echo json_encode(['status' => 'failed', 'response' => 'Invalid Request 2']);
}
} else {
    error_log("Invalid Request.");
    echo json_encode(['status' => 'failed', 'response' => 'Invalid Request 3']);
}
?>