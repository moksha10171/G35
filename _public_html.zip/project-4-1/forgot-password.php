<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('assets/layout/header.php');
$footer = inancap('assets/layout/footer.php');
$meta = inancap('assets/layout/meta.php');
echo $meta;
$descript = 'Forgot Password - TalentSphere';
$title = 'Forgot Password - TalentSphere';
echo generateMetaTags($title, $descript, '', '', 'Coding, Courses');
echo $header;
?>
    <main id="main-content">
        <section class="forgot-password-section">
            <div class="container">
                <div class="forgot-password-container">
                    <h1>Forgot Your Password?</h1>
                    <p>Enter your email address below, and we'll send you instructions to reset your password.</p>
                    <form id="forgot-password-form" class="forgot-password-form">
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Reset Password</button>
                    </form>
                    <div class="back-to-login">
                        <a href="/project-4-1/login">Back to Login</a>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <?php echo $footer;?>