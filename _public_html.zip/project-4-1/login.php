<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('assets/layout/header.php');
$footer = inancap('assets/layout/footer.php');
$meta = inancap('assets/layout/meta.php');
echo $meta;
$descript = 'Log In - TalentSphere';
$title = 'Log In - TalentSphere';
echo generateMetaTags($title, $descript, '', '', 'Coding, Courses');
echo $header;
?>
<link rel="stylesheet" href="assets/css/style.css">
    <main id="main-content">
        <section class="login-section">
            <div class="login-container">
                <div class="login-header">
                    <h1>Welcome Back!</h1>
                    <p class="login-intro">Enter your credentials to access your account</p>
                </div>
                
                <form id="login-form" class="login-form" method="POST" action="/project-4-1/auth/login">
                    <div class="form-group">
                        <div class="form-label">
                            <label for="email">Email Address</label>
                        </div>
                        <div class="input-wrapper">
                            <i class="far fa-envelope input-icon"></i>
                            <input type="email" id="email" name="email" placeholder="Enter your email" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="form-label">
                            <label for="password">Password</label>
                        </div>
                        <div class="input-wrapper">
                            <i class="far fa-lock input-icon"></i>
                            <input type="password" id="password" name="password" placeholder="Enter your password" required>
                            <button type="button" class="password-toggle">
                                <i class="far fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <div class="form-footer">
                        <div class="checkbox-group">
                            <input type="checkbox" id="remember-me" name="remember-me">
                            <label for="remember-me">Remember me</label>
                        </div>
                        <a href="/project-4-1/forgot-password" class="forgot-link">Forgot password?</a>
                    </div>

                    <button type="submit" class="btn-block">
                        Sign In
                    </button>

                    <p class="signup-link">
                        Don't have an account? <a href="/project-4-1/signup">Sign up</a>
                    </p>
                </form>
            </div>
        </section>
    </main>
    <script>
        // Password toggle functionality
        document.querySelectorAll('.password-toggle').forEach(button => {
            button.addEventListener('click', function() {
                const input = this.previousElementSibling;
                const icon = this.querySelector('i');
                
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            });
        });

        // Form submission handling
        document.getElementById('login-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            // Remove any existing alerts
            removeAlerts();
            
            const submitButton = e.target.querySelector('button[type="submit"]');
            const originalButtonText = submitButton.innerHTML;
            
            // Get form inputs
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            
            // Basic validation
            if (!email || !password) {
                showError('Please fill in all fields');
                return;
            }
            
            if (!isValidEmail(email)) {
                showError('Please enter a valid email address');
                return;
            }
            
            // Disable form and show loading state
            setLoading(true, submitButton, originalButtonText);
            
            try {
                const success = await loginUser(email, password);
                if (success) {
                    showSuccess('Login successful! Redirecting...');
                    setTimeout(() => {
                        window.location.href = '/project-4-1/app/';
                    }, 1500);
                }
            } catch (error) {
                showError(error.message || 'Login failed. Please try again.');
            } finally {
                setLoading(false, submitButton, originalButtonText);
            }
        });

        async function loginUser(email, password) {
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;
            if (!csrfToken) {
                throw new Error('Security token not found. Please refresh the page.');
            }
            
            try {
                const response = await fetch('assets/account/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'X-CSRF-Token': csrfToken,
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: new URLSearchParams({
                        email: email,
                        password: password,
                        'remember-me': document.getElementById('remember-me').checked
                    }),
                    credentials: 'same-origin'
                });

                const data = await response.json();
                
                if (!response.ok) {
                    throw new Error(data.message || `Server error: ${response.status}`);
                }
                
                if (data.status === 'success') {
                    return true;
                } else {
                    throw new Error(data.message || 'Invalid credentials');
                }
            } catch (error) {
                console.error('Login error:', error);
                throw error;
            }
        }

        // Helper functions
        function isValidEmail(email) {
            const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
            return emailRegex.test(email);
        }

        function showError(message) {
            const alertDiv = createAlert('danger', message);
            insertAlert(alertDiv);
        }

        function showSuccess(message) {
            const alertDiv = createAlert('success', message);
            insertAlert(alertDiv);
        }

        function createAlert(type, message) {
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type} fade-in`;
            
            const icon = document.createElement('i');
            icon.className = type === 'danger' 
                ? 'fas fa-exclamation-circle mr-2' 
                : 'fas fa-check-circle mr-2';
            
            const messageSpan = document.createElement('span');
            messageSpan.textContent = message;
            
            const closeButton = document.createElement('button');
            closeButton.className = 'alert-close';
            closeButton.innerHTML = '&times;';
            closeButton.onclick = () => alertDiv.remove();
            
            alertDiv.appendChild(icon);
            alertDiv.appendChild(messageSpan);
            alertDiv.appendChild(closeButton);
            
            return alertDiv;
        }

        function insertAlert(alertDiv) {
            const form = document.getElementById('login-form');
            const existingAlert = form.querySelector('.alert');
            if (existingAlert) {
                existingAlert.remove();
            }
            form.insertBefore(alertDiv, form.firstChild);
        }

        function removeAlerts() {
            document.querySelectorAll('.alert').forEach(alert => alert.remove());
        }

        function setLoading(isLoading, button, originalText) {
            const form = document.getElementById('login-form');
            const inputs = form.querySelectorAll('input, button');
            
            inputs.forEach(input => input.disabled = isLoading);
            
            if (isLoading) {
                button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing in...';
            } else {
                button.innerHTML = originalText;
            }
        }
    </script>
<?php echo $footer;?>