// Use IIFE to avoid global namespace pollution
const ApplicationModal = (() => {
    class JobApplicationModal {
        constructor() {
            if (JobApplicationModal.instance) {
                return JobApplicationModal.instance;
            }
            JobApplicationModal.instance = this;

            this.modal = document.getElementById('applicationModal');
            this.form = document.getElementById('jobApplicationForm');
            this.notification = this.createNotification();
            this.activeTab = 'description';
            this.initializeEventListeners();
        }

        createNotification() {
            const notification = document.createElement('div');
            notification.className = 'notification';
            notification.innerHTML = `
                <i class="notification-icon"></i>
                <div class="notification-content">
                    <span class="notification-message"></span>
                </div>
            `;
            document.body.appendChild(notification);
            return notification;
        }

        showNotification(message, type = 'success') {
            const iconClass = type === 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle';
            this.notification.querySelector('.notification-icon').className = `notification-icon ${iconClass}`;
            this.notification.querySelector('.notification-message').textContent = message;
            this.notification.className = `notification ${type} show`;
            
            setTimeout(() => {
                this.notification.className = 'notification';
            }, 3000);
        }

        initializeEventListeners() {
            // Close modal handlers
            this.modal.querySelector('.close-modal').addEventListener('click', () => this.hide());
            this.modal.addEventListener('click', (e) => {
                if (e.target === this.modal) this.hide();
            });

            // Keyboard navigation
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && this.modal.style.display === 'block') {
                    this.hide();
                }
            });

            // Tab switching with improved handling
            this.modal.querySelectorAll('.tab-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.switchTab(e);
                });
            });

            // Enhanced file upload handling
            const fileInput = this.form.querySelector('#resume');
            const dropZone = this.form.querySelector('.file-upload');

            dropZone.addEventListener('dragover', (e) => {
                e.preventDefault();
                dropZone.classList.add('dragover');
            });

            dropZone.addEventListener('dragleave', () => {
                dropZone.classList.remove('dragover');
            });

            dropZone.addEventListener('drop', (e) => {
                e.preventDefault();
                dropZone.classList.remove('dragover');
                const files = e.dataTransfer.files;
                if (files.length) {
                    fileInput.files = files;
                    this.handleFileSelection({ target: fileInput });
                }
            });

            fileInput.addEventListener('change', (e) => this.handleFileSelection(e));

            // Cover letter with auto-save
            const coverLetter = this.form.querySelector('#coverLetter');
            let typingTimer;
            coverLetter.addEventListener('input', (e) => {
                this.updateCharCount(e);
                clearTimeout(typingTimer);
                typingTimer = setTimeout(() => {
                    localStorage.setItem('coverLetterDraft', e.target.value);
                }, 1000);
            });

            // Form submission with validation
            this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        }

        async show(jobId) {
            try {
                const response = await fetch(`/project-4-1/api/fetch_job_details.php?id=${jobId}`);
                const data = await response.json();

                if (!data.success) throw new Error(data.error);

                this.populateJobDetails(data.data);
                this.modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
                
                // Reset form but restore draft if exists
                this.form.reset();
                this.form.querySelector('#jobId').value = jobId;
                const savedDraft = localStorage.getItem('coverLetterDraft');
                if (savedDraft) {
                    this.form.querySelector('#coverLetter').value = savedDraft;
                    this.updateCharCount({ target: this.form.querySelector('#coverLetter') });
                }
                
            } catch (error) {
                console.error('Error loading job details:', error);
                this.showNotification('Failed to load job details. Please try again.', 'error');
            }
        }

        hide() {
            this.modal.style.display = 'none';
            document.body.style.overflow = '';
            this.resetTabs();
        }

        resetTabs() {
            this.activeTab = 'description';
            this.modal.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.toggle('active', btn.dataset.tab === 'description');
            });
            this.modal.querySelectorAll('.tab-pane').forEach(pane => {
                pane.classList.toggle('active', pane.id === 'description');
            });
        }

        populateJobDetails(job) {
            this.modal.querySelector('.job-title').textContent = job.title;
            this.modal.querySelector('.company-name').textContent = job.company_name;
            this.modal.querySelector('.company-logo').src = job.company_logo || '/assets/images/default-company.png';
            this.modal.querySelector('.job-description').innerHTML = job.description;
            this.modal.querySelector('.requirements-list').innerHTML = this.formatList(job.requirements);
            this.modal.querySelector('.benefits-list').innerHTML = this.formatList(job.benefits);
            this.modal.querySelector('.company-description').innerHTML = job.company_description;
            
            // Update skills
            const skillsList = this.modal.querySelector('.skills-list');
            if (job.required_skills) {
                skillsList.innerHTML = job.required_skills
                    .map(skill => `<span class="skill-tag">${skill}</span>`)
                    .join('');
            }
        }

        formatList(items) {
            if (!items || !Array.isArray(items)) return '';
            return `<ul>${items.map(item => `<li>${item}</li>`).join('')}</ul>`;
        }

        switchTab(event) {
            const buttons = this.modal.querySelectorAll('.tab-btn');
            const panes = this.modal.querySelectorAll('.tab-pane');
            
            buttons.forEach(btn => btn.classList.remove('active'));
            panes.forEach(pane => pane.classList.remove('active'));
            
            event.target.classList.add('active');
            const tabId = event.target.dataset.tab;
            document.getElementById(tabId).classList.add('active');
        }

        handleFileSelection(event) {
            const file = event.target.files[0];
            const fileInfo = this.modal.querySelector('.selected-file');
            const fileInput = event.target;
            
            if (file) {
                if (file.size > 5 * 1024 * 1024) {
                    this.showNotification('File size must be less than 5MB', 'error');
                    fileInput.value = '';
                    fileInfo.textContent = '';
                    return;
                }
                
                fileInfo.innerHTML = `
                    <div class="file-preview">
                        <i class="far fa-file-pdf"></i>
                        <span>${file.name}</span>
                        <button type="button" class="remove-file">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                `;
                
                // Add remove file handler
                fileInfo.querySelector('.remove-file').addEventListener('click', () => {
                    fileInput.value = '';
                    fileInfo.textContent = '';
                });
            } else {
                fileInfo.textContent = '';
            }
        }

        updateCharCount(event) {
            const maxLength = 500;
            const current = event.target.value.length;
            this.modal.querySelector('.char-count').textContent = `${current}/${maxLength}`;
            
            if (current > maxLength) {
                event.target.value = event.target.value.substring(0, maxLength);
            }
        }

        validateForm() {
            const fileInput = this.form.querySelector('#resume');
            const coverLetter = this.form.querySelector('#coverLetter');

            if (!fileInput.files.length) {
                this.showNotification('Please upload your resume', 'error');
                return false;
            }

            if (coverLetter.value.trim().length < 50) {
                this.showNotification('Cover letter should be at least 50 characters', 'error');
                return false;
            }

            return true;
        }

        async handleSubmit(event) {
            event.preventDefault();
            
            if (!this.validateForm()) return;

            const submitBtn = this.form.querySelector('.btn-submit');
            submitBtn.disabled = true;
            submitBtn.classList.add('loading');
            
            try {
                const formData = new FormData(this.form);
                const response = await fetch('/project-4-1/api/submit_application.php', {
                    method: 'POST',
                    body: formData
                });
        
                const data = await response.json();
        
                if (!data.success) throw new Error(data.error);
        
                this.showNotification('Application submitted successfully!');
                localStorage.removeItem('coverLetterDraft');
                this.hide();
                
            } catch (error) {
                this.showNotification(error.message || 'Failed to submit application. Please try again.', 'error');
            } finally {
                submitBtn.disabled = false;
                submitBtn.classList.remove('loading');
            }
        }
    }

    return new JobApplicationModal();
})();

// Export for global use
window.applicationModal = ApplicationModal;