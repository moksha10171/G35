function getcsrftoken() {
    return document.querySelector('meta[name="csrf-token"]').getAttribute('content');
}

var is_loggingin = false;
var ntwk = 1;

// Snackbar message function
function snackbarmessage(message, isError = false) {
    const existingSnackbar = document.querySelector('.snackbar');
    if (existingSnackbar) {
        existingSnackbar.remove();
    }

    const snackbar = document.createElement('div');
    snackbar.className = `snackbar ${isError ? 'error' : 'success'}`;
    snackbar.textContent = message;
    document.body.appendChild(snackbar);

    // Trigger reflow to restart animation
    snackbar.offsetHeight;
    snackbar.classList.add('show');

    setTimeout(() => {
        snackbar.remove();
    }, 3000);
}

// Form validation
function validateForm(email, password) {
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    
    if (!email || !emailRegex.test(email)) {
        snackbarmessage('Please enter a valid email address', true);
        return false;
    }
    
    if (!password || password.length < 6) {
        snackbarmessage('Password must be at least 6 characters', true);
        return false;
    }
    
    return true;
}

function login_section() {
    if (is_loggingin) return;
    if (ntwk !== 1) {
        handleNetworkStatusChange();
        return;
    }

    is_loggingin = true;
    const submitBtn = document.querySelector('.btn-block');
    
    try {
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();

        if (!validateForm(email, password)) {
            is_loggingin = false;
            return;
        }

        // Show loading state
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span>Signing in...</span>';

        var formData = new FormData();
        formData.append("password", password);
        formData.append("email", email);

        $.ajax({
            type: 'POST',
            url: '/project-4-1/assets/account/login',
            headers: { 'x-csrf-token': getcsrftoken() },
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                try {
                    const r = typeof response === 'string' ? JSON.parse(response) : response;
                    if (r && r.status === 'success') {
                        snackbarmessage('Login successful! Redirecting...', false);
                        setTimeout(() => {
                            window.location.href = "https://www.bmreducation.in/project-4-1/app/";
                        }, 1500);
                    } else {
                        snackbarmessage(r.response || 'Login failed. Please try again.', true);
                    }
                } catch (e) {
                    snackbarmessage('Invalid response from server', true);
                }
            },
            error: function(xhr) {
                snackbarmessage(xhr.responseText || 'Cannot connect to server. Please try again.', true);
            },
            complete: function() {
                is_loggingin = false;
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<span>Sign In</span><i class="far fa-arrow-right"></i>';
            }
        });
    } catch (error) {
        snackbarmessage("An error occurred. Please try again.", true);
        is_loggingin = false;
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<span>Sign In</span><i class="far fa-arrow-right"></i>';
    }
}

function handleNetworkStatusChange() {
    if (navigator.onLine) {
        ntwk = 1;
        snackbarmessage("You're back online!", false);
    } else {
        ntwk = 0;
        snackbarmessage("You're offline. Please check your connection.", true);
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('login-form');
    const passwordToggle = document.querySelector('.password-toggle');
    const passwordInput = document.getElementById('password');

    // Password toggle
    passwordToggle?.addEventListener('click', function() {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        
        const icon = this.querySelector('i');
        icon.classList.toggle('fa-eye');
        icon.classList.toggle('fa-eye-slash');
    });

    // Form submission
    loginForm?.addEventListener('submit', function(e) {
        e.preventDefault();
        login_section();
    });

    // Network status monitoring
    window.addEventListener('online', handleNetworkStatusChange);
    window.addEventListener('offline', handleNetworkStatusChange);
});