class EnhancedTutorialProgress {
    constructor() {
        this.storageKey = 'tutorial_progress_v2';
        this.currentTutorial = document.querySelector('main').dataset.tutorialId;
        this.progressBar = document.querySelector('.tutorial-progress-bar .progress');
        this.init();
    }

    init() {
        this.initializeStorage();
        this.bindScrollEvents();
        this.bindQuizEvents();
        this.updateProgressBar();
        this.markVisibleSections();
    }

    initializeStorage() {
        if (!localStorage.getItem(this.storageKey)) {
            localStorage.setItem(this.storageKey, JSON.stringify({
                tutorials: {},
                lastAccessed: null,
                totalProgress: 0
            }));
        }
        
        // Initialize current tutorial if not exists
        const storage = this.getStorage();
        if (!storage.tutorials[this.currentTutorial]) {
            storage.tutorials[this.currentTutorial] = {
                progress: 0,
                completedSections: [],
                quizScores: {},
                lastPosition: 0,
                timeSpent: 0,
                startDate: new Date().toISOString()
            };
            this.saveStorage(storage);
        }
    }

    bindScrollEvents() {
        let lastScrollTime = Date.now();
        let ticking = false;

        window.addEventListener('scroll', () => {
            if (!ticking) {
                window.requestAnimationFrame(() => {
                    this.handleScroll();
                    this.updateTimeSpent(lastScrollTime);
                    lastScrollTime = Date.now();
                    ticking = false;
                });
                ticking = true;
            }
        });
    }

    handleScroll() {
        const sections = document.querySelectorAll('.chapter');
        const viewportHeight = window.innerHeight;
        let visibleSections = 0;
        let totalSections = sections.length;

        sections.forEach(section => {
            if (this.isElementInViewport(section)) {
                this.markSectionAsRead(section.id);
                visibleSections++;
            }
        });

        this.updateProgressBar();
    }

    markSectionAsRead(sectionId) {
        const storage = this.getStorage();
        const tutorial = storage.tutorials[this.currentTutorial];
        if (!tutorial.completedSections.includes(sectionId)) {
            tutorial.completedSections.push(sectionId);
            this.saveStorage(storage);
        }
    }

    updateProgressBar() {
        const storage = this.getStorage();
        const tutorial = storage.tutorials[this.currentTutorial];
        const completedSections = tutorial.completedSections.length;
        const totalSections = document.querySelectorAll('.chapter').length;
        const progressPercentage = ((completedSections / totalSections) * 100).toFixed(2);
        this.progressBar.style.width = `${progressPercentage}%`;
    }

    getStorage() {
        return JSON.parse(localStorage.getItem(this.storageKey));
    }

    saveStorage(storage) {
        localStorage.setItem(this.storageKey, JSON.stringify(storage));
    }

    isElementInViewport(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }

    updateTimeSpent(lastScrollTime) {
        const currentTime = Date.now();
        const timeSpent = currentTime - lastScrollTime;
        const storage = this.getStorage();
        const tutorial = storage.tutorials[this.currentTutorial];
        tutorial.timeSpent += timeSpent;
        this.saveStorage(storage);
    }
} 