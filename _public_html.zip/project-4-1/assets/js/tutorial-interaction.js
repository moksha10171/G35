class TutorialQuiz {
    constructor() {
        this.bindEvents();
        this.initializeNavigation();
    }

    bindEvents() {
        document.querySelectorAll('.btn-submit-quiz').forEach(button => {
            button.addEventListener('click', (e) => this.handleQuizSubmit(e));
        });
    }

    initializeNavigation() {
        document.querySelectorAll('.chapter-item a').forEach(link => {
            link.addEventListener('click', (e) => this.handleNavigation(e));
        });
    }

    handleNavigation(e) {
        e.preventDefault();
        const targetId = e.currentTarget.getAttribute('href').substring(1);
        const targetSection = document.getElementById(targetId);
        
        // Update active state
        document.querySelectorAll('.chapter-item').forEach(item => {
            item.classList.remove('active');
        });
        e.currentTarget.closest('.chapter-item').classList.add('active');

        // Scroll to section
        targetSection.scrollIntoView({ behavior: 'smooth' });
    }

    handleQuizSubmit(e) {
        const quizContainer = e.target.closest('.chapter-quiz');
        const questions = quizContainer.querySelectorAll('.quiz-question');
        let score = 0;
        const results = [];

        questions.forEach(question => {
            const selected = question.querySelector('input[type="radio"]:checked');
            if (!selected) return;

            const isCorrect = selected.value === question.dataset.correct;
            if (isCorrect) score++;

            results.push({
                question: question.querySelector('h4').textContent,
                selected: selected.nextElementSibling.textContent,
                correct: question.dataset.correct,
                isCorrect
            });
        });

        this.showResults(quizContainer, score, results, questions.length);
    }

    showResults(container, score, results, total) {
        const resultsDiv = container.querySelector('.quiz-results');
        const scoreDiv = resultsDiv.querySelector('.score');
        const reviewDiv = resultsDiv.querySelector('.answers-review');

        scoreDiv.innerHTML = `
            <h5>Your Score: ${score}/${total}</h5>
            <p>Percentage: ${Math.round((score/total) * 100)}%</p>
        `;

        reviewDiv.innerHTML = results.map(result => `
            <div class="answer-review ${result.isCorrect ? 'correct' : 'incorrect'}">
                <p><strong>${result.question}</strong></p>
                <p>Your answer: ${result.selected}</p>
                ${!result.isCorrect ? `<p>Correct answer: ${result.correct}</p>` : ''}
            </div>
        `).join('');

        resultsDiv.classList.remove('hidden');
    }
}

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', () => {
    new TutorialQuiz();
}); 