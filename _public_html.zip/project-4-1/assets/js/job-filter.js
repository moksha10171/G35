// Add this at the top of the file, outside the class
window.applicationModal = {
    show: async (jobId, jobTitle) => {
        const modal = document.querySelector('.modal');
        if (!modal) return;
        
        modal.style.display = 'block';
        
        try {
            // Fetch job details
            const response = await fetch(`/project-4-1/api/fetch_job_details.php?id=${jobId}`);
            const data = await response.json();
            
            if (!data.success) {
                throw new Error(data.error || 'Failed to load job details');
            }
            
            const job = data.data;
            
            // Update modal content
            modal.querySelector('.job-title').textContent = job.title;
            modal.querySelector('.company-name').textContent = job.company_name;
            modal.querySelector('.job-description').innerHTML = job.description;
            modal.querySelector('.requirements-list').innerHTML = formatList(job.requirements);
            modal.querySelector('.benefits-list').innerHTML = formatList(job.benefits);
            modal.querySelector('.company-description').innerHTML = job.company_description;
            
            // Update skills list
            const skillsList = modal.querySelector('.skills-list');
            if (skillsList && job.required_skills) {
                skillsList.innerHTML = job.required_skills
                    .map(skill => `<span class="skill-tag">${skill}</span>`)
                    .join('');
            }
            
            // Set job ID in the form
            const jobIdInput = modal.querySelector('#jobId');
            if (jobIdInput) {
                jobIdInput.value = jobId;
            }
            
        } catch (error) {
            console.error('Error loading job details:', error);
            alert('Failed to load job details. Please try again.');
        }
    },
    hide: () => {
        const modal = document.querySelector('.modal');
        if (modal) {
            modal.style.display = 'none';
        }
    }
};

// Helper function for formatting lists
function formatList(items) {
    if (!items || !Array.isArray(items)) return '';
    return `<ul>${items.map(item => `<li>${item}</li>`).join('')}</ul>`;
}

class JobFilter {
    constructor() {
        this.currentFilters = {
            search: '',
            job_type: [],
            experience: [],
            location: '',
            salary_min: '',
            skills: [],
            sort: 'recent',
            page: 1
        };
        
        this.sliderTimeout = null;
        this.init();
    }
    
    init() {
        this.bindFilterEvents();
        this.loadJobs();
        this.initSalarySlider();
        this.initBookmarks();
        this.initSkillsFilter();
    }
    
    bindFilterEvents() {
        // Search and location inputs
        ['search', 'location'].forEach(filterType => {
            document.querySelector(`#${filterType}Input`)?.addEventListener('input', 
                debounce((e) => {
                    this.currentFilters[filterType] = e.target.value;
                    this.currentFilters.page = 1;
                    this.loadJobs();
                }, 500)
            );
        });

        // Checkbox filters (job type and experience)
        ['job_type', 'experience'].forEach(filterType => {
            document.querySelectorAll(`input[name="${filterType}"]`).forEach(checkbox => {
                checkbox.addEventListener('change', (e) => {
                    const checkedBoxes = document.querySelectorAll(`input[name="${filterType}"]:checked`);
                    this.currentFilters[filterType] = Array.from(checkedBoxes).map(cb => cb.value);
                    this.currentFilters.page = 1;
                    this.loadJobs();
                });
            });
        });

        // Salary range slider
        const salarySlider = document.querySelector('#salaryRange');
        if (salarySlider) {
            salarySlider.addEventListener('change', (e) => {
                this.currentFilters.salary_min = e.target.value;
                this.currentFilters.page = 1;
                this.loadJobs();
                document.querySelector('#salaryValue').textContent = 
                    `$${Number(e.target.value).toLocaleString()}`;
            });
        }

        // Pagination
        document.querySelector('.pagination')?.addEventListener('click', (e) => {
            if (e.target.matches('[data-page]')) {
                e.preventDefault();
                const page = parseInt(e.target.dataset.page);
                if (page && !isNaN(page)) {
                    this.currentFilters.page = page;
                    this.loadJobs();
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                }
            }
        });

        // Add sort options handler
        document.querySelector('#sortOptions')?.addEventListener('change', (e) => {
            this.currentFilters.sort = e.target.value;
            this.currentFilters.page = 1;
            this.loadJobs();
        });
    }
    
    async loadJobs() {
        try {
            this.showLoader();
            const queryString = new URLSearchParams(this.currentFilters).toString();
            const response = await fetch(`/project-4-1/api/fetch_jobs.php?${queryString}`);
            const data = await response.json();
            
            if (data.success) {
                this.renderJobs(data.data.jobs);
                this.updatePagination(data.data.pages);
                this.updateJobCount(data.data.total);
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            this.showError('Error loading jobs: ' + error.message);
        } finally {
            this.hideLoader();
        }
    }

    renderJobs(jobs) {
        const jobsContainer = document.querySelector('#jobsContainer');
        if (!jobsContainer) return;

        if (!jobs || jobs.length === 0) {
            jobsContainer.innerHTML = this.getNoJobsTemplate();
            return;
        }

        jobsContainer.innerHTML = jobs.map(job => this.getJobCardTemplate(job)).join('');
    }

    getJobCardTemplate(job) {
        return `
            <div class="job-card" data-job-id="${job.id}">
                <div class="job-card-header">
                    <img src="${job.company_logo || '/project-4-1/assets/images/default-company.png'}" 
                         alt="${job.company_name}" 
                         class="company-logo">
                    <div class="job-info">
                        <h3 class="job-title">${job.title}</h3>
                        <div class="company-info">
                            <span class="company-name">${job.company_name}</span>
                            ${job.company_rating ? `
                                <div class="company-rating">
                                    ${this.getStarRating(parseFloat(job.company_rating))}
                                </div>
                            ` : ''}
                        </div>
                    </div>
                </div>
                
                <div class="job-meta">
                    ${job.location ? `<span><i class="fas fa-map-marker-alt"></i> ${job.location}</span>` : ''}
                    ${job.job_type ? `<span><i class="fas fa-briefcase"></i> ${job.job_type}</span>` : ''}
                    <span><i class="fas fa-dollar-sign"></i> ${job.salary_min} - ${job.salary_max}</span>
                    ${job.experience_level ? `<span><i class="fas fa-layer-group"></i> ${job.experience_level}</span>` : ''}
                </div>
                
                ${job.skills && job.skills.length > 0 ? `
                    <div class="job-skills">
                        ${job.skills.slice(0, 4).map(skill => 
                            `<span class="skill-tag">${skill}</span>`
                        ).join('')}
                        ${job.skills.length > 4 ? `
                            <span class="skill-tag more-skills">+${job.skills.length - 4}</span>
                        ` : ''}
                    </div>
                ` : ''}
                
                <div class="job-actions">
                    <button class="btn-apply" onclick="applicationModal.show(${job.id})">
                        <i class="fas fa-paper-plane"></i>
                        Apply Now
                    </button>
                    <button class="bookmark-btn ${this.isBookmarked(job.id) ? 'active' : ''}" 
                            data-job-id="${job.id}" 
                            aria-label="${this.isBookmarked(job.id) ? 'Remove from bookmarks' : 'Save job'}">
                        <i class="fa-${this.isBookmarked(job.id) ? 'solid' : 'regular'} fa-bookmark"></i>
                    </button>
                </div>
            </div>
        `;
    }

    getStarRating(rating) {
        // Check if rating is valid
        if (!rating || isNaN(rating)) {
            return '';
        }

        rating = parseFloat(rating);
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 >= 0.5;
        const emptyStars = 5 - Math.ceil(rating);
        
        return `
            ${`<i class="fas fa-star"></i>`.repeat(fullStars)}
            ${hasHalfStar ? '<i class="fas fa-star-half-alt"></i>' : ''}
            ${`<i class="far fa-star"></i>`.repeat(emptyStars)}
            <span class="rating-value">${rating.toFixed(1)}</span>
        `;
    }

    getNoJobsTemplate() {
        return `
            <div class="no-jobs">
                <i class="fas fa-search"></i>
                <h3>No jobs found</h3>
                <p>Try adjusting your search criteria</p>
            </div>
        `;
    }

    showLoader() {
        const jobsContainer = document.querySelector('#jobsContainer');
        if (jobsContainer) {
            jobsContainer.innerHTML = `
                <div class="loader">
                    <div class="spinner"></div>
                    <p>Loading jobs...</p>
                </div>
            `;
        }
    }

    hideLoader() {
        const loader = document.querySelector('.loader');
        if (loader) {
            loader.remove();
        }
    }

    showError(message) {
        const jobsContainer = document.querySelector('#jobsContainer');
        if (jobsContainer) {
            jobsContainer.innerHTML = `
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <p>${message}</p>
                </div>
            `;
        }
    }

    updateJobCount(total) {
        const jobCount = document.querySelector('#jobCount');
        if (jobCount) {
            jobCount.textContent = total;
        }
    }

    updatePagination(totalPages) {
        const pagination = document.querySelector('.pagination');
        if (!pagination || totalPages <= 1) {
            pagination.innerHTML = '';
            return;
        }

        let html = '';
        const currentPage = this.currentFilters.page;

        // Previous button
        html += `<button class="page-link" data-page="${currentPage - 1}" ${currentPage === 1 ? 'disabled' : ''}>
            <i class="fas fa-chevron-left"></i>
        </button>`;

        // Page numbers
        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - 1 && i <= currentPage + 1)) {
                html += `<button class="page-link ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</button>`;
            } else if (i === currentPage - 2 || i === currentPage + 2) {
                html += `<span class="page-ellipsis">...</span>`;
            }
        }

        // Next button
        html += `<button class="page-link" data-page="${currentPage + 1}" ${currentPage === totalPages ? 'disabled' : ''}>
            <i class="fas fa-chevron-right"></i>
        </button>`;

        pagination.innerHTML = html;
    }

    initSalarySlider() {
        const slider = document.getElementById('salaryRange');
        const salaryValue = document.getElementById('salaryValue');
        const sliderSection = document.querySelector('.salary-slider');
        
        if (!slider || !salaryValue || !sliderSection) return;

        const formatSalary = (value) => {
            return value >= 1000 ? 
                `$${(value/1000).toFixed(0)}k` : 
                `$${value}`;
        };

        const updateSlider = (value) => {
            // Update visual elements immediately
            const percentage = (value / slider.max) * 100;
            slider.style.setProperty('--slider-percentage', `${percentage}%`);
            salaryValue.textContent = formatSalary(value);
            
            // Clear existing timeout
            if (this.sliderTimeout) {
                clearTimeout(this.sliderTimeout);
            }

            // Set new timeout for API call
            this.sliderTimeout = setTimeout(() => {
                this.currentFilters.salary_min = value;
                this.currentFilters.page = 1;
                this.loadJobs();
                
                // Add loading state
                sliderSection.classList.add('loading');
                setTimeout(() => {
                    sliderSection.classList.remove('loading');
                }, 400);
            }, 400);
        };

        // Initial setup
        updateSlider(slider.value);

        // Event listeners
        slider.addEventListener('input', (e) => {
            updateSlider(e.target.value);
        });

        slider.addEventListener('touchend', (e) => {
            updateSlider(e.target.value);
        });
    }

    initBookmarks() {
        // Initialize bookmarks from localStorage
        this.bookmarks = new Set(JSON.parse(localStorage.getItem('bookmarks') || '[]'));

        // Delegate event listener for bookmark buttons
        document.addEventListener('click', (e) => {
            const bookmarkBtn = e.target.closest('.bookmark-btn');
            if (!bookmarkBtn) return;

            const jobId = bookmarkBtn.dataset.jobId;
            if (!jobId) return;

            this.toggleBookmark(jobId, bookmarkBtn);
        });
    }

    isBookmarked(jobId) {
        return this.bookmarks.has(jobId.toString());
    }

    toggleBookmark(jobId, button) {
        // Toggle bookmark state
        const isNowBookmarked = !this.isBookmarked(jobId);
        
        // Animate the button
        this.animateBookmarkButton(button, isNowBookmarked);

        // Update bookmarks set and localStorage
        if (isNowBookmarked) {
            this.bookmarks.add(jobId.toString());
        } else {
            this.bookmarks.delete(jobId.toString());
        }
        
        localStorage.setItem('bookmarks', JSON.stringify([...this.bookmarks]));

        // Update UI
        this.updateBookmarkUI(button, isNowBookmarked);

        // Optional: Show feedback toast
        this.showBookmarkFeedback(isNowBookmarked);
    }

    animateBookmarkButton(button, isBookmarked) {
        // Remove existing animation classes
        button.classList.remove('bookmark-animation-add', 'bookmark-animation-remove');
        
        // Force reflow
        void button.offsetWidth;
        
        // Add appropriate animation class
        button.classList.add(isBookmarked ? 'bookmark-animation-add' : 'bookmark-animation-remove');
        
        const icon = button.querySelector('i');
        if (icon) {
            icon.className = `fa-${isBookmarked ? 'solid' : 'regular'} fa-bookmark`;
            
            // Add pop animation
            icon.style.transform = 'scale(1.2)';
            setTimeout(() => {
                icon.style.transform = 'scale(1)';
            }, 200);
        }
    }

    updateBookmarkUI(button, isBookmarked) {
        button.classList.toggle('active', isBookmarked);
        button.setAttribute('aria-label', 
            isBookmarked ? 'Remove from bookmarks' : 'Save job'
        );
    }

    showBookmarkFeedback(isBookmarked) {
        // Create toast element if it doesn't exist
        let toast = document.getElementById('bookmarkToast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'bookmarkToast';
            toast.className = 'toast';
            document.body.appendChild(toast);
        }

        // Update toast content and show it
        toast.textContent = isBookmarked ? 'Job saved to bookmarks' : 'Job removed from bookmarks';
        toast.className = 'toast show';

        // Hide toast after 3 seconds
        setTimeout(() => {
            toast.className = 'toast';
        }, 3000);
    }

    initSkillsFilter() {
        const skillsSearch = document.querySelector('.skills-search input');
        const skillsContainer = document.querySelector('.popular-skills');

        if (skillsSearch) {
            skillsSearch.addEventListener('input', debounce((e) => {
                const searchTerm = e.target.value.toLowerCase();
                this.searchSkills(searchTerm);
            }, 300));
        }

        if (skillsContainer) {
            skillsContainer.addEventListener('click', (e) => {
                const skillTag = e.target.closest('.skill-tag');
                if (skillTag) {
                    this.toggleSkill(skillTag.textContent.trim());
                }
            });
        }
    }

    searchSkills(searchTerm) {
        const skillTags = document.querySelectorAll('.skill-tag');
        skillTags.forEach(tag => {
            const skill = tag.textContent.toLowerCase();
            tag.style.display = skill.includes(searchTerm) ? 'inline-flex' : 'none';
        });
    }

    toggleSkill(skill) {
        const index = this.currentFilters.skills.indexOf(skill);
        const skillTags = document.querySelectorAll('.skill-tag');
        
        skillTags.forEach(tag => {
            if (tag.textContent.trim() === skill) {
                if (index === -1) {
                    this.currentFilters.skills.push(skill);
                    tag.classList.add('active');
                } else {
                    this.currentFilters.skills.splice(index, 1);
                    tag.classList.remove('active');
                }
            }
        });

        // Add loading state
        const skillsSection = document.querySelector('.popular-skills');
        if (skillsSection) {
            skillsSection.classList.add('loading');
        }

        this.currentFilters.page = 1;
        this.loadJobs().finally(() => {
            if (skillsSection) {
                skillsSection.classList.remove('loading');
            }
        });
    }

    async handleApplicationSubmit(event) {
        event.preventDefault();
        const form = event.target;
        const submitBtn = form.querySelector('button[type="submit"]');
        const formData = new FormData(form);

        try {
            submitBtn.disabled = true;
            submitBtn.classList.add('loading');

            const response = await fetch('/project-4-1/api/submit_application.php', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.success) {
                this.showSuccessMessage('Application submitted successfully!');
                window.applicationModal.hide();
            } else {
                throw new Error(data.error || 'Failed to submit application');
            }
        } catch (error) {
            this.showError(error.message);
        } finally {
            submitBtn.disabled = false;
            submitBtn.classList.remove('loading');
        }
    }

    initializeModalTabs() {
        document.querySelectorAll('.tab-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                // Remove active class from all tabs and panes
                document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
                document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('active'));
                
                // Add active class to clicked tab and corresponding pane
                e.target.classList.add('active');
                const tabId = e.target.dataset.tab;
                document.getElementById(tabId).classList.add('active');
            });
        });

        // Initialize application form submission
        const applicationForm = document.getElementById('applicationForm');
        if (applicationForm) {
            applicationForm.addEventListener('submit', this.handleApplicationSubmit.bind(this));
        }
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    new JobFilter();
});

// Debounce helper
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
} 