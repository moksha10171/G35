document.addEventListener('DOMContentLoaded', () => {
    // Close modal when clicking outside
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.style.display = 'none';
        }
    });

    // Handle form submission
    const applicationForm = document.getElementById('applicationForm');
    if (applicationForm) {
        applicationForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(applicationForm);
            const submitButton = applicationForm.querySelector('button[type="submit"]');
            
            try {
                submitButton.disabled = true;
                submitButton.classList.add('loading');

                const response = await fetch('/project-4-1/api/submit_application.php', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (!data.success) {
                    throw new Error(data.error || 'Failed to submit application');
                }

                // Show success message and close modal
                alert('Application submitted successfully!');
                document.querySelector('.modal').style.display = 'none';
                
            } catch (error) {
                alert(error.message);
            } finally {
                submitButton.disabled = false;
                submitButton.classList.remove('loading');
            }
        });
    }
}); 