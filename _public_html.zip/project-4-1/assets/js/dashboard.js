class DashboardManager {
    constructor() {
        this.initializeElements();
        this.bindEvents();
        this.loadDashboardData();
        this.setupRealTimeUpdates();
    }

    setupRealTimeUpdates() {
        // Update dashboard data every 5 seconds
        this.updateIntervals = {
            notifications: setInterval(() => this.updateNotifications(), 5000),
            stats: setInterval(() => this.updateStats(), 5000),
            activity: setInterval(() => this.updateActivity(), 5000)
        };
    }

    async updateNotifications() {
        try {
            const response = await fetch('/project-4-1/api/get-latest.php');
            const data = await response.json();
            if (data.success) {
                this.updateNotificationBadges(data.data);
            }
        } catch (error) {
            console.error('Error updating notifications:', error);
        }
    }

    async updateStats() {
        try {
            const response = await fetch('/project-4-1/api/stats.php');
            const data = await response.json();
            if (data.success) {
                this.updateDashboardStats(data.data);
            }
        } catch (error) {
            console.error('Error updating stats:', error);
        }
    }

    async handleSearch(value) {
        if (value.length === 0) {
            this.searchClear.style.display = 'none';
            this.clearSearchResults();
            return;
        }

        this.searchClear.style.display = 'block';
        try {
            const response = await fetch('/project-4-1/api/global.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').content
                },
                body: JSON.stringify({ query: value })
            });
            
            const data = await response.json();
            if (data.success) {
                this.displaySearchResults(data.data);
            }
        } catch (error) {
            console.error('Search error:', error);
        }
    }

    displaySearchResults(results) {
        const resultsContainer = document.querySelector('.search-results');
        if (!resultsContainer) return;

        resultsContainer.innerHTML = results.map(item => `
            <div class="search-result-item">
                <div class="result-icon">
                    <i class="fas ${this.getResultIcon(item.type)}"></i>
                </div>
                <div class="result-content">
                    <h4>${item.title}</h4>
                    <p>${item.description}</p>
                </div>
            </div>
        `).join('');
    }

    getResultIcon(type) {
        const icons = {
            job: 'fa-briefcase',
            company: 'fa-building',
            user: 'fa-user',
            post: 'fa-file-alt'
        };
        return icons[type] || 'fa-search';
    }

    async loadDashboardData() {
        try {
            this.showLoadingState();
            await Promise.all([
                this.loadStats(),
                this.loadActivity(),
                this.loadRecommendedJobs()
            ]);
            this.hideLoadingState();
        } catch (error) {
            console.error('Error loading dashboard data:', error);
            this.showError('Failed to load dashboard data');
        }
    }

    showLoadingState() {
        document.querySelectorAll('.loading-placeholder').forEach(placeholder => {
            placeholder.style.display = 'flex';
        });
    }

    hideLoadingState() {
        document.querySelectorAll('.loading-placeholder').forEach(placeholder => {
            placeholder.style.display = 'none';
        });
    }

    async loadStats() {
        try {
            const response = await fetch('/project-4-1/api/dashboard/stats.php');
            const data = await response.json();

            if (data.success) {
                this.updateStatsDisplay(data.data);
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            console.error('Error loading stats:', error);
            this.showError('Failed to load statistics');
        }
    }

    updateStatsDisplay(stats) {
        const cards = {
            applications: {
                total: stats.applications?.total || 0,
                change: stats.applications?.change || 0
            },
            interviews: {
                total: stats.interviews?.total || 0,
                change: stats.interviews?.change || 0
            },
            profileViews: {
                total: stats.profile_views?.total || 0,
                change: stats.profile_views?.change || 0
            }
        };

        Object.entries(cards).forEach(([key, data]) => {
            const card = document.querySelector(`.stat-card.${key}`);
            if (!card) return;

            const numberEl = card.querySelector('.stat-number');
            const trendEl = card.querySelector('.trend-indicator');
            const trendValueEl = card.querySelector('.trend-value');

            numberEl.textContent = data.total;
            
            const trendIcon = data.change > 0 ? 'fa-arrow-up' : 
                            data.change < 0 ? 'fa-arrow-down' : 'fa-minus';
            const trendClass = data.change > 0 ? 'up' : 
                             data.change < 0 ? 'down' : 'neutral';

            trendEl.innerHTML = `<i class="fas ${trendIcon}"></i>`;
            trendEl.className = `trend-indicator ${trendClass}`;
            trendValueEl.textContent = `${Math.abs(data.change)}%`;
        });
    }

    async loadActivity() {
        try {
            const response = await fetch('/project-4-1/api/activity.php?limit=5');
            const data = await response.json();

            if (data.success) {
                this.updateActivityList(data.data);
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            console.error('Error loading activity:', error);
            this.showError('Failed to load recent activity');
        }
    }

    updateActivityList(activities) {
        const activityList = document.querySelector('.activity-list');
        if (!activityList) return;

        activityList.innerHTML = activities.map(activity => `
            <div class="activity-item">
                <div class="activity-icon ${activity.type}">
                    <i class="fas ${this.getActivityIcon(activity.type)}"></i>
                </div>
                <div class="activity-details">
                    <p class="activity-text">${this.formatActivityText(activity)}</p>
                    <span class="activity-time">${this.formatTimeAgo(activity.created_at)}</span>
                </div>
            </div>
        `).join('');
    }

    formatActivityText(activity) {
        switch (activity.type) {
            case 'application':
                return `Applied for ${activity.job_title} at ${activity.company_name}`;
            case 'profile_view':
                return `Your profile was viewed by ${activity.company_name}`;
            case 'interview':
                return `Interview scheduled for ${activity.job_title} position`;
            default:
                return activity.details;
        }
    }

    showError(message) {
        // Implement your error display logic here
        const errorDiv = document.createElement('div');
        errorDiv.className = 'alert alert-danger';
        errorDiv.textContent = message;
        document.body.appendChild(errorDiv);
    }

    initializeElements() {
        // Navigation elements
        this.sidebar = document.querySelector('.dashboard-sidebar');
        this.dashboardMain = document.querySelector('.dashboard-main');
        this.menuToggle = document.querySelector('.menu-toggle');
        this.sidebarToggle = document.querySelector('.sidebar-toggle');
        this.searchToggle = document.querySelector('.search-toggle');
        this.searchBar = document.querySelector('.search-bar');
        this.searchInput = document.querySelector('.search-bar input');
        this.searchClear = document.querySelector('.search-clear');
        
        // User menu elements
        this.userMenu = document.querySelector('.user-menu');
        this.userDropdown = document.querySelector('.user-dropdown');
        
        // Notification elements
        this.notificationBtns = document.querySelectorAll('.nav-btn');
        
        // Track sidebar state
        this.sidebarOpen = !this.isMobile;
    }

    bindEvents() {
        // Menu toggle events
        this.menuToggle?.addEventListener('click', () => this.toggleSidebar());
        this.sidebarToggle?.addEventListener('click', () => this.toggleSidebar());

        // Search functionality
        this.searchToggle?.addEventListener('click', () => this.toggleSearch());
        this.searchInput?.addEventListener('input', this.debounce((e) => this.handleSearch(e.target.value), 300));
        this.searchClear?.addEventListener('click', () => this.clearSearch());

        // User menu events
        document.addEventListener('click', (e) => this.handleClickOutside(e));
        this.userMenu?.addEventListener('click', () => this.toggleUserMenu());
        
        // Keyboard navigation
        this.userMenu?.addEventListener('keydown', (e) => this.handleKeyboardNavigation(e));

        // Window resize handler
        window.addEventListener('resize', this.debounce(() => this.handleResize(), 150));

        // Close dropdown on scroll
        this.dashboardMain?.addEventListener('scroll', this.debounce(() => this.closeUserMenu(), 150));
    }

    toggleSidebar() {
        this.sidebarOpen = !this.sidebarOpen;
        this.sidebar.classList.toggle('collapsed');
        this.dashboardMain.classList.toggle('expanded');
        
        // Store preference
        localStorage.setItem('sidebarOpen', this.sidebarOpen);
        
        // Trigger resize event for charts/grids
        window.dispatchEvent(new Event('resize'));
    }

    toggleSearch() {
        this.searchBar.classList.toggle('active');
        if (this.searchBar.classList.contains('active')) {
            this.searchInput.focus();
        }
    }

    handleSearch(value) {
        if (value.length > 0) {
            this.searchClear.style.display = 'block';
        } else {
            this.searchClear.style.display = 'none';
        }
        
        // Implement your search logic here
        console.log('Searching for:', value);
    }

    clearSearch() {
        this.searchInput.value = '';
        this.searchClear.style.display = 'none';
        this.searchInput.focus();
    }

    toggleUserMenu() {
        const isOpen = this.userMenu.classList.contains('active');
        
        // Close all other dropdowns first
        this.closeAllDropdowns();
        
        if (!isOpen) {
            this.userMenu.classList.add('active');
            this.userDropdown.classList.add('show');
        }
    }

    closeUserMenu() {
        this.userMenu.classList.remove('active');
        this.userDropdown.classList.remove('show');
    }

    closeAllDropdowns() {
        document.querySelectorAll('.nav-btn.active').forEach(btn => {
            btn.classList.remove('active');
        });
        this.closeUserMenu();
    }

    handleClickOutside(event) {
        if (!this.userMenu?.contains(event.target)) {
            this.closeUserMenu();
        }
    }

    handleKeyboardNavigation(event) {
        if (event.key === 'Escape') {
            this.closeUserMenu();
        } else if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.toggleUserMenu();
        }
    }

    handleResize() {
        const wasNotMobile = !this.isMobile;
        this.isMobile = window.innerWidth <= 768;
        
        // Handle transition from desktop to mobile
        if (wasNotMobile && this.isMobile) {
            this.sidebar.classList.add('collapsed');
            this.sidebarOpen = false;
        }
        
        // Handle transition from mobile to desktop
        if (!wasNotMobile && !this.isMobile) {
            this.sidebar.classList.remove('collapsed');
            this.sidebarOpen = true;
        }
    }

    setupNotifications() {
        // WebSocket connection for real-time notifications
        this.setupWebSocket();
        
        // Initialize notification counters
        this.updateNotificationBadges();
    }

    setupWebSocket() {
        // Implement your WebSocket connection here
        console.log('Setting up WebSocket connection...');
    }

    updateNotificationBadges() {
        // Update notification badges with actual counts
        // This is a placeholder - implement your actual logic
        const counts = {
            messages: 2,
            notifications: 3
        };

        this.notificationBtns.forEach(btn => {
            const type = btn.getAttribute('title').toLowerCase();
            const badge = btn.querySelector('.badge');
            if (badge && counts[type]) {
                badge.textContent = counts[type];
                if (counts[type] > 0) {
                    badge.classList.add('pulse');
                }
            }
        });
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
}

// Initialize dashboard
document.addEventListener('DOMContentLoaded', () => {
    window.dashboard = new DashboardManager();
});

document.addEventListener('DOMContentLoaded', function() {
    const searchToggle = document.querySelector('.search-toggle');
    const searchWrapper = document.querySelector('.search-wrapper');
    const searchInput = document.querySelector('.search-bar input');
    const searchClear = document.querySelector('.search-clear');

    // Toggle search on mobile
    searchToggle.addEventListener('click', () => {
        searchWrapper.classList.toggle('active');
        if (searchWrapper.classList.contains('active')) {
            searchInput.focus();
        }
    });

    // Clear search
    searchClear.addEventListener('click', () => {
        searchInput.value = '';
        searchInput.focus();
    });

    // Close search on click outside
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.nav-left') && searchWrapper.classList.contains('active')) {
            searchWrapper.classList.remove('active');
        }
    });

    // Close search on escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && searchWrapper.classList.contains('active')) {
            searchWrapper.classList.remove('active');
        }
    });
}); 

async function fetchLatestUpdates() {
    try {
        const response = await fetch('/api/notifications/get-latest.php');
        const data = await response.json();
        
        if (data.success) {
            updateNotificationBadges(data.data.counts);
            updateNotificationDropdown(data.data.notifications);
            updateMessagesList(data.data.messages);
            updateActivityFeed(data.data.activities);
        }
    } catch (error) {
        console.error('Error fetching updates:', error);
    }
}

// Call initially and set up interval
fetchLatestUpdates();
setInterval(fetchLatestUpdates, 5000);