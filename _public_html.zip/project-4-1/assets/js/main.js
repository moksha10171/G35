// Header Scroll Effect
window.addEventListener('scroll', () => {
    const header = document.querySelector('.header');
    if (window.scrollY > 50) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
});

// Sidebar Toggle
const sidebarToggle = document.querySelector('.sidebar-toggle');
const sidebar = document.querySelector('.sidebar');
const body = document.body;

sidebarToggle.addEventListener('click', () => {
    sidebar.classList.toggle('active');
    body.style.overflow = sidebar.classList.contains('active') ? 'hidden' : '';
});

// Close sidebar when clicking outside
document.addEventListener('click', (e) => {
    if (sidebar.classList.contains('active') && 
        !sidebar.contains(e.target) && 
        !sidebarToggle.contains(e.target)) {
        sidebar.classList.remove('active');
        body.style.overflow = '';
    }
});
    function htmlEncode(str) {
    const tempDiv = document.createElement('div');
    tempDiv.textContent = str;
    return tempDiv.innerHTML;
}

// Close sidebar on escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && sidebar.classList.contains('active')) {
        sidebar.classList.remove('active');
        body.style.overflow = '';
    }
});
// Word Definition Feature
class WordDefinition {
    constructor() {
        this.timeout = null;
        this.container = this.createContainer();
        this.selectedRange = null; // Store the selected range
        this.apiKey = 'YN6ZP5KTV1oHumagAsjFA7xyfBEGaRxkMlbMWg6V';
        this.init();
    }

    createContainer() {
        const container = document.createElement('div');
        container.className = 'word-definition-container';
        document.body.appendChild(container);
        return container;
    }

    init() {
        document.addEventListener('mouseup', (e) => {
            const selection = window.getSelection();
            const selectedText = selection.toString().trim();

            // Clear previous timeout and selection
            if (this.timeout) clearTimeout(this.timeout);

            if (selectedText) {
                const range = selection.getRangeAt(0);
                this.selectedRange = range;
                const rect = range.getBoundingClientRect();

                // Check if it's a single word or multiple words
                const isMultipleWords = selectedText.includes(' ');

                this.timeout = setTimeout(() => {
                    if (isMultipleWords) {
                        this.showOptions(selectedText, {
                            x: rect.left + window.scrollX,
                            y: rect.bottom + window.scrollY
                        });
                    } else {
                        this.showDefinition(selectedText, {
                            x: rect.left + window.scrollX,
                            y: rect.bottom + window.scrollY
                        });
                    }
                }, 100);
            } else if (!this.container.contains(e.target)) {
                this.hideContainer();
            }
        });

        // Modified click handler
        document.addEventListener('click', (e) => {
            // Don't hide if clicking inside the container
            if (this.container.contains(e.target)) {
                return;
            }

            // Don't hide if clicking on the selected text
            if (this.selectedRange) {
                const rect = this.selectedRange.getBoundingClientRect();
                if (e.clientX >= rect.left && 
                    e.clientX <= rect.right && 
                    e.clientY >= rect.top && 
                    e.clientY <= rect.bottom) {
                    return;
                }
            }

            // Hide in all other cases
            this.container.style.display = 'none';
        });

        // Update the close button event listener
        this.container.addEventListener('click', (e) => {
            const closeButton = e.target.closest('.definition-close');
            if (closeButton) {
                this.hideContainer();
            }
        });

        // Close on escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.hideContainer();
            }
        });
    }

    hideContainer() {
        this.container.style.display = 'none';
        this.selectedRange = null;
    }

    async showDefinition(word, position) {
        try {
            // Show loading state
            this.container.innerHTML = `
                <div class="word-definition-loading">
                    <div class="loading-spinner"></div>
                    <span>Finding definition...</span>
                </div>
            `;
            this.positionContainer(position);
            this.container.style.display = 'block';

            // Fetch definition
            const response = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`);
            const data = await response.json();

            if (!response.ok) throw new Error('Word not found');

            // Update to just set the HTML since event handlers are added in formatDefinition
            this.formatDefinition(data[0]);

        } catch (error) {
            this.container.innerHTML = `
                <div class="word-definition-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>${error.message || 'Failed to get definition'}</span>
                    <button class="btn-primary ask-ai" data-word="${this.escapeText(word)}">
                        <i class="fas fa-robot"></i>
                        Ask AI Instead
                    </button>
                </div>
            `;

            // Add click handler for AI button in error state
            const aiButton = this.container.querySelector('.ask-ai');
            aiButton.addEventListener('click', () => {
                const failedWord = aiButton.dataset.word;
                if (failedWord) {
                    this.handleAskAI(failedWord);
                }
            });
        }
    }

    showOptions(text, position) {
        const escapedText = this.escapeText(text);
        this.container.innerHTML = `
            <div class="word-definition options-menu">
                <div class="word-header">
                    <div class="word-title-group">
                        <h3>Selected Text</h3>
                        <p class="selected-text">"${text}"</p>
                    </div>
                    <button type="button" class="definition-close" aria-label="Close">×</button>
                </div>
                <div class="options-actions">
                    <button class="btn-primary ask-ai" data-text="${escapedText}">
                        <i class="fas fa-robot"></i>
                        Ask AI about this
                    </button>
                    <button class="btn-primary generate-quiz" data-text="${escapedText}">
                        <i class="fas fa-question-circle"></i>
                        Generate Quiz
                    </button>
                </div>
            </div>
        `;
        this.positionContainer(position);
        this.container.style.display = 'block';

        // Add click handlers
        const aiButton = this.container.querySelector('.ask-ai');
        const quizButton = this.container.querySelector('.generate-quiz');

        aiButton.addEventListener('click', () => {
            const textToAsk = aiButton.dataset.text;
            this.handleAskAI(textToAsk);
        });

        quizButton.addEventListener('click', () => {
            const textForQuiz = quizButton.dataset.text;
            this.generateQuiz(textForQuiz);
        });
    }

    handleAskAI(text) {
        try {
            const chatInput = document.querySelector('#userInput');
            const sendButton = document.querySelector('#sendBtn');
            const chatToggle = document.querySelector('#chatToggle');
            
            if (chatInput && sendButton && chatToggle) {
                // Properly format the input text
                const prompt = text.includes(' ') 
                    ? `Explain this text: "${text}"`
                    : `Define this word: "${text}"`;
                
                // Set the value using jQuery
                $(chatInput).val(prompt);
                
                // Trigger clicks using jQuery
                $(sendButton).trigger('click');
                $(chatToggle).trigger('click');
                
                // Hide the definition container
                this.hideContainer();
            }
        } catch (error) {
            console.error('Error handling AI request:', error);
        }
    }

    formatDefinition(data) {
        const escapedWord = this.escapeText(data.word);
        const html = `
            <div class="word-definition">
                <div class="word-header">
                    <div class="word-title-group">
                        <h3>${data.word}</h3>
                        ${data.phonetic ? `<span class="phonetic">${data.phonetic}</span>` : ''}
                    </div>
                    <button type="button" class="definition-close" aria-label="Close definition">×</button>
                </div>
                ${data.meanings.map(meaning => `
                    <div class="meaning">
                        <span class="part-of-speech">${meaning.partOfSpeech}</span>
                        <ul class="definitions">
                            ${meaning.definitions.slice(0, 3).map(def => `
                                <li>
                                    <p>${def.definition}</p>
                                    ${def.example ? `<span class="example">"${def.example}"</span>` : ''}
                                </li>
                            `).join('')}
                        </ul>
                    </div>
                `).join('')}
                <div class="ai-actions">
                    <button class="btn-primary ask-ai" data-word="${escapedWord}">
                        <i class="fas fa-robot"></i>
                        Ask AI about this word
                    </button>
                </div>
            </div>
        `;

        // Set the HTML
        this.container.innerHTML = html;

        // Add click handler for AI button
        const aiButton = this.container.querySelector('.ask-ai');
        aiButton.addEventListener('click', () => {
            const word = aiButton.dataset.word;
            if (word) {
                this.handleAskAI(word);
            }
        });

        return html;
    }

    positionContainer(position) {
        const { x, y } = position;
        const containerRect = this.container.getBoundingClientRect();
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        const scrollY = window.scrollY;
        const scrollX = window.scrollX;
        const padding = 20; // Padding from viewport edges

        // Calculate initial position
        let left = x;
        let top = y + 10;

        // Check right edge
        if (left + containerRect.width > viewportWidth - padding) {
            left = viewportWidth - containerRect.width - padding;
        }

        // Check left edge
        if (left < padding) {
            left = padding;
        }

        // Check bottom edge
        if (top + containerRect.height > viewportHeight + scrollY - padding) {
            // Position above the selection if not enough space below
            top = y - containerRect.height - 10;
            
            // If still no space above, position at the bottom of viewport
            if (top < scrollY + padding) {
                top = viewportHeight + scrollY - containerRect.height - padding;
                
                // If viewport is too small, position at top with scrolling
                if (top < scrollY + padding) {
                    top = scrollY + padding;
                }
            }
        }

        // Add smooth transition
        this.container.style.transition = 'all 0.3s ease';
        this.container.style.left = `${left}px`;
        this.container.style.top = `${top}px`;

        // Add responsive positioning for mobile
        if (viewportWidth <= 480) {
            this.container.style.left = `${padding}px`;
            this.container.style.right = `${padding}px`;
            this.container.style.width = `calc(100% - ${padding * 2}px)`;
            this.container.style.bottom = `${padding}px`;
            this.container.style.top = 'auto';
        }
    }

    escapeText(text) {
        return text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;')
            .replace(/\n/g, ' ')
            .trim();
    }

    async generateQuiz(text) {
        try {
            // Show loading state
            this.container.innerHTML = `
                <div class="quiz-loading">
                    <div class="loading-spinner"></div>
                    <span>Generating quiz...</span>
                </div>
            `;

            // Determine category based on text content
            const category = this.determineCategory(text);
            
            // Fetch quiz questions
            const response = await fetch(`https://quizapi.io/api/v1/questions?apiKey=${this.apiKey}&category=${category}&limit=10`);
            const questions = await response.json();

            if (!response.ok) throw new Error('Failed to generate quiz');

            this.displayQuiz(questions);

        } catch (error) {
            this.container.innerHTML = `
                <div class="quiz-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>${error.message || 'Failed to generate quiz'}</span>
                    <button class="btn-primary ask-ai" data-text="${this.escapeText(text)}">
                        <i class="fas fa-robot"></i>
                        Ask AI Instead
                    </button>
                </div>
            `;
        }
    }

    determineCategory(text) {
        const keywords = {
            linux: ['linux', 'unix', 'bash', 'shell', 'terminal', 'command line'],
            docker: ['docker', 'container', 'image', 'dockerfile', 'docker-compose'],
            kubernetes: ['kubernetes', 'k8s', 'pod', 'cluster', 'container orchestration'],
            devops: ['devops', 'ci/cd', 'pipeline', 'jenkins', 'automation', 'deployment'],
            php: ['php', 'laravel', 'symfony', 'composer', 'wordpress', 'drupal'],
            javascript: ['javascript', 'js', 'node', 'react', 'vue', 'angular', 'typescript', 'npm'],
            python: ['python', 'django', 'flask', 'pandas', 'numpy', 'pip'],
            database: ['sql', 'mysql', 'postgresql', 'mongodb', 'database', 'redis'],
            networking: ['network', 'tcp/ip', 'dns', 'http', 'ssl', 'routing'],
            security: ['security', 'encryption', 'firewall', 'authentication', 'oauth'],
            cloud: ['aws', 'azure', 'gcp', 'cloud', 'serverless', 's3'],
            git: ['git', 'github', 'gitlab', 'version control', 'repository']
        };

        const lowercaseText = text.toLowerCase();
        for (const [category, words] of Object.entries(keywords)) {
            if (words.some(word => lowercaseText.includes(word))) {
                return category;
            }
        }

        return 'linux'; // Default category
    }

    displayQuiz(questions) {
        const html = `
            <div class="quiz-container" role="form" aria-label="Quiz questions">
                <div class="quiz-header">
                    <h3 id="quiz-title">Quick Quiz</h3>
                    <button type="button" class="definition-close" aria-label="Close quiz">×</button>
                </div>
                <div class="quiz-content">
                    ${questions.map((q, index) => `
                        <div class="quiz-question" data-question="${index}">
                            <p class="question-text">${this.escapeText(q.question)}</p>
                            <div class="answers-grid">
                                ${Object.entries(q.answers)
                                    .filter(([_, value]) => value !== null && value !== '')
                                    .map(([key, value]) => `
                                        <label class="answer-option">
                                            <input type="radio" name="question_${index}" value="${key}">
                                            <span class="answer-text">${this.escapeText(value)}</span>
                                        </label>
                                    `).join('')}
                            </div>
                        </div>
                    `).join('')}
                </div>
                <div class="quiz-actions">
                    <button class="btn-primary check-answers">
                        <i class="fas fa-check"></i>
                        Check Answers
                    </button>
                </div>
            </div>
        `;

        this.container.innerHTML = html;
        this.setupQuizEventListeners(questions);
    }

    setupQuizEventListeners(questions) {
        // Check answers button
        const checkButton = this.container.querySelector('.check-answers');
        if (checkButton) {
            checkButton.addEventListener('click', (e) => {
                e.preventDefault(); // Prevent default action
                e.stopPropagation(); // Stop event bubbling
                this.checkAnswers(questions);
            });
        }

        // Close button
        const closeButton = this.container.querySelector('.definition-close');
        if (closeButton) {
            closeButton.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.hideContainer();
            });
        }

        // Prevent container from closing when clicking inside
        this.container.addEventListener('click', (e) => {
            e.stopPropagation();
        });
    }

    checkAnswers(questions) {
        try {
            let score = 0;
            let totalAnswered = 0;
            const quizContent = this.container.querySelector('.quiz-content');

            if (!quizContent) {
                throw new Error('Quiz content not found');
            }

            // First pass: Count answers and calculate score
            questions.forEach((q, index) => {
                const questionEl = quizContent.querySelector(`[data-question="${index}"]`);
                if (!questionEl) return;

                const selectedAnswer = questionEl.querySelector('input[type="radio"]:checked');
                if (selectedAnswer) {
                    totalAnswered++;
                    const isCorrect = q.correct_answers[`${selectedAnswer.value}_correct`] === 'true';
                    if (isCorrect) score++;
                }
            });

            // Second pass: Show results and explanations
            questions.forEach((q, index) => {
                const questionEl = quizContent.querySelector(`[data-question="${index}"]`);
                if (!questionEl) return;

                const selectedAnswer = questionEl.querySelector('input[type="radio"]:checked');
                const allAnswers = questionEl.querySelectorAll('.answer-option');

                allAnswers.forEach(answerEl => {
                    const input = answerEl.querySelector('input[type="radio"]');
                    const isCorrect = q.correct_answers[`${input.value}_correct`] === 'true';
                    
                    // Add visual feedback
                    if (input === selectedAnswer || isCorrect) {
                        answerEl.classList.add(isCorrect ? 'correct' : 'incorrect');
                    }
                    
                    // Disable all inputs
                    input.disabled = true;
                });

                // Add explanation if available
                if (q.explanation) {
                    const explanationDiv = document.createElement('div');
                    explanationDiv.className = 'answer-explanation';
                    explanationDiv.innerHTML = `
                        <i class="fas fa-info-circle"></i>
                        <p>${this.escapeText(q.explanation)}</p>
                    `;
                    questionEl.appendChild(explanationDiv);
                }
            });

            // Update quiz actions with results
            const quizActions = this.container.querySelector('.quiz-actions');
            if (quizActions) {
                const resultHtml = `
                    ${totalAnswered < questions.length 
                        ? '<div class="quiz-feedback" role="alert">Please answer all questions</div>' 
                        : ''}
                    <div class="quiz-results">
                        <div class="quiz-score" role="status">
                            <span class="score-text">Your Score: ${score}/${questions.length}</span>
                            <div class="score-percentage">
                                ${Math.round((score / questions.length) * 100)}%
                            </div>
                        </div>
                        ${totalAnswered === questions.length ? `
                            <div class="score-message">
                                ${score === questions.length ? 'Perfect score! Excellent work!' :
                                  score >= questions.length * 0.7 ? 'Great job! Keep it up!' :
                                  score >= questions.length * 0.5 ? 'Good effort! Room for improvement.' :
                                  'Keep practicing! You can do better!'}
                            </div>
                        ` : ''}
                    </div>
                    <div class="quiz-buttons">
                        <button class="btn-primary try-again">
                            <i class="fas fa-redo"></i>
                            Try Again
                        </button>
                    </div>
                `;

                quizActions.innerHTML = resultHtml;

                // Add try again handler
                const tryAgainButton = quizActions.querySelector('.try-again');
                if (tryAgainButton) {
                    tryAgainButton.addEventListener('click', (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        this.displayQuiz(questions);
                    });
                }
            }

        } catch (error) {
            console.error('Error checking answers:', error);
            this.showQuizError('An error occurred while checking answers');
        }
    }

    showQuizError(message) {
        if (this.container) {
            this.container.innerHTML = `
                <div class="quiz-error" role="alert">
                    <i class="fas fa-exclamation-circle" aria-hidden="true"></i>
                    <p>${this.escapeText(message)}</p>
                    <button class="btn-primary try-again" type="button">
                        Try Again
                    </button>
                </div>
            `;
        }
    }
}

// Auto-initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new WordDefinition();
});

// Alternative approach using IIFE (Immediately Invoked Function Expression)
(() => {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => new WordDefinition());
    } else {
        new WordDefinition();
    }
})();