class ProfileManager {
    constructor() {
        this.initializeElements();
        this.bindEvents();
        this.setupValidation();
        this.updateCharCount();
    }

    initializeElements() {
        this.form = document.getElementById('profileUpdateForm');
        this.elements = {
            name: document.getElementById('name'),
            phone: document.getElementById('phone'),
            location: document.getElementById('location'),
            title: document.getElementById('title'),
            company: document.getElementById('company'),
            bio: document.getElementById('bio'),
            bioCount: document.getElementById('bioCharCount'),
            profileImage: document.getElementById('profileImage'),
            preview: document.getElementById('profilePreview')
        };
    }

    bindEvents() {
        // Form submission
        this.form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveChanges();
        });

        // Bio character count
        this.elements.bio?.addEventListener('input', () => this.updateCharCount());

        // Image preview
        this.elements.profileImage?.addEventListener('change', (e) => this.handleImagePreview(e));

        // Real-time validation
        Object.entries(this.elements).forEach(([key, element]) => {
            if (element && key !== 'preview' && key !== 'bioCount') {
                element.addEventListener('input', (e) => this.validateField(e.target));
            }
        });
    }

    setupValidation() {
        // Phone validation
        this.elements.phone?.addEventListener('input', (e) => {
            const phone = e.target.value.trim();
            const isValid = this.validatePhone(phone);
            this.toggleValidationUI(e.target, isValid);
        });

        // Name validation
        this.elements.name?.addEventListener('input', (e) => {
            const name = e.target.value.trim();
            const isValid = name.length >= 2 && name.length <= 25;
            this.toggleValidationUI(e.target, isValid);
        });

        // Required fields validation
        ['title', 'company'].forEach(field => {
            this.elements[field]?.addEventListener('input', (e) => {
                const value = e.target.value.trim();
                this.toggleValidationUI(e.target, value.length > 0);
            });
        });
    }

    validateField(element) {
        let isValid = true;
        const value = element.value.trim();

        switch (element.id) {
            case 'name':
                isValid = value.length >= 2 && value.length <= 25;
                break;
            case 'phone':
                isValid = !value || this.validatePhone(value);
                break;
            case 'title':
            case 'company':
                isValid = value.length > 0;
                break;
            case 'bio':
                isValid = value.length <= 500;
                break;
        }

        this.toggleValidationUI(element, isValid);
        return isValid;
    }

    validatePhone(phone) {
        return !phone || /^[0-9+\-\s()]{10,15}$/.test(phone);
    }

    toggleValidationUI(element, isValid) {
        if (!element) return;
        
        element.classList.remove('is-valid', 'is-invalid');
        element.classList.add(isValid ? 'is-valid' : 'is-invalid');

        // Find or create validation feedback element
        let feedback = element.parentElement.querySelector('.validation-feedback');
        if (!feedback) {
            feedback = document.createElement('div');
            feedback.className = 'validation-feedback';
            element.parentElement.appendChild(feedback);
        }

        // Show validation message if invalid
        if (!isValid) {
            feedback.textContent = this.getValidationMessage(element);
            feedback.style.color = '#dc2626'; // Red color for error
        } else {
            feedback.textContent = '';
        }
    }

    getValidationMessage(element) {
        switch (element.id) {
            case 'name':
                return 'Name must be between 2 and 25 characters';
            case 'phone':
                return 'Please enter a valid phone number';
            case 'title':
                return 'Job title is required';
            case 'company':
                return 'Company name is required';
            case 'bio':
                return 'Bio must not exceed 500 characters';
            default:
                return 'This field is required';
        }
    }

    updateCharCount() {
        if (this.elements.bio && this.elements.bioCount) {
            const count = this.elements.bio.value.length;
            this.elements.bioCount.textContent = count;
            this.elements.bioCount.parentElement.classList.toggle('text-red-500', count > 500);
        }
    }

    handleImagePreview(event) {
        const file = event.target.files[0];
        if (!file) return;

        if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
            this.showNotification('Please select a valid image file (JPG, PNG, or WebP)', 'error');
            return;
        }

        if (file.size > 5 * 1024 * 1024) {
            this.showNotification('Image size must be less than 5MB', 'error');
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            this.elements.preview.src = e.target.result;
        };
        reader.readAsDataURL(file);
    }

    async saveChanges() {
        try {
            // Validate form before submission
            if (!this.isFormValid()) {
                throw new Error('Please fill in all required fields correctly');
            }

            this.showLoadingState(true);
            const formData = new FormData(this.form);
            
            const response = await fetch('/project-4-1/api/update_profile.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || 'Failed to update profile');
            }

            this.showNotification('Profile updated successfully', 'success');
            setTimeout(() => location.reload(), 1500);

        } catch (error) {
            this.showNotification(error.message, 'error');
        } finally {
            this.showLoadingState(false);
        }
    }

    isFormValid() {
        let isValid = true;
        const requiredFields = ['name', 'title', 'company'];

        // Check required fields
        requiredFields.forEach(fieldId => {
            const element = document.getElementById(fieldId);
            if (!element?.value.trim()) {
                this.toggleValidationUI(element, false);
                isValid = false;
            }
        });

        // Validate name length
        const nameField = document.getElementById('name');
        if (nameField) {
            const nameValue = nameField.value.trim();
            if (nameValue.length < 2 || nameValue.length > 25) {
                this.toggleValidationUI(nameField, false);
                isValid = false;
            }
        }

        // Validate phone if provided
        const phoneField = document.getElementById('phone');
        if (phoneField && phoneField.value.trim()) {
            const isPhoneValid = this.validatePhone(phoneField.value.trim());
            if (!isPhoneValid) {
                this.toggleValidationUI(phoneField, false);
                isValid = false;
            }
        }

        // Validate bio length if provided
        const bioField = document.getElementById('bio');
        if (bioField && bioField.value.trim().length > 500) {
            this.toggleValidationUI(bioField, false);
            isValid = false;
        }

        return isValid;
    }

    showLoadingState(isLoading) {
        const saveBtn = this.form.querySelector('button[type="submit"]');
        if (!saveBtn) return;

        if (isLoading) {
            saveBtn.disabled = true;
            saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        } else {
            saveBtn.disabled = false;
            saveBtn.innerHTML = '<i class="fas fa-save"></i> Save Changes';
        }
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
                <span>${message}</span>
            </div>
            <button onclick="this.parentElement.remove()" aria-label="Close">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        // Remove existing notifications
        document.querySelectorAll('.notification').forEach(n => n.remove());
        
        document.body.appendChild(notification);
        setTimeout(() => notification.remove(), 5000);
    }

    resetForm() {
        this.form.reset();
        this.elements.preview.src = '/assets/images/default-avatar.png';
    }
}

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', () => {
    window.profileManager = new ProfileManager();
}); 