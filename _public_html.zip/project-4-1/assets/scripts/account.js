function getcsrftoken(){
  return document.querySelector('meta[name="csrf-token"]').getAttribute('content');
}
var is_loggingin = false;
var ntwk = 1;
function login_section() {
    if (is_loggingin) return;
    if(ntwk == 1){
    is_loggingin = true;

    try {
        const email = $("#email").val();
        const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        if (!emailRegex.test(email)) {
            is_loggingin = false; 
            return;
        }
        var formData = new FormData();
        formData.append("password", password);
        formData.append("email", email);

        $.ajax({
            type: 'POST',
            url: '/project-4-1/assets/account/login',
            headers: { 'x-csrf-token': getcsrftoken() },
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                const r = JSON.parse(response);
                if (r && r.status === 'success') {
                    window.location.href = "https://www.bmreducation.in/project-4-1/app/";
                } else {
                    snackbarmessage('Can\'t fetch now. Try again later');
                }
            },
            error: function() {
                snackbarmessage('Can\'t fetch now. Try again later');
            },
            complete: function() {
                is_loggingin = false;
            }
        });
    } catch (error) {
        snackbarmessage("An error occurred. Please try again.");
        is_loggingin = false;
    }
    } else{
        handleNetworkStatusChange();
    }
}

var is_signingin = false;
function signup_section() {
    if (is_signingin) return;
    if(ntwk == 1){
    is_signingin = true;

    try {
        const email = $("#email").val();
        const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        if (!emailRegex.test(email)) {
            is_signingin = false; 
            return;
        }
        var formData = new FormData();
        formData.append("password", password);
        formData.append("email", email);

        $.ajax({
            type: 'POST',
            url: '/project-4-1/assets/account/login',
            headers: { 'x-csrf-token': getcsrftoken() },
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                const r = JSON.parse(response);
                if (r && r.status === 'success') {
                    window.location.href = "https://www.bmreducation.in/project-4-1/app/";
                } else {
                    snackbarmessage('Can\'t fetch now. Try again later');
                }
            },
            error: function() {
                snackbarmessage('Can\'t fetch now. Try again later');
            },
            complete: function() {
                is_signingin = false;
            }
        });
    } catch (error) {
        snackbarmessage("An error occurred. Please try again.");
        is_signingin = false;
    }
    } else{
        handleNetworkStatusChange();
    }
}

function handleNetworkStatusChange() {
    if (navigator.onLine) {
        ntwk = 1;
        snackbarmessage("The webpage is online.");
    } else {
        ntwk = 0;
        snackbarmessage("The webpage is offline.");
    }
}
$(window).on('online', function() {
    handleNetworkStatusChange();
});

// Add this function to animate numbers
function animateNumbers() {
    $('.stat-card h3').each(function() {
        const $this = $(this);
        const targetNumber = parseInt($this.text());
        $({ Counter: 0 }).animate({
            Counter: targetNumber
        }, {
            duration: 2000,
            easing: 'swing',
            step: function() {
                $this.text(Math.ceil(this.Counter));
            },
            complete: function() {
                $this.text(targetNumber + '+');
            }
        });
    });
}

// Add this to your existing scroll handler
$(window).on('scroll', function() {
    requestAnimationFrame(function() {
        animateProductGrids();
        if (isInViewport('.stats')) {
            animateNumbers();
        }
    });
});

// Add this function for testimonial carousel
function initTestimonialCarousel() {
    let currentSlide = 0;
    const $carousel = $('.testimonial-carousel');
    const $cards = $('.testimonial-card');
    const totalSlides = $cards.length;
    
    function updateCarousel() {
        const translateValue = -currentSlide * 100;
        $carousel.css('transform', `translateX(${translateValue}%)`);
        updateIndicators();
    }
    
    function updateIndicators() {
        $('.carousel-indicators .indicator').removeClass('active')
            .eq(currentSlide).addClass('active');
    }
    
    // Create indicators
    const $indicators = $('.carousel-indicators');
    for (let i = 0; i < totalSlides; i++) {
        $indicators.append($('<div>').addClass('indicator')
            .on('click', () => {
                currentSlide = i;
                updateCarousel();
            }));
    }
    
    // Add click handlers for navigation buttons
    $('.prev-btn').on('click', () => {
        currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
        updateCarousel();
    });
    
    $('.next-btn').on('click', () => {
        currentSlide = (currentSlide + 1) % totalSlides;
        updateCarousel();
    });
    
    // Auto-advance carousel
    setInterval(() => {
        currentSlide = (currentSlide + 1) % totalSlides;
        updateCarousel();
    }, 5000);
    
    // Initialize first slide
    updateCarousel();
}

// Call this when document is ready
$(document).ready(function() {
    initTestimonialCarousel();
});

