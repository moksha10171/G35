var  ntwk = 1;
var isSidebarOpen = localStorage.getItem('sidebarOpen') === 'true';
    if (isSidebarOpen) {
        var browserWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
        if (browserWidth >= 600) {
        openSidebar();
        }
    } else {
        closeSidebar();
    }

    $("#bmropensidebar").on('click', function() {
        openSidebar();
        localStorage.setItem('sidebarOpen', 'true');
    });

    $("#bmrclosesidebar").on('click', function() {
        closeSidebar();
        localStorage.setItem('sidebarOpen', 'false');
    });
    
    var cpf = 0;
    function tempcloseside(){
         closeSidebar();
         cpf = cpf+1;
        localStorage.setItem('sidebarOpen', 'false');
    }
    $(window).on('resize', function() {
        if (isSidebarOpen) {
        var browserWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
        if (browserWidth >= 600) {
            adjustHeightForOpenSidebar();
        }
        } else {
            adjustHeightForClosedSidebar();
        }
        handleSidebarOnResize();
    });
    function allthesidebarmomet(){
    if (isSidebarOpen) {
        var browserWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
        if (browserWidth >= 600) {
            adjustHeightForOpenSidebar();
        }
        } else {
            adjustHeightForClosedSidebar();
        }
    }

    function openSidebar() {
        $("#bmrsidebar_optn_pos").css('left', '0');
        $("#bmr_appmySidebar").css('width', '250px');
        $("#bmr_app_main").css('margin-left', '250px');
        
        var browserWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
        if (browserWidth >= 600) {
        $("#bmr_app_main").css('width', '-webkit-fill-available');
            adjustHeightForOpenSidebar();
        } else{
            $("#bmr_app_main").css('width', '100%');
            adjustHeightForOpenSidebar(27);
        }
        $("#bmrsidebar_optn_pos").css('left', '250px');
        $(".btn_input_sidb").css('position', 'relative');
        $("#bottom_inpt_ai_").css('height', '100vh');
        $("#bmropensidebar").hide();
        $("#bmrclosesidebar").show();
        $("#bmrclosesidebar i,#bmropensidebar i").css({
    'transform': 'scaleX(-1)',
    '-webkit-transform': 'scaleX(-1)', /* For Safari */
    '-ms-transform': 'scaleX(-1)'
});
    }

    function closeSidebar() {
        $("#bmrsidebar_optn_pos").css('left', '0');
        $("#bmr_appmySidebar").css('width', '0');
        $("#bmr_app_main").css('margin-left', '0');
        $("#bmr_app_main").css('width', '100%');
        $("#bmrclosesidebar").hide();
        $("#bmropensidebar").show();
        $("#bmrclosesidebar i,#bmropensidebar i").css({
    'transform': 'scaleX(1)',
    '-webkit-transform': 'scaleX(1)', /* For Safari */
    '-ms-transform': 'scaleX(1)'
});
        setTimeout(function() {
            $(".btn_input_sidb").css('position', 'fixed');
            $("#bottom_inpt_ai_").css('height', 'fit-content');
            adjustHeightForClosedSidebar();
        }, 500);
    }
    var xcvghj = 0;
    function handleSidebarOnResize() {
        var browserWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;

        if (browserWidth < 600) {
            if(xcvghj == 0){
            xcvghj = 1;
            closeSidebar();
            }
        } else {
            if (isSidebarOpen) {
                xcvghj = 0;
                openSidebar();
            } else {
                xcvghj = 0;
                closeSidebar();
            }
        }
    }
    function adjustHeightForOpenSidebar(offset = 0) {
        var browserHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
    }

    function adjustHeightForClosedSidebar(offset = 0) {
        var browserHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
    }
    
function copyToClipboard(dv) {
    if (dv !== "") {
        var $tempInput = $("<input>");
        $("body").append($tempInput);
        $tempInput.val(dv);
        $tempInput.select();
        document.execCommand("copy");
        $tempInput.remove();
        $("#generalinfo1").hide();
        snackbarmessage("Copied");
    } else {
        snackbarmessage("No text to copy");
    }
}

    const allowedfiles = [
        "profile", 'dashboard', 'activity', 'feedback', 'bmreducation','bmreducation_publih_pages', 'bmreducation_section', 'bmreducation_images', 'bmreducation_manage_pages', 'bmreducation_trash', 'bmreducation_authors_list', 'bmreducation_categories', 'bmrblog_publih_article', 'bmrblog', 'bmrblog_images', 'bmrblog_manage_article', 'bmrblog_trash', 'bmrblog_drafts', 'bmrblog_authors_list', 'bmrblog_categories', 'bmrhealthcare', 'bmrhealthcare_publih_article', 'bmrhealthcare_images', 'bmrhealthcare_manage_article', 'bmrhealthcare_trash', 'bmrhealthcare_authors_list', 'bmrhealthcare_categories', 'bmrsupport', 'bmrsupport_publih_article', 'bmrsupport_images', 'bmrsupport_manage_article', 'bmrsupport_trash', 'bmrsupport_authors_list', 'bmrsupport_categories'
    ];
    
function getinfo(getval) {
    if (ntwk === 1) {
        if (allowedfiles.includes(getval)) {
            $("#preloader").html('');
            $.get(`/admin/sec/${getval}`, (r) => {
                $("#result").html(r);

                const mappings = {
                    "dashboard": { path: "", title: "DASHBOARD", header: null },
                    "profile": { path: "profile", title: "PROFILE", header: null },
                    "activity": { path: "activity", title: "ACTIVITY", header: null },
                    "feedback": { path: "feedback", title: "FEEDBACK", header: null },
                    
                    "bmreducation": { path: "education/dashboard", title: "DASHBOARD - BMR EDUCATION", header: "#educationheaderview" },
                    "bmreducation_publih_pages": { path: "education/publish-article", title: "PUBLISH ARTICLE - BMR EDUCATION", header: "#educationheaderview" },
                    "bmreducation_section": { path: "education/section", title: "SECTION - BMR EDUCATION", header: "#educationheaderview" },
                    "bmreducation_images": { path: "education/images", title: "IMAGES - BMR EDUCATION", header: "#educationheaderview" },
                    "bmreducation_manage_pages": { path: "education/manage-article", title: "MANAGE ARTICLE - BMR EDUCATION", header: "#educationheaderview" },
                    "bmreducation_trash": { path: "education/trash", title: "TRASH - BMR EDUCATION", header: "#educationheaderview" },
                    "bmreducation_authors_list": { path: "education/authors", title: "AUTHORS - BMR EDUCATION", header: "#educationheaderview" },
                    "bmreducation_categories": { path: "education/category", title: "CATEGORY - BMR EDUCATION", header: "#educationheaderview" },
                    
                    "bmrblog": { path: "blog/dashboard", title: "DASHBOARD - BMR BLOG", header: "#blogheaderview" },
                    "bmrblog_publih_article": { path: "blog/publish-article", title: "PUBLISH ARTICLE - BMR BLOG", header: "#blogheaderview" },
                    "bmrblog_images": { path: "blog/images", title: "IMAGES - BMR BLOG", header: "#blogheaderview" },
                    "bmrblog_manage_article": { path: "blog/manage-article", title: "MANAGE ARTICLE - BMR BLOG", header: "#blogheaderview" },
                    "bmrblog_trash": { path: "blog/trash", title: "TRASH - BMR BLOG", header: "#blogheaderview" },
                    "bmrblog_authors_list": { path: "blog/authors", title: "AUTHORS - BMR BLOG", header: "#blogheaderview" },
                    "bmrblog_categories": { path: "blog/category", title: "CATEGORY - BMR BLOG", header: "#blogheaderview" },
                    "bmrblog_drafts": { path: "blog/drafts", title: "DRAFTS - BMR BLOG", header: "#blogheaderview" },
                    
                    "bmrhealthcare": { path: "healthcare/dashboard", title: "DASHBOARD - BMR HEALTHCARE", header: "#heathcareheaderview" },
                    "bmrhealthcare_publih_article": { path: "healthcare/publish-article", title: "PUBLISH ARTICLE - BMR HEALTHCARE", header: "#heathcareheaderview" },
                    "bmrhealthcare_images": { path: "healthcare/images", title: "IMAGES - BMR HEALTHCARE", header: "#heathcareheaderview" },
                    "bmrhealthcare_manage_article": { path: "healthcare/manage-article", title: "MANAGE ARTICLE - BMR HEALTHCARE", header: "#heathcareheaderview" },
                    "bmrhealthcare_trash": { path: "healthcare/trash", title: "TRASH - BMR HEALTHCARE", header: "#heathcareheaderview" },
                    "bmrhealthcare_authors_list": { path: "healthcare/authors", title: "AUTHORS - BMR HEALTHCARE", header: "#heathcareheaderview" },
                    "bmrhealthcare_categories": { path: "healthcare/category", title: "CATEGORY - BMR HEALTHCARE", header: "#heathcareheaderview" },
                    
                    "bmrsupport": { path: "support/dashboard", title: "DASHBOARD - BMR SUPPORT", header: "#supportheaderview" },
                    "bmrsupport_publih_article": { path: "support/publish-article", title: "PUBLISH ARTICLE - BMR SUPPORT", header: "#supportheaderview" },
                    "bmrsupport_images": { path: "support/images", title: "IMAGES - BMR SUPPORT", header: "#supportheaderview" },
                    "bmrsupport_manage_article": { path: "support/manage-article", title: "MANAGE ARTICLE - BMR SUPPORT", header: "#supportheaderview" },
                    "bmrsupport_trash": { path: "support/trash", title: "TRASH - BMR SUPPORT", header: "#supportheaderview" },
                    "bmrsupport_authors_list": { path: "support/authors", title: "AUTHORS - BMR SUPPORT", header: "#supportheaderview" },
                    "bmrsupport_categories": { path: "support/category", title: "CATEGORY - BMR SUPPORT", header: "#supportheaderview" },
                };

                const mapping = mappings[getval] || { path: "", title: "DASHBOARD", header: null };
                const newURL = `https://www.bmreducation.com/admin/${mapping.path}`;
                
                $("#heathcareheaderview,#supportheaderview,#educationheaderview,#blogheaderview").hide();
                
            $(".spl_active").removeClass("spl_active");
                $(".spl_w_active").removeClass("spl_w_active");
            if (mapping.header) {
                    if(mapping.header == '#educationheaderview'){
                $("nav a[onclick=\"getinfo('bmreducation')\"]").addClass('spl_active');
                
               if (!$(`script[src='https://cdn.bmreducation.com/scripts/admin_panel/bmreducation_v4.200.400.js']`).length) {
        $('#scriptsec').html('');
    $('<script>', {
        src: 'https://cdn.bmreducation.com/scripts/admin_panel/bmreducation_v4.200.400.js',
        async: true
    }).appendTo('#scriptsec');
}

                    } else if(mapping.header == '#heathcareheaderview'){
                $("nav a[onclick=\"getinfo('bmrhealthcare')\"]").addClass('spl_active');
                        $('#scriptsec').html('');
                    }else if(mapping.header == '#blogheaderview'){
                $("nav a[onclick=\"getinfo('bmrblog')\"]").addClass('spl_active');
                    
               if (!$(`script[src='https://cdn.bmreducation.com/scripts/admin_panel/bmr_blog_v4.9101.2311.js']`).length) {
        $('#scriptsec').html('');
    $('<script>', {
        src: 'https://cdn.bmreducation.com/scripts/admin_panel/bmr_blog_v4.9101.2311.js',
        async: true
    }).appendTo('#scriptsec');
}
                
                        $('#scriptsec').html('');
                    }else if(mapping.header == '#supportheaderview'){
                $("nav a[onclick=\"getinfo('bmrsupport')\"]").addClass('spl_active');
                        $('#scriptsec').html('');
                    }
                    $(mapping.header).show();
                }
            
            $("#view_panel_xcv a[onclick=\"getinfo('" + getval + "')\"]").addClass('spl_w_active');
            if(getval == 'feedback' || getval == 'activity' || getval == 'profile'){
            $("nav a[onclick=\"getinfo('" + getval + "')\"]").addClass('spl_active');
            
            }else if( getval == ''){
            $("nav a[onclick=\"getinfo('dashboard')\"]").addClass('spl_active');
            }
                history.pushState({}, "", newURL);
                $(document).prop('title', `${mapping.title} | BMR ADMIN PANEL`);
                allthesidebarmomet();
            });
        }
    } else {
        handleNetworkStatusChange();
    }
}
function getinfo_no_change(getval, newTitle) {
    if (ntwk == 1) {
        if (allowedfiles.includes(getval)) {
            $("#preloader").html('');
       $.get("/admin/sec/" + getval)
    .done(function(r) {
        $("#result").html(r);
            $(document).prop('title', newTitle+" | BMR ADMIN PANEL");
    })
    .fail(function(jqXHR, textStatus, errorThrown) {
        
        console.error("Error occurred: " + textStatus, errorThrown);
        $("#result").html("An error occurred while processing the request.");
    });

            allthesidebarmomet();
        }
    } else {
        handleNetworkStatusChange();
    }
}
function handleHistoryChange() {
    var pathArray = window.location.pathname.split("/");
    var getval = pathArray[pathArray.length - 1];
    var getv2 = pathArray[pathArray.length - 2];

    var headerMapping = {
        "admin": { 
            "": { key: "dashboard", title: "DASHBOARD" },
            "profile": { key: "profile", title: "PROFILE" },
            "activity": { key: "activity", title: "ACTIVITY" },
            "feedback": { key: "feedback", title: "FEEDBACK" }
        },
        "blog": {
            "dashboard": { key: "bmrblog", title: "DASHBOARD - BMR BLOG" },
            "publish-article": { key: "bmrblog_publish_article", title: "PUBLISH ARTICLE - BMR BLOG" },
            "images": { key: "bmrblog_images", title: "IMAGES - BMR BLOG" },
            "manage-article": { key: "bmrblog_manage_article", title: "MANAGE ARTICLE - BMR BLOG" },
            "trash": { key: "bmrblog_trash", title: "TRASH - BMR BLOG" },
            "authors": { key: "bmrblog_authors_list", title: "AUTHORS - BMR BLOG" },
            "category": { key: "bmrblog_categories", title: "CATEGORY - BMR BLOG" },
            "drafts": { key: "bmrblog_drafts", title: "DRAFTS - BMR BLOG" }
        },
        "healthcare": {
            "dashboard": { key: "bmrhealthcare", title: "DASHBOARD - BMR HEALTHCARE" },
            "publish-article": { key: "bmrhealthcare_publish_article", title: "PUBLISH ARTICLE - BMR HEALTHCARE" },
            "images": { key: "bmrhealthcare_images", title: "IMAGES - BMR HEALTHCARE" },
            "manage-article": { key: "bmrhealthcare_manage_article", title: "MANAGE ARTICLE - BMR HEALTHCARE" },
            "trash": { key: "bmrhealthcare_trash", title: "TRASH - BMR HEALTHCARE" },
            "authors": { key: "bmrhealthcare_authors_list", title: "AUTHORS - BMR HEALTHCARE" },
            "category": { key: "bmrhealthcare_categories", title: "CATEGORY - BMR HEALTHCARE" }
        },
        "education": {
            "dashboard": { key: "bmreducation", title: "DASHBOARD - BMR EDUCATION" },
            "publish-article": { key: "bmreducation_publish_pages", title: "PUBLISH ARTICLE - BMR EDUCATION" },
            "images": { key: "bmreducation_images", title: "IMAGES - BMR EDUCATION" },
            "manage-article": { key: "bmreducation_manage_pages", title: "MANAGE ARTICLE - BMR EDUCATION" },
            "trash": { key: "bmreducation_trash", title: "TRASH - BMR EDUCATION" },
            "authors": { key: "bmreducation_authors_list", title: "AUTHORS - BMR EDUCATION" },
            "category": { key: "bmreducation_categories", title: "CATEGORY - BMR EDUCATION" },
            "section": { key: "bmreducation_section", title: "SECTION - BMR EDUCATION" }
        },
        "support": {
            "dashboard": { key: "bmrsupport", title: "DASHBOARD - BMR SUPPORT" },
            "publish-article": { key: "bmrsupport_publish_article", title: "PUBLISH ARTICLE - BMR SUPPORT" },
            "images": { key: "bmrsupport_images", title: "IMAGES - BMR SUPPORT" },
            "manage-article": { key: "bmrsupport_manage_article", title: "MANAGE ARTICLE - BMR SUPPORT" },
            "trash": { key: "bmrsupport_trash", title: "TRASH - BMR SUPPORT" },
            "authors": { key: "bmrsupport_authors_list", title: "AUTHORS - BMR SUPPORT" },
            "category": { key: "bmrsupport_categories", title: "CATEGORY - BMR SUPPORT" }
        }
    };

    if (headerMapping[getv2] && headerMapping[getv2][getval]) {
        let { key, title } = headerMapping[getv2][getval];
        
        // Check if key is allowed
        if (allowedfiles.includes(key)) {
            getinfo_no_change(key, title);
            
            // Remove any previous active class
            $(".spl_active").removeClass("spl_active");

            // Highlight the correct menu item
            if (getval == 'feedback' || getval == 'activity' || getval == 'profile') {
                $("nav a[onclick=\"getinfo('" + getval + "')\"]").addClass('spl_active');
            } else if (getval == '') {
                $("nav a[onclick=\"getinfo('dashboard')\"]").addClass('spl_active');
            } else if (getval == 'dashboard') {
                $("nav a[onclick=\"getinfo('bmr" + getv2 + "')\"]").addClass('spl_active');
            } else {
                $("nav a[onclick=\"getinfo('" + key + "')\"]").addClass('spl_active');
            }
        }

    }
}

window.addEventListener('popstate', handleHistoryChange);

handleHistoryChange();

function saveProfile(event) {
    event.preventDefault();
    
    const form = document.getElementById('profileForm');
    const formData = new FormData(form);

    // Show loading state
    const saveBtn = document.querySelector('.btn-primary');
    saveBtn.disabled = true;
    saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';

    fetch('/api/update_profile.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Profile updated successfully', 'success');
        } else {
            throw new Error(data.error || 'Failed to update profile');
        }
    })
    .catch(error => {
        showNotification(error.message, 'error');
    })
    .finally(() => {
        // Reset button state
        saveBtn.disabled = false;
        saveBtn.innerHTML = '<i class="fas fa-save"></i> Save Changes';
    });
}

function resetForm() {
    const form = document.getElementById('profileForm');
    form.reset();
    showNotification('Form has been reset', 'info');
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        </div>
        <button onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 5000);
}
