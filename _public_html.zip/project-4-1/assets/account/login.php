<?php
session_start();
ini_set('log_errors', 1);
ini_set('error_log', '/home/u291518478/domains/bmreducation.in/public_html/project-4-1/logs/error.log');
error_reporting(E_ALL);
ini_set('display_errors', 0);
date_default_timezone_set('Asia/Kolkata');
session_regenerate_id(true);

$ist_zone = new DateTimeZone('Asia/Kolkata');
$date = new DateTime('now', $ist_zone);
$Registered_on = $date->format('Y-m-d H:i:s');
$client = $_SERVER['HTTP_USER_AGENT'];
$Browser = end(explode(" ", $client));
$Operating_system = explode(";", $client)[1] ?? "";
$id = $_SERVER['REMOTE_ADDR'];
$time = time();

$data_api = file_get_contents("http://ip-api.com/json/{$id}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,currency,isp,org,as,query");
$row_api = json_decode($data_api, true);

$isMob = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "mobile"));
$isTab = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "tablet"));
$isWin = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "windows"));
$isAndroid = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "android"));
$isIPhone = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "iphone"));
$isIPad = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "ipad"));
$isIOS = $isIPhone || $isIPad;

$device_platform = $isMob ? ($isTab ? 'Tablet' : 'Mobile') : 'Desktop';
$device_type = $isIOS ? 'iOS' : ($isAndroid ? 'ANDROID' : ($isWin ? 'WINDOWS' : 'OTHER'));
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_SERVER['SCRIPT_URI'] === 'https://www.bmreducation.in/project-4-1/assets/account/login' && $_SERVER['SERVER_NAME'] === 'www.bmreducation.in') {
if (
    isset($_POST['email']) &&
    isset($_POST['password']) &&
    !empty($_POST['email']) &&
    !empty($_POST['password'])
) {
    try {
        $conn = new mysqli('localhost', 'u291518478_project1', 'Moksha@10170+10171', 'u291518478_project1');
        if ($conn->connect_error) {
            throw new Exception("Database connection failed");
        }

        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        $password = $_POST['password'];
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                $tkn = md5(time() . $row['email']) . md5($row['email']);
            $stmt1 = $conn->prepare(
    "INSERT INTO session_access (email, session_id, uid, registered_time, timeid, device_platform, device_type, ip_address, operating_system, browser_info, client_id_info) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
);

$stmt1->bind_param(
    "sssssssssss",
    $row['email'],
    $tkn,
    $row['uid'],
    $Registered_on,
    $time,
                    $device_platform,
                    $device_type,
                    $id,
                    $Operating_system,
                    $Browser,
                    $client
);


                if ($stmt1->execute()) {
                    $_SESSION['session_new_project'] = $tkn;
                    echo json_encode(['status' => 'success']);
                } else {
                    error_log("Invalid Request.");
                    echo json_encode(['status' => 'failed', 'response' => 'Try again Later.']);
                }
            } else {
                error_log("Invalid Request.");
                echo json_encode(['status' => 'failed', 'response' => 'Incorrect email and password.']);
            }
        } else {
            error_log("Invalid Request.");
            echo json_encode(['status' => 'failed', 'response' => 'User not found.']);
        }
    } catch (Exception $e) {
        error_log($e->getMessage());
        echo json_encode(['status' => 'failed', 'response' => 'An error occurred. Please try again later']);
    } finally {
        if (isset($conn)) {
            $conn->close();
        }
    }
} else {
    error_log("Invalid Request.");
    echo json_encode(['status' => 'failed', 'response' => 'Invalid Request 2']);
}
} else {
    error_log("Invalid Request.");
    echo json_encode(['status' => 'failed', 'response' => 'Invalid Request 3']);
}
?>