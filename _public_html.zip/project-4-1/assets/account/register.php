<?php
session_start();
ini_set('log_errors', 1);
ini_set('error_log', '/home/u291518478/domains/bmreducation.in/public_html/project-4-1/logs/error.log');
error_reporting(E_ALL);
ini_set('display_errors', 0);
date_default_timezone_set('Asia/Kolkata');
session_regenerate_id(true);


    function generateRandomString($length) {
        $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        return substr(str_shuffle($characters), 0, $length);
    }

    function generateToken($email) {
        return md5(time()) . md5($email);
    }

    function generateOTP() {
        return rand(100000, 999999);
    }

    function generateMailID() {
        return random_int(1, 9) . generateRandomString(3) . random_int(10, 99) . generateRandomString(1) . random_int(10, 99) . generateRandomString(2) . random_int(10, 99);
    }
    
$ist_zone = new DateTimeZone('Asia/Kolkata');
$date = new DateTime('now', $ist_zone);
$Registered_on = $date->format('d-m-Y H:i:s');
$client = $_SERVER['HTTP_USER_AGENT'];
$Operating_system = explode(";", $client)[1] ?? "";
$Browser = end(explode(" ", $client));
$id = $_SERVER['REMOTE_ADDR'];
$time = time();

$data_api = file_get_contents("http://ip-api.com/json/{$id}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,currency,isp,org,as,query");
$row_api = json_decode($data_api, true);

$isMob = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "mobile"));
$isTab = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "tablet"));
$isWin = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "windows"));
$isAndroid = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "android"));
$isIPhone = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "iphone"));
$isIPad = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "ipad"));
$isIOS = $isIPhone || $isIPad;

$device_platform = $isMob ? ($isTab ? 'Tablet' : 'Mobile') : 'Desktop';
$device_type = $isIOS ? 'iOS' : ($isAndroid ? 'ANDROID' : ($isWin ? 'WINDOWS' : 'OTHER'));
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../../../PHPMailer/src/Exception.php';
require '../../../PHPMailer/src/PHPMailer.php';
require '../../../PHPMailer/src/SMTP.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_SERVER['SCRIPT_URI'] === 'https://www.bmreducation.in/project-4-1/assets/account/register' && $_SERVER['SERVER_NAME'] === 'www.bmreducation.in') {
if (
    isset($_POST['email']) &&
    isset($_POST['password']) &&
    !empty($_POST['email']) &&
    !empty($_POST['password'])
) {
    try {
        $conn = new mysqli('localhost', 'u291518478_project1', 'Moksha@10170+10171', 'u291518478_project1');
        if ($conn->connect_error) {
            throw new Exception("Database connection failed");
        }
        $email = $_POST['email'];
        $password = $_POST['password'];
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        
    $stmt = $conn->prepare("DELETE FROM registration_details WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    $tkn = generateToken($email);
    $otp = generateOTP();
    $mail_id = generateMailID();
    $name = $_POST['firstName'].' '.$_POST['lastName'];
    $Registered_on = date('Y-m-d H:i:s');
    $time = time();
    
    $sql = "INSERT INTO registration_details (name, email, registered_time, password, token, otp, timeid, mailid) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt1 = $conn->prepare($sql);
    $stmt1->bind_param("ssssssss", $name, $email, $Registered_on, $hashedPassword, $tkn, $otp, $time, $mail_id);
    
    if ($stmt1->execute()) {

   $mail = new PHPMailer;
   $mail->isSMTP();
   $mail->SMTPDebug = 0;
   $mail->Host = 'smtp.hostinger.com';
   $mail->Port = 587;
   $mail->SMTPAuth = true;
   $mail->Username = 'login@bmreducation.com';
   $mail->Password = 'Moksha@10171+10170';
   $mail->setFrom('login@bmreducation.com', 'Sign up - TalentSphere');
   $mail->addAddress($email);
   $mail->isHTML(true); 
   $mail->Subject = 'Verify your email';
   $mail->Body = 
   '
   <!DOCTYPE html>
   <html lang="en">
   <head>
       <meta charset="UTF-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <title>Verify Your Account</title>
   </head>
   <body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f4f4f4;">
       <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
           <tr>
               <td style="padding: 20px 0; text-align: center; background: linear-gradient(135deg, #0A2647 0%, #051428 100%);">
                   <h1 style="color: #FFD700; margin: 0; font-size: 28px;">TalentSphere</h1>
               </td>
           </tr>
           <tr>
               <td style="padding: 40px 20px; background: #ffffff;">
                   <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
                       <tr>
                           <td style="padding-bottom: 20px; text-align: center;">
                               <h2 style="color: #0A2647; margin: 0; font-size: 24px;">Verify Your Email</h2>
                           </td>
                       </tr>
                       <tr>
                           <td style="padding-bottom: 20px; text-align: center; color: #666666;">
                               <p style="margin: 0; line-height: 1.6;">Please click the following verification link to complete your registration:</p>
                           </td>
                       </tr>
                       <tr>
                           <td style="padding-bottom: 30px;">
                               <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center;">
                                   <a href="https://www.bmreducation.in/project-4-1/verify?auth='.$tkn.'" style="font-size: 32px; font-weight: bold; color: #0A2647; letter-spacing: 5px;">Verify</a>
                               </div>
                           </td>
                       </tr>
                       <tr>
                           <td style="padding-bottom: 20px; text-align: center; color: #666666;">
                               <p style="margin: 0; font-size: 14px;">This link will expire in 10 minutes.</p>
                           </td>
                       </tr>
                       <tr>
                           <td style="padding-bottom: 20px; text-align: center; color: #666666;">
                               <p style="margin: 0; font-size: 14px;">If you didn\'t request this link, please ignore this email.</p>
                           </td>
                       </tr>
                   </table>
               </td>
           </tr>
           <tr>
               <td style="padding: 20px; text-align: center; background: #f8f9fa; color: #666666;">
                   <p style="margin: 0; font-size: 14px;">Need help? Contact our support team</p>
                   <a href="mailto:support@talentsphere.com" style="color: #0A2647; text-decoration: none; font-weight: 500;">support@talentsphere.com</a>
               </td>
           </tr>
       </table>
   </body>
   </html>';
   if (!$mail->send()) {
        echo 3;
   } else {
       $pupuse = 'OTP Signup';
        $Registered_on = date('Y-m-d H:i:s');
        $time = time();
    $sql = "INSERT INTO mail_record (sender, purpose, mail_id, reg_id, time_id, ip) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt1 = $conn->prepare($sql);
    $stmt1->bind_param("ssssss", $email, $pupuse, $mail_id, $Registered_on, $time, $id);
    if ($stmt1->execute()) {
         echo json_encode(['status' => 'success']);
    } else{
        echo json_encode(['status' => 'success']);
    }
   }
    } else {
            error_log("Invalid Request.");
            echo json_encode(['status' => 'failed', 'response' => 'User not found.']);
        }
    } else {
            echo json_encode(['status' => 'failed', 'response' => 'Already Registered.']);
        }
    } catch (Exception $e) {
        error_log($e->getMessage());
        echo json_encode(['status' => 'failed', 'response' => 'An error occurred. Please try again later']);
    } finally {
        if (isset($conn)) {
            $conn->close();
        }
    }
} else {
    error_log("Invalid Request.");
    echo json_encode(['status' => 'failed', 'response' => 'Invalid Request 2']);
}
} else {
    error_log("Invalid Request.");
    echo json_encode(['status' => 'failed', 'response' => 'Invalid Request 3']);
}
?>