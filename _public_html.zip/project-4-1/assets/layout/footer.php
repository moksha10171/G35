<section class="cta">
            <div class="container">
                <div class="cta-wrapper">
                    <span class="cta-tag">Get Started Today</span>
                    <div class="cta-content">
                        <h2>Ready to Transform Your Hiring?</h2>
                        <p>Join thousands of companies finding their perfect match with our AI-powered platform</p>
                        
                        <div class="cta-buttons">
                            <a href="#" class="btn-primary">
                                Get Started
                                <i class="fas fa-arrow-right"></i>
                            </a>
                            <a href="#" class="btn-secondary">
                                Log In
                                <i class="fas fa-sign-in-alt"></i>
                            </a>
                        </div>

                        <div class="cta-features">
                            <div class="cta-feature">
                                <i class="fas fa-rocket"></i>
                                <span>Quick Setup</span>
                            </div>
                            <div class="cta-feature">
                                <i class="fas fa-clock"></i>
                                <span>14-Day Free Trial</span>
                            </div>
                            <div class="cta-feature">
                                <i class="fas fa-shield-alt"></i>
                                <span>Enterprise Security</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<section class="newsletter">
    <div class="container">
        <div class="newsletter-wrapper">
            <div class="newsletter-header">
                <span class="newsletter-tag">Newsletter</span>
                <h2>Stay Ahead in Insurance Recruitment</h2>
                <p>Get weekly insights on industry trends, recruitment strategies, and exclusive tips delivered to your inbox.</p>
            </div>
            
            <form class="newsletter-form" id="newsletterForm">
                <div class="form-group">
                    <div class="input-wrapper">
                        <i class="far fa-envelope input-icon"></i>
                        <input type="email" 
                               class="newsletter-input" 
                               placeholder="Enter your business email" 
                               required>
                    </div>
                    <button type="submit" class="newsletter-button">
                        Subscribe Now
                        <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            </form>

            <div class="newsletter-features">
                <div class="newsletter-feature">
                    <i class="fas fa-shield-alt"></i>
                    <span>100% Secure & Private</span>
                </div>
                <div class="newsletter-feature">
                    <i class="fas fa-paper-plane"></i>
                    <span>Weekly Curated Content</span>
                </div>
                <div class="newsletter-feature">
                    <i class="fas fa-times-circle"></i>
                    <span>Cancel Any Time</span>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Footer -->
<footer class="footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-column">
                <h3>TalentSphere</h3>
                <p>Revolutionizing insurance industry hiring through AI-powered matching, compliance management, and comprehensive learning solutions.</p>
                <div class="social-icons">
                    <a href="#" class="facebook" aria-label="Facebook">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="#" class="twitter" aria-label="Twitter">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" class="linkedin" aria-label="LinkedIn">
                        <i class="fab fa-linkedin-in"></i>
                    </a>
                    <a href="#" class="instagram" aria-label="Instagram">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="#" class="youtube" aria-label="YouTube">
                        <i class="fab fa-youtube"></i>
                    </a>
                </div>
            </div>

            <div class="footer-column">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="/about">About Us</a></li>
                    <li><a href="/careers">Careers</a></li>
                    <li><a href="/press">Press Room</a></li>
                    <li><a href="/partners">Partners</a></li>
                    <li><a href="/success-stories">Success Stories</a></li>
                </ul>
            </div>

            <div class="footer-column">
                <h3>Solutions</h3>
                <ul>
                    <li><a href="/ai-matching">AI Matching</a></li>
                    <li><a href="/compliance">Compliance</a></li>
                    <li><a href="/analytics">Analytics</a></li>
                    <li><a href="/learning">Learning</a></li>
                    <li><a href="/integrations">Integrations</a></li>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="footer-bottom-left">
                © 2024 TalentSphere. All rights reserved.
            </div>
            <div class="footer-bottom-right">
                <a href="/privacy">Privacy Policy</a>
                <a href="/terms">Terms of Service</a>
                <a href="/cookies">Cookie Policy</a>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
<script src="/project-4-1/assets/js/main.js"></script>
<script src="/project-4-1/assets/js/chat_90.js"></script>
</body>
</html>