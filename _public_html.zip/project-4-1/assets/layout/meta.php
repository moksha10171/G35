<?php
session_start();
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
if (strpos($_SERVER['REQUEST_URI'], '.php') !== false) {
    header('Location: https://www.bmreducation.in'.$cleanPath, true, 301);
    exit();
}

function dbasehost() {
    $servername = "localhost";
    $username = "u291518478_project1";
    $password = "Moksha@10170+10171";
    $dbname = "u291518478_bmr10171_314";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) {
        exit();
    }
    return $conn;
}

function generateMetaTags($title, $description,$img, $url,$keywords) {
    if($img== ''){
        $img = '/project-4-1/assets/images/plogo.png';
    }
     if($url== ''){
        $url = cleanUrl(getCurrentUrl());
    }
    $metaTags = '
    <meta name="description" content="' . htmlspecialchars($description) . '">
    <meta name="keywords" content="'.$keywords.', BMR BUZZ, BMR Education, Online Tools, BMR BUZZ">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>' . htmlspecialchars($title) . '</title>
    <meta property="og:title" content="' . htmlspecialchars($title) . '">
    <meta property="og:description" content="' . htmlspecialchars($description) . '">
    <meta property="og:image" content="'.$img.'">
    <meta property="og:url" content="'.$url.'">
    <meta name="twitter:card" content="summary_large_image"/>
    <meta name="twitter:title" content="'.$title.'" />
    <meta name="twitter:description" content="'.$description.'" />
    <meta name="twitter:url" content="'.$url.'" />
    <meta name="twitter:image" content="'.$img.'" />
    <meta property="twitter:image:width" content="600">
    <meta property="twitter:image:height" content="315">';
    return $metaTags;
}

function cleanUrl($url) {
    $parsedUrl = parse_url($url);
    $cleanUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];

    if (isset($parsedUrl['path'])) {
        $cleanUrl .= $parsedUrl['path'];
    }
    return $cleanUrl;
}

function getCurrentUrl() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https" : "http";
    $url = $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    return $url;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo $_SESSION['csrf_token']; ?>">
    <link rel="icon" type="image/x-icon" href="/project-4-1/assets/images/plogo.png">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link href="/project-4-1/assets/styles/styles.915.20104.css" rel="stylesheet">
    <link href="/project-4-1/assets/styles/chat_20.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="/project-4-1/quizmaster/styles.css">