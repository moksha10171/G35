</head>
<body>
<header class="header">
        <div class="container">
            <nav class="nav">
                <a href="/project-4-1/" class="logo">TalentSphere</a>
                <button class="sidebar-toggle" aria-label="Toggle menu">
                    <i class="fas fa-bars"></i>
                </button>
                <ul class="menu-items">
                    <li><a href="/project-4-1/">Home</a></li>
                    <li><a href="/project-4-1/quizmaster/learning-tracks">Learn</a></li>
                    <li><a href="/project-4-1/quizmaster/quiz">Quizzes</a></li>
                    <li><a href="/project-4-1/quizmaster/compiler-quiz">Compiler Quiz</a></li>
                    <li><a href="/project-4-1/contact">Contact</a></li>
                </ul>
                <div class="auth-buttons">
                    <a href="/project-4-1/login" class="btn gets btn-secondary">Log In</a>
                    <a href="/project-4-1/signup" class="btn gets btn-primary">Sign Up</a>
                </div>
            </nav>
        </div>
    </header>
    <div class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="/project-4-1/">Home</a></li>
            <li><a href="/project-4-1/quizmaster/learning-tracks">Learn</a></li>
            <li><a href="/project-4-1/quizmaster/quiz">Quizzes</a></li>
            <li><a href="/project-4-1/quizmaster/compiler-quiz">Compiler Quiz</a></li>
            <li><a href="/project-4-1/contact">Contact</a></li>
        </ul>
        <div class="sidebar-auth-buttons">
            <a href="/project-4-1/login" class="btn btn-secondary">Log In</a>
            <a href="/project-4-1/signup" class="btn btn-primary">Sign Up</a>
        </div>
    </div>

<button class="chat-toggle" id="chatToggle">
    <i class="fas fa-comments"></i>
</button>
<!-- Chat Widget -->
<div class="chat-widget" id="chatWidget">
    <!-- Header -->
    <div class="chat-header">
        <div class="chat-title">
            <i class="fas fa-user-md"></i>
            <h3>Assistant</h3>
        </div>
        <div class="chat-actions">
            <button class="new-chat-btn" aria-label="New Chat">
                <i class="fas fa-plus"></i>
            </button>
            <button class="minimize-btn" aria-label="Close Chat">
                <i class="fas fa-times"></i>
            </button>
        </div>
    </div>

    <!-- Messages Area -->
    <div class="chat-body" id="chatMessages">
        <div class="message bot-message">
            <div class="message-content">
                <p>👋 Hello! How can I assist you today?</p>
                <span class="time">Now</span>
            </div>
        </div>
    </div>

    <!-- Fixed Bottom Section -->
    <div class="chat-bottom">
        <div class="chat-suggestions">
            <button data-query="courses">Couses</button>
            <button data-query="jobs">Jobs</button>
            <button data-query="skills">Skills</button>
            <button data-query="apply">Apply</button>
            <button data-query="help">Help</button>
            <button data-query="profile">Profile</button>
            <button data-query="about">About</button>
        </div>
        
        <div class="chat-input">
            <div class="input-actions">
                <button class="upload-btn" aria-label="Upload File">
                    <i class="fas fa-paperclip"></i>
                </button>
                <button class="voice-btn" aria-label="Voice Input">
                    <i class="fas fa-microphone"></i>
                </button>
            </div>
            <input type="text" id="userInput" placeholder="Type your message...">
            <button class="send-btn" id="sendBtn" disabled>
                <i class="fas fa-paper-plane"></i>
            </button>
        </div>
    </div>
</div>