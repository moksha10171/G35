<?php
session_start();
    $conn = mysqli_connect('localhost', 'u291518478_bmr10171_314', 'Moksha@10170+10171', 'u291518478_bmr10171_314');
    if (!$conn) {
        echo 400;
    } else {
        if (isset($_SESSION['session_new_project']) && !empty($_SESSION['session_new_project'])) {
            $getlc = 0;
            $account_access = 0;
            $stmt = $conn->prepare("SELECT * FROM session_access WHERE session_id = ?");
            $stmt->bind_param("s", $_SESSION['session_new_project']);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stmt1 = $conn->prepare("DELETE FROM session_access WHERE session_id = ?");
                $stmt1->bind_param("s", $_SESSION['session_new_project']);
                $stmt1->execute();
                if ($stmt1->affected_rows > 0) {
                   $_SESSION['session_new_project'] = '';
                   session_destroy();
                   header('Location: https://www.bmreducation.in/project-4-1/login');
                } else {
                    $conn->close();
                    $_SESSION['session_new_project'] = '';
                    session_destroy();
                    header('Location: https://www.bmreducation.in/project-4-1/login');
                }
            } else {
                $conn->close();
                $_SESSION['session_new_project'] = '';
                session_destroy();
                header('Location: https://www.bmreducation.in/project-4-1/login');
                }
        } else {
            $conn->close();
            $_SESSION['session_new_project'] = '';
            session_destroy();
            header('Location: https://www.bmreducation.in/project-4-1/login');
        }
        $conn->close();
    }
?>