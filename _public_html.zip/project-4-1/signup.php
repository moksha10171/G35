<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('assets/layout/header.php');
$footer = inancap('assets/layout/footer.php');
$meta = inancap('assets/layout/meta.php');
echo $meta;
$descript = 'Sign Up - TalentSphere';
$title = 'Sign Up - TalentSphere';
echo generateMetaTags($title, $descript, '', '', 'Coding, Courses');
echo $header;
?>
<link rel="stylesheet" href="assets/css/style.css">
    <main id="main-content">
        <section class="signup-section">
            <div class="signup-container">
                <div class="signup-header">
                    <h1>Create Your Account</h1>
                    <p class="signup-intro">Join TalentSphere and unlock exclusive features</p>
                </div>
                
                <form id="signup-form" class="signup-form" method="POST" action="/project-4-1/auth/signup">
                    <div class="form-grid">
                        <div class="form-group">
                            <div class="form-label">
                                <label for="firstName">First Name</label>
                            </div>
                            <div class="input-wrapper">
                                <i class="far fa-user input-icon"></i>
                                <input type="text" id="firstName" name="firstName" placeholder="Enter your first name" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="form-label">
                                <label for="lastName">Last Name</label>
                            </div>
                            <div class="input-wrapper">
                                <i class="far fa-user input-icon"></i>
                                <input type="text" id="lastName" name="lastName" placeholder="Enter your last name" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="form-label">
                            <label for="email">Email Address</label>
                        </div>
                        <div class="input-wrapper">
                            <i class="far fa-envelope input-icon"></i>
                            <input type="email" id="email" name="email" placeholder="Enter your email" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="form-label">
                            <label for="password">Password</label>
                        </div>
                        <div class="input-wrapper">
                            <i class="far fa-lock input-icon"></i>
                            <input type="password" id="password" name="password" placeholder="Create a password" required>
                            <button type="button" class="password-toggle">
                                <i class="far fa-eye"></i>
                            </button>
                        </div>
                        <div class="password-strength" id="password-strength"></div>
                    </div>

                    <div class="form-group">
                        <div class="form-label">
                            <label for="confirmPassword">Confirm Password</label>
                        </div>
                        <div class="input-wrapper">
                            <i class="far fa-lock input-icon"></i>
                            <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm your password" required>
                            <button type="button" class="password-toggle">
                                <i class="far fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" id="terms" name="terms" required>
                            <label for="terms">I agree to the <a href="/terms">Terms of Service</a> and <a href="/privacy">Privacy Policy</a></label>
                        </div>
                    </div>

                    <button type="submit" class="btn-block">
                        Create Account
                    </button>

                    <p class="login-link">
                        Already have an account? <a href="/project-4-1/login">Sign in</a>
                    </p>
                </form>
            </div>
        </section>
    </main>

    <script>
        document.querySelectorAll('.password-toggle').forEach(button => {
            button.addEventListener('click', function() {
                const input = this.previousElementSibling;
                const icon = this.querySelector('i');
                
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            });
        });

        // Password strength checker
        const passwordInput = document.getElementById('password');
        const strengthIndicator = document.getElementById('password-strength');

        passwordInput.addEventListener('input', checkPasswordStrength);

        function checkPasswordStrength() {
            const password = passwordInput.value;
            let strength = 0;
            let message = '';

            // Length check
            if (password.length >= 8) strength += 1;
            // Uppercase check
            if (/[A-Z]/.test(password)) strength += 1;
            // Lowercase check
            if (/[a-z]/.test(password)) strength += 1;
            // Number check
            if (/[0-9]/.test(password)) strength += 1;
            // Special character check
            if (/[^A-Za-z0-9]/.test(password)) strength += 1;

            switch(strength) {
                case 0:
                case 1:
                    message = '<span class="weak">Weak</span>';
                    break;
                case 2:
                case 3:
                    message = '<span class="medium">Medium</span>';
                    break;
                case 4:
                case 5:
                    message = '<span class="strong">Strong</span>';
                    break;
            }

            strengthIndicator.innerHTML = message;
        }

        // Form submission handling
        document.getElementById('signup-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            removeAlerts();
            
            const submitButton = e.target.querySelector('button[type="submit"]');
            const originalButtonText = submitButton.innerHTML;
            
            // Get form inputs
            const firstName = document.getElementById('firstName').value.trim();
            const lastName = document.getElementById('lastName').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            // Validation
            if (!firstName || !lastName || !email || !password || !confirmPassword) {
                showError('Please fill in all fields');
                return;
            }
            
            if (!isValidEmail(email)) {
                showError('Please enter a valid email address');
                return;
            }
            
            if (password !== confirmPassword) {
                showError('Passwords do not match');
                return;
            }
            
            if (password.length < 8) {
                showError('Password must be at least 8 characters long');
                return;
            }
            
            setLoading(true, submitButton, originalButtonText);
            
            try {
                const success = await registerUser(firstName, lastName, email, password);
                if (success) {
                    showSuccess('Check your email to verfiy');
                }
            } catch (error) {
                showError(error.message || 'Registration failed. Please try again.');
            } finally {
                setLoading(false, submitButton, originalButtonText);
            }
        });

        // Helper functions (reused from login.php)
        function isValidEmail(email) {
            const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
            return emailRegex.test(email);
        }

        async function registerUser(firstName, lastName, email, password) {
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;
            if (!csrfToken) {
                throw new Error('Security token not found. Please refresh the page.');
            }
            
            try {
                const response = await fetch('/project-4-1/assets/account/register', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'X-CSRF-Token': csrfToken,
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: new URLSearchParams({
                        firstName,
                        lastName,
                        email,
                        password
                    }),
                    credentials: 'same-origin'
                });

                const data = await response.json();
                
                if (!response.ok) {
                    throw new Error(data.message || `Server error: ${response.status}`);
                }
                
                return data.status === 'success';
            } catch (error) {
                console.error('Registration error:', error);
                throw error;
            }
        }

        // Alert and loading functions (reused from login.php)
        function showError(message) {
            const alertDiv = createAlert('danger', message);
            insertAlert(alertDiv);
        }

        function showSuccess(message) {
            const alertDiv = createAlert('success', message);
            insertAlert(alertDiv);
        }

        function createAlert(type, message) {
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type} fade-in`;
            
            const icon = document.createElement('i');
            icon.className = type === 'danger' 
                ? 'fas fa-exclamation-circle mr-2' 
                : 'fas fa-check-circle mr-2';
            
            const messageSpan = document.createElement('span');
            messageSpan.textContent = message;
            
            const closeButton = document.createElement('button');
            closeButton.className = 'alert-close';
            closeButton.innerHTML = '&times;';
            closeButton.onclick = () => alertDiv.remove();
            
            alertDiv.appendChild(icon);
            alertDiv.appendChild(messageSpan);
            alertDiv.appendChild(closeButton);
            
            return alertDiv;
        }

        function insertAlert(alertDiv) {
            const form = document.getElementById('signup-form');
            const existingAlert = form.querySelector('.alert');
            if (existingAlert) {
                existingAlert.remove();
            }
            form.insertBefore(alertDiv, form.firstChild);
        }

        function removeAlerts() {
            document.querySelectorAll('.alert').forEach(alert => alert.remove());
        }

        function setLoading(isLoading, button, originalText) {
            const form = document.getElementById('signup-form');
            const inputs = form.querySelectorAll('input, button');
            
            inputs.forEach(input => input.disabled = isLoading);
            
            if (isLoading) {
                button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating account...';
            } else {
                button.innerHTML = originalText;
            }
        }
    </script>
<?php echo $footer;?> 