<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

$mail = new PHPMailer(true);                            
try {
    $mail->SMTPDebug = 2;                                
    $mail->isSMTP();                                    
    $mail->Host = 'smtp.hostinger.com';                  
    $mail->SMTPAuth = true;                              
    $mail->Username = 'login@bmreducation.com';             
    $mail->Password = 'Moksha@10171+10170';
    $mail->SMTPSecure = 'tls';                            
    $mail->Port = 587;
    $mail->setFrom('login@bmreducation.com', 'Mailer');
    $mail->addAddress('moksha10171@gmail.com', 'Hello');
    $mail->isHTML(true);
    $mail->Subject = 'Subject line goes here';
    $mail->Body    = 'Body text goes here';
    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
}
?>