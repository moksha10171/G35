<?php
function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$header = inancap('../assets/layout/header.php');
$footer = inancap('../assets/layout/footer.php');
$meta = inancap('../assets/layout/meta.php');
echo $meta;
$descript = 'Property & Casualty';
$title = 'AboutProperty & Casualty';
echo generateMetaTags($title, $descript, '', '', 'Property & Casualty, Courses');
echo $header;
?>
<link href="/project-4-1/assets/styles/tutorial-page.css" rel="stylesheet">
<main class="tutorial-content" data-tutorial-id="property-insurance-basics">
    <!-- Enhanced Progress Bar -->
    <div class="tutorial-progress-bar">
        <div class="progress" style="width: 0%"></div>
    </div>

    <!-- Enhanced Tutorial Header -->
    <section class="tutorial-header">
        <div class="container">
            <div class="tutorial-header-content">
                <div class="breadcrumb">
                    <a href="/insurance-tutorials">Tutorials</a>
                    <span class="separator">></span>
                    <a href="#property-casualty">Property & Casualty</a>
                    <span class="separator">></span>
                    <span>Property Insurance Basics</span>
                </div>
                
                <div class="tutorial-meta-wrapper">
                    <h1>Property Insurance Basics</h1>
                    <div class="tutorial-meta">
                        <span class="duration"><i class="far fa-clock"></i> 45 minutes</span>
                        <span class="difficulty"><i class="fas fa-signal"></i> Beginner</span>
                        <span class="category"><i class="fas fa-tag"></i> Property Insurance</span>
                        <span class="progress-indicator">
                            <i class="fas fa-chart-line"></i>
                            <span class="progress-text">0% Complete</span>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Improved Tutorial Layout -->
    <div class="tutorial-layout">
        <!-- Enhanced Navigation Sidebar -->
        <aside class="tutorial-sidebar">
            <nav class="tutorial-nav">
                <div class="nav-header">
                    <h3>Course Contents</h3>
                    <div class="course-progress">
                        <svg class="progress-ring" width="40" height="40">
                            <circle class="progress-ring-circle-bg" cx="20" cy="20" r="16"></circle>
                            <circle class="progress-ring-circle" cx="20" cy="20" r="16"></circle>
                            <text class="progress-text" x="20" y="20" text-anchor="middle" dominant-baseline="middle">0%</text>
                        </svg>
                    </div>
                </div>

                <div class="chapters-list">
                    <!-- Introduction -->
                    <div class="chapter-item active">
                        <a href="#introduction">
                            <div class="chapter-marker" data-chapter-id="introduction">
                                <span class="chapter-number">1</span>
                                <div class="completion-indicator"></div>
                            </div>
                            <div class="chapter-info">
                                <span class="chapter-title">Introduction to Property Insurance</span>
                                <div class="chapter-meta">
                                    <span class="duration"><i class="far fa-clock"></i> 15 min</span>
                                    <span class="status">In Progress</span>
                                </div>
                            </div>
                        </a>
                    </div>

                    <!-- Coverage Types -->
                    <div class="chapter-item">
                        <a href="#coverage-types">
                            <div class="chapter-marker" data-chapter-id="coverage-types">
                                <span class="chapter-number">2</span>
                                <div class="completion-indicator"></div>
                            </div>
                            <div class="chapter-info">
                                <span class="chapter-title">Types of Coverage</span>
                                <div class="chapter-meta">
                                    <span class="duration"><i class="far fa-clock"></i> 20 min</span>
                                    <span class="status">Not Started</span>
                                </div>
                            </div>
                        </a>
                    </div>

                    <!-- Policy Components -->
                    <div class="chapter-item">
                        <a href="#policy-components">
                            <div class="chapter-marker" data-chapter-id="policy-components">
                                <span class="chapter-number">3</span>
                                <div class="completion-indicator"></div>
                            </div>
                            <div class="chapter-info">
                                <span class="chapter-title">Policy Components</span>
                                <div class="chapter-meta">
                                    <span class="duration"><i class="far fa-clock"></i> 25 min</span>
                                    <span class="status">Not Started</span>
                                </div>
                            </div>
                        </a>
                    </div>

                    <!-- Risk Assessment -->
                    <div class="chapter-item">
                        <a href="#risk-assessment">
                            <div class="chapter-marker" data-chapter-id="risk-assessment">
                                <span class="chapter-number">4</span>
                                <div class="completion-indicator"></div>
                            </div>
                            <div class="chapter-info">
                                <span class="chapter-title">Risk Assessment</span>
                                <div class="chapter-meta">
                                    <span class="duration"><i class="far fa-clock"></i> 30 min</span>
                                    <span class="status">Not Started</span>
                                </div>
                            </div>
                        </a>
                    </div>

                    <!-- Property Valuation -->
                    <div class="chapter-item">
                        <a href="#property-valuation">
                            <div class="chapter-marker" data-chapter-id="property-valuation">
                                <span class="chapter-number">5</span>
                                <div class="completion-indicator"></div>
                            </div>
                            <div class="chapter-info">
                                <span class="chapter-title">Property Valuation Methods</span>
                                <div class="chapter-meta">
                                    <span class="duration"><i class="far fa-clock"></i> 25 min</span>
                                    <span class="status">Not Started</span>
                                </div>
                            </div>
                        </a>
                    </div>

                    <!-- Claims Process -->
                    <div class="chapter-item">
                        <a href="#claims-process">
                            <div class="chapter-marker" data-chapter-id="claims-process">
                                <span class="chapter-number">6</span>
                                <div class="completion-indicator"></div>
                            </div>
                            <div class="chapter-info">
                                <span class="chapter-title">Claims Process</span>
                                <div class="chapter-meta">
                                    <span class="duration"><i class="far fa-clock"></i> 35 min</span>
                                    <span class="status">Not Started</span>
                                </div>
                            </div>
                        </a>
                    </div>

                    <!-- Final Assessment -->
                    <div class="chapter-item">
                        <a href="#final-assessment">
                            <div class="chapter-marker" data-chapter-id="final-assessment">
                                <span class="chapter-number">7</span>
                                <div class="completion-indicator"></div>
                            </div>
                            <div class="chapter-info">
                                <span class="chapter-title">Final Assessment</span>
                                <div class="chapter-meta">
                                    <span class="duration"><i class="far fa-clock"></i> 45 min</span>
                                    <span class="status">Not Started</span>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </nav>

            <!-- Mobile Navigation Toggle -->
            <button class="nav-toggle" aria-label="Toggle Navigation">
                <i class="fas fa-bars"></i>
            </button>
        </aside>

        <!-- Enhanced Main Content Area -->
        <article class="tutorial-content">
            <!-- Example of an improved chapter section -->
            <section id="introduction" class="chapter" data-chapter="1">
                <h2>1. Introduction to Property Insurance</h2>
                <div class="chapter-content">
                    <div class="content-block">
                        <h3>Understanding Property Insurance</h3>
                        <p>Property insurance provides financial protection against losses or damage to property caused by covered perils such as fire, theft, natural disasters, and other risks.</p>
                        
                        <div class="key-points">
                            <h4>Key Concepts</h4>
                            <ul>
                                <li>Financial protection for property owners</li>
                                <li>Coverage against various risks and perils</li>
                                <li>Risk assessment and management</li>
                                <li>Policy structure and components</li>
                            </ul>
                        </div>

                        <div class="content-section">
                            <h4>Importance of Property Insurance</h4>
                            <p>Property insurance plays a crucial role in protecting assets and ensuring financial security. It helps:</p>
                            <ul>
                                <li>Protect investment in property</li>
                                <li>Maintain financial stability</li>
                                <li>Meet legal requirements</li>
                                <li>Provide peace of mind</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Chapter 2: Types of Coverage -->
            <section id="coverage-types" class="chapter" data-chapter="2">
                <h2>2. Types of Property Insurance Coverage</h2>
                <div class="chapter-content">
                    <div class="content-block">
                        <h3>Coverage Categories</h3>
                        <div class="coverage-grid">
                            <div class="coverage-card">
                                <h4>Residential Coverage</h4>
                                <ul>
                                    <li>Single-family homes</li>
                                    <li>Condominiums</li>
                                    <li>Rental properties</li>
                                    <li>Personal belongings</li>
                                </ul>
                            </div>
                            <div class="coverage-card">
                                <h4>Commercial Coverage</h4>
                                <ul>
                                    <li>Office buildings</li>
                                    <li>Retail spaces</li>
                                    <li>Business equipment</li>
                                    <li>Inventory protection</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Chapter 3: Policy Components -->
            <section id="policy-components" class="chapter" data-chapter="3">
                <h2>3. Understanding Policy Structure</h2>
                <div class="chapter-content">
                    <div class="content-block">
                        <h3>Key Policy Elements</h3>
                        <div class="policy-components">
                            <div class="component-card">
                                <h4>Coverage Limits</h4>
                                <p>Maximum amount payable under the policy for covered losses.</p>
                            </div>
                            <div class="component-card">
                                <h4>Deductibles</h4>
                                <p>Amount the policyholder must pay before coverage begins.</p>
                            </div>
                            <div class="component-card">
                                <h4>Premium Calculation</h4>
                                <p>Factors affecting insurance costs and payment terms.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Chapter 4: Risk Assessment -->
            <section id="risk-assessment" class="chapter" data-chapter="4">
                <h2>4. Risk Assessment and Management</h2>
                <div class="chapter-content">
                    <div class="content-block">
                        <h3>Understanding Property Risks</h3>
                        <p>Risk assessment is a crucial process in property insurance that helps identify, evaluate, and prioritize potential risks to property.</p>
                        
                        <div class="key-points">
                            <h4>Key Risk Factors</h4>
                            <ul>
                                <li>Location and environmental hazards</li>
                                <li>Property construction and age</li>
                                <li>Security measures and safety features</li>
                                <li>Previous claims history</li>
                            </ul>
                        </div>

                        <div class="risk-factors-grid">
                            <div class="risk-card">
                                <h4>Natural Hazards</h4>
                                <div class="risk-details">
                                    <ul>
                                        <li>Flood zones and water damage risks</li>
                                        <li>Severe weather exposure</li>
                                        <li>Geological hazards</li>
                                        <li>Wildfire susceptibility</li>
                                    </ul>
                                </div>
                            </div>

                            <div class="risk-card">
                                <h4>Structural Factors</h4>
                                <div class="risk-details">
                                    <ul>
                                        <li>Building materials and quality</li>
                                        <li>Age and maintenance history</li>
                                        <li>Renovation requirements</li>
                                        <li>Code compliance status</li>
                                    </ul>
                                </div>
                            </div>

                            <div class="risk-card">
                                <h4>Security Considerations</h4>
                                <div class="risk-details">
                                    <ul>
                                        <li>Alarm systems and monitoring</li>
                                        <li>Access control measures</li>
                                        <li>Fire protection systems</li>
                                        <li>Surveillance equipment</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="content-section">
                            <h4>Risk Mitigation Strategies</h4>
                            <div class="strategy-grid">
                                <div class="strategy-card">
                                    <h5>Preventive Measures</h5>
                                    <ul>
                                        <li>Regular maintenance schedules</li>
                                        <li>Safety inspections</li>
                                        <li>Employee training programs</li>
                                        <li>Emergency response plans</li>
                                    </ul>
                                </div>

                                <div class="strategy-card">
                                    <h5>Risk Transfer Options</h5>
                                    <ul>
                                        <li>Insurance coverage selection</li>
                                        <li>Policy endorsements</li>
                                        <li>Reinsurance arrangements</li>
                                        <li>Contractual risk transfer</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Additional Chapters -->

            <!-- Chapter 5: Property Valuation -->
            <section id="property-valuation" class="chapter" data-chapter="5">
                <h2>5. Property Valuation Methods</h2>
                <div class="chapter-content">
                    <div class="content-block">
                        <h3>Understanding Property Values</h3>
                        <div class="valuation-methods">
                            <div class="method-card">
                                <h4>Market Value</h4>
                                <p>The estimated amount a property would sell for in the current market.</p>
                                <ul>
                                    <li>Based on comparable sales</li>
                                    <li>Location considerations</li>
                                    <li>Current market conditions</li>
                                    <li>Property condition</li>
                                </ul>
                            </div>

                            <div class="method-card">
                                <h4>Replacement Cost</h4>
                                <p>Cost to rebuild or replace property with similar materials and quality.</p>
                                <ul>
                                    <li>Construction costs</li>
                                    <li>Material prices</li>
                                    <li>Labor expenses</li>
                                    <li>Building codes compliance</li>
                                </ul>
                            </div>

                            <div class="method-card">
                                <h4>Actual Cash Value</h4>
                                <p>Replacement cost minus depreciation.</p>
                                <ul>
                                    <li>Age of property</li>
                                    <li>Wear and tear</li>
                                    <li>Obsolescence</li>
                                    <li>Depreciation factors</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Chapter 6: Claims Process -->
            <section id="claims-process" class="chapter" data-chapter="6">
                <h2>6. Understanding the Claims Process</h2>
                <div class="chapter-content">
                    <div class="content-block">
                        <h3>Steps in Filing a Claim</h3>
                        <div class="process-steps">
                            <div class="step-card">
                                <span class="step-number">1</span>
                                <h4>Initial Notification</h4>
                                <p>Contact your insurance provider immediately after the incident.</p>
                            </div>

                            <div class="step-card">
                                <span class="step-number">2</span>
                                <h4>Documentation</h4>
                                <p>Gather evidence and document the damage:</p>
                                <ul>
                                    <li>Photographs of damage</li>
                                    <li>Police reports (if applicable)</li>
                                    <li>List of damaged items</li>
                                    <li>Estimated values</li>
                                </ul>
                            </div>

                            <div class="step-card">
                                <span class="step-number">3</span>
                                <h4>Claim Assessment</h4>
                                <p>Insurance adjuster evaluates the claim and damage.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Chapter 7: Policy Exclusions -->
            <section id="policy-exclusions" class="chapter" data-chapter="7">
                <h2>7. Common Policy Exclusions</h2>
                <div class="chapter-content">
                    <div class="content-block">
                        <h3>Understanding What
                    </div>
                </div>
            </section>

        </article>
    </div>
</main>
<!-- Enhanced Scripts -->
<script>
// Mobile navigation toggle
document.querySelector('.nav-toggle').addEventListener('click', () => {
    document.querySelector('.tutorial-sidebar').classList.toggle('active');
});

// Chapter navigation
document.querySelectorAll('.chapter-item a').forEach(link => {
    link.addEventListener('click', (e) => {
        document.querySelectorAll('.chapter-item').forEach(item => {
            item.classList.remove('active');
        });
        e.target.closest('.chapter-item').classList.add('active');
    });
});
</script>
<script src="/project-4-1/assets/js/tutorial-interactions.js"></script>
<script src="/project-4-1/assets/js/tutorial-progress.js"></script>
<?php echo $footer;?>