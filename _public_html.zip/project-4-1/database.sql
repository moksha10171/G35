-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 23, 2024 at 09:26 AM
-- Server version: 10.11.9-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u291518478_project1`
--

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `founded_year` int(11) DEFAULT NULL,
  `employee_count` varchar(50) DEFAULT NULL,
  `rating` decimal(2,1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `logo`, `description`, `industry`, `location`, `website`, `founded_year`, `employee_count`, `rating`, `created_at`) VALUES
(1, 'TechCorp Solutions', 'techcorp-logo.png', 'Leading technology solutions provider specializing in enterprise software', 'Technology', 'New York, NY', 'https://techcorp.com', 2010, '1000-5000', 4.5, '2024-11-23 08:50:53'),
(2, 'InnovateSoft', 'innovate-logo.png', 'Innovative software development company focusing on mobile applications', 'Software', 'San Francisco, CA', 'https://innovatesoft.com', 2015, '500-1000', 4.2, '2024-11-23 08:50:53'),
(3, 'DataDynamics', 'datadynamics-logo.png', 'Big data and analytics solutions for Fortune 500 companies', 'Data Analytics', 'Boston, MA', 'https://datadynamics.com', 2012, '100-500', 4.0, '2024-11-23 08:50:53'),
(4, 'CloudTech Systems', 'cloudtech-logo.png', 'Cloud infrastructure and DevOps solutions', 'Cloud Computing', 'Seattle, WA', 'https://cloudtech.io', 2013, '2000-5000', 4.7, '2024-11-23 08:50:53'),
(5, 'AI Innovations', 'ai-innovations-logo.png', 'Artificial intelligence and machine learning research', 'AI/ML', 'Austin, TX', 'https://aiinnovations.ai', 2017, '100-500', 4.3, '2024-11-23 08:50:53'),
(6, 'SecureNet', 'securenet-logo.png', 'Cybersecurity solutions and consulting', 'Cybersecurity', 'Washington, DC', 'https://securenet.com', 2011, '500-1000', 4.4, '2024-11-23 08:50:53'),
(7, 'FinTech Solutions', 'fintech-logo.png', 'Financial technology and payment systems', 'FinTech', 'Chicago, IL', 'https://fintechsol.com', 2014, '1000-2000', 4.1, '2024-11-23 08:50:53'),
(8, 'HealthTech Pro', 'healthtech-logo.png', 'Healthcare technology and telemedicine solutions', 'Healthcare', 'Boston, MA', 'https://healthtechpro.com', 2016, '200-500', 4.2, '2024-11-23 08:50:53'),
(9, 'GameStudios', 'gamestudios-logo.png', 'Video game development and interactive entertainment', 'Gaming', 'Los Angeles, CA', 'https://gamestudios.com', 2009, '500-1000', 4.6, '2024-11-23 08:50:53'),
(10, 'EcoTech Solutions', 'ecotech-logo.png', 'Sustainable technology and green energy solutions', 'Clean Tech', 'Portland, OR', 'https://ecotechsol.com', 2018, '100-200', 4.0, '2024-11-23 08:50:53'),
(11, 'WebFlow Digital', 'webflow-logo.png', 'Digital marketing and web development agency', 'Digital Marketing', 'Miami, FL', 'https://webflowdigital.com', 2015, '50-100', 4.1, '2024-11-23 08:50:53'),
(12, 'RoboTech Industries', 'robotech-logo.png', 'Robotics and automation solutions', 'Robotics', 'Detroit, MI', 'https://robotech.com', 2013, '200-500', 4.3, '2024-11-23 08:50:53'),
(13, 'VR Dynamics', 'vrdynamics-logo.png', 'Virtual and augmented reality development', 'VR/AR', 'San Jose, CA', 'https://vrdynamics.com', 2016, '100-200', 4.4, '2024-11-23 08:50:53'),
(14, 'SmartHome Systems', 'smarthome-logo.png', 'IoT and smart home technology', 'IoT', 'Denver, CO', 'https://smarthomesys.com', 2015, '200-500', 4.2, '2024-11-23 08:50:53'),
(15, 'BlockChain Tech', 'blockchain-logo.png', 'Blockchain and cryptocurrency solutions', 'Blockchain', 'San Francisco, CA', 'https://blockchaintech.io', 2017, '100-200', 4.1, '2024-11-23 08:50:53'),
(16, 'EdTech Solutions', 'edtech-logo.png', 'Educational technology and e-learning platforms', 'Education', 'Atlanta, GA', 'https://edtechsol.com', 2014, '200-500', 4.3, '2024-11-23 08:50:53'),
(17, 'MediaTech Pro', 'mediatech-logo.png', 'Digital media and streaming technology', 'Media', 'Los Angeles, CA', 'https://mediatechpro.com', 2012, '500-1000', 4.4, '2024-11-23 08:50:53'),
(18, 'RetailTech Solutions', 'retailtech-logo.png', 'E-commerce and retail technology solutions', 'Retail', 'Seattle, WA', 'https://retailtech.com', 2015, '200-500', 4.2, '2024-11-23 08:50:53'),
(19, 'AgriTech Systems', 'agritech-logo.png', 'Agricultural technology and smart farming solutions', 'Agriculture', 'Dallas, TX', 'https://agritech.com', 2016, '100-200', 4.0, '2024-11-23 08:50:53'),
(20, 'SpaceTech Innovations', 'spacetech-logo.png', 'Space technology and satellite systems', 'Space Tech', 'Houston, TX', 'https://spacetechinn.com', 2018, '200-500', 4.5, '2024-11-23 08:50:53'),
(21, 'Quantum Computing Corp', 'quantum-logo.png', 'Quantum computing research and development', 'Quantum Computing', 'Berkeley, CA', 'https://quantumcomp.com', 2019, '50-100', 4.6, '2024-11-23 08:50:53'),
(22, 'Digital Twins Tech', 'digitaltwins-logo.png', 'Digital twin technology and simulation solutions', 'Digital Twin', 'Minneapolis, MN', 'https://digitaltwin.com', 2017, '100-200', 4.2, '2024-11-23 08:50:53'),
(23, 'BioTech Solutions', 'biotech-logo.png', 'Biotechnology and genetic research', 'Biotech', 'Cambridge, MA', 'https://biotechsol.com', 2015, '200-500', 4.4, '2024-11-23 08:50:53'),
(24, 'NanoTech Systems', 'nanotech-logo.png', 'Nanotechnology research and development', 'Nanotech', 'San Diego, CA', 'https://nanotechsys.com', 2016, '100-200', 4.3, '2024-11-23 08:50:53'),
(25, 'AutoTech Innovations', 'autotech-logo.png', 'Autonomous vehicle and smart transportation', 'Automotive', 'Detroit, MI', 'https://autotech.com', 2014, '500-1000', 4.5, '2024-11-23 08:50:53'),
(26, 'DroneTech Solutions', 'dronetech-logo.png', 'Drone technology and aerial systems', 'Drone Tech', 'Phoenix, AZ', 'https://dronetech.com', 2017, '100-200', 4.1, '2024-11-23 08:50:53'),
(27, 'CyberSec Pro', 'cybersec-logo.png', 'Advanced cybersecurity and threat detection', 'Cybersecurity', 'Arlington, VA', 'https://cybersecpro.com', 2015, '200-500', 4.4, '2024-11-23 08:50:53'),
(28, 'CloudNative Systems', 'cloudnative-logo.png', 'Cloud-native application development', 'Cloud Computing', 'Portland, OR', 'https://cloudnative.com', 2016, '200-500', 4.3, '2024-11-23 08:50:53'),
(29, 'DataScience Corp', 'datascience-logo.png', 'Data science and analytics consulting', 'Data Science', 'Austin, TX', 'https://datasciencecorp.com', 2015, '100-200', 4.2, '2024-11-23 08:50:53'),
(30, 'AIResearch Lab', 'airesearch-logo.png', 'Artificial intelligence research and development', 'AI/ML', 'Pittsburgh, PA', 'https://airesearch.com', 2018, '50-100', 4.5, '2024-11-23 08:50:53'),
(31, 'DevOps Solutions', 'devops-logo.png', 'DevOps and CI/CD solutions', 'DevOps', 'Raleigh, NC', 'https://devopssol.com', 2014, '200-500', 4.3, '2024-11-23 08:50:53'),
(32, 'MobileApp Pro', 'mobileapp-logo.png', 'Mobile application development', 'Mobile Dev', 'Nashville, TN', 'https://mobileapppro.com', 2015, '100-200', 4.1, '2024-11-23 08:50:53'),
(33, 'WebTech Solutions', 'webtech-logo.png', 'Web development and design services', 'Web Dev', 'Salt Lake City, UT', 'https://webtechsol.com', 2013, '200-500', 4.2, '2024-11-23 08:50:53'),
(34, 'UX Design Studio', 'uxdesign-logo.png', 'User experience and interface design', 'UX/UI', 'San Francisco, CA', 'https://uxdesignstudio.com', 2016, '50-100', 4.4, '2024-11-23 08:50:53'),
(35, 'TestingPro Labs', 'testingpro-logo.png', 'Software testing and quality assurance', 'QA', 'Charlotte, NC', 'https://testingpro.com', 2015, '100-200', 4.0, '2024-11-23 08:50:53'),
(36, 'InfoSec Solutions', 'infosec-logo.png', 'Information security and compliance', 'InfoSec', 'Washington, DC', 'https://infosecsol.com', 2014, '200-500', 4.3, '2024-11-23 08:50:53'),
(37, 'NetworkTech Pro', 'networktech-logo.png', 'Network infrastructure and security', 'Networking', 'Dallas, TX', 'https://networktechpro.com', 2012, '200-500', 4.2, '2024-11-23 08:50:53'),
(38, 'SystemAdmin Corp', 'sysadmin-logo.png', 'System administration and IT services', 'IT Services', 'Houston, TX', 'https://sysadmincorp.com', 2013, '100-200', 4.1, '2024-11-23 08:50:53'),
(39, 'DatabasePro Systems', 'dbpro-logo.png', 'Database management and optimization', 'Database', 'Chicago, IL', 'https://dbpro.com', 2015, '100-200', 4.3, '2024-11-23 08:50:53'),
(40, 'CloudSecurity Tech', 'cloudsec-logo.png', 'Cloud security and compliance solutions', 'Cloud Security', 'Seattle, WA', 'https://cloudsectech.com', 2016, '200-500', 4.4, '2024-11-23 08:50:53'),
(41, 'APITech Solutions', 'apitech-logo.png', 'API development and integration services', 'API', 'Boston, MA', 'https://apitech.com', 2017, '100-200', 4.2, '2024-11-23 08:50:53'),
(42, 'MLOps Systems', 'mlops-logo.png', 'Machine learning operations and deployment', 'MLOps', 'San Jose, CA', 'https://mlopssystems.com', 2018, '50-100', 4.5, '2024-11-23 08:50:53'),
(43, 'DataOps Pro', 'dataops-logo.png', 'Data operations and pipeline management', 'DataOps', 'Austin, TX', 'https://dataopspro.com', 2016, '100-200', 4.3, '2024-11-23 08:50:53'),
(44, 'CloudArch Solutions', 'cloudarch-logo.png', 'Cloud architecture and consulting', 'Cloud Architecture', 'Denver, CO', 'https://cloudarch.com', 2015, '200-500', 4.4, '2024-11-23 08:50:53'),
(45, 'DevSecOps Corp', 'devsecops-logo.png', 'Development security operations', 'DevSecOps', 'Atlanta, GA', 'https://devsecops.com', 2017, '100-200', 4.2, '2024-11-23 08:50:53'),
(46, 'SREPro Systems', 'srepro-logo.png', 'Site reliability engineering services', 'SRE', 'Portland, OR', 'https://srepro.com', 2016, '100-200', 4.3, '2024-11-23 08:50:53'),
(47, 'InfraTech Solutions', 'infratech-logo.png', 'Infrastructure technology and management', 'Infrastructure', 'Miami, FL', 'https://infratech.com', 2014, '200-500', 4.1, '2024-11-23 08:50:53'),
(48, 'CloudStorage Pro', 'cloudstorage-logo.png', 'Cloud storage and data management', 'Cloud Storage', 'Las Vegas, NV', 'https://cloudstoragepro.com', 2015, '100-200', 4.2, '2024-11-23 08:50:53'),
(49, 'ContainerTech Systems', 'containertech-logo.png', 'Container technology and orchestration', 'Containers', 'San Diego, CA', 'https://containertech.com', 2016, '200-500', 4.4, '2024-11-23 08:50:53'),
(50, 'ServerlessPro', 'serverless-logo.png', 'Serverless architecture and development', 'Serverless', 'Austin, TX', 'https://serverlesspro.com', 2018, '50-100', 4.3, '2024-11-23 08:50:53'),
(51, 'MicroservicesTech', 'microservices-logo.png', 'Microservices architecture and development', 'Microservices', 'Seattle, WA', 'https://microservicestech.com', 2017, '100-200', 4.5, '2024-11-23 08:50:53');

-- --------------------------------------------------------

--
-- Table structure for table `company_reviews`
--

CREATE TABLE `company_reviews` (
  `id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `rating` decimal(2,1) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `pros` text DEFAULT NULL,
  `cons` text DEFAULT NULL,
  `review_date` timestamp NULL DEFAULT current_timestamp(),
  `helpful_count` int(11) DEFAULT 0,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `requirements` text DEFAULT NULL,
  `responsibilities` text DEFAULT NULL,
  `benefits` text DEFAULT NULL,
  `job_type` enum('Full-time','Part-time','Contract','Remote') DEFAULT NULL,
  `experience_level` enum('Entry','Intermediate','Senior','Expert') DEFAULT NULL,
  `salary_min` decimal(10,2) DEFAULT NULL,
  `salary_max` decimal(10,2) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `remote_option` tinyint(1) DEFAULT 0,
  `status` enum('Active','Filled','Expired') DEFAULT 'Active',
  `posted_date` timestamp NULL DEFAULT current_timestamp(),
  `deadline_date` date DEFAULT NULL,
  `views` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `company_id`, `title`, `description`, `requirements`, `responsibilities`, `benefits`, `job_type`, `experience_level`, `salary_min`, `salary_max`, `location`, `remote_option`, `status`, `posted_date`, `deadline_date`, `views`) VALUES
(36, 1, 'Senior Software Engineer', 'Leading development team for enterprise applications', 'Bachelor\'s in CS\n5+ years experience\nJava expertise', 'Lead development team\nArchitect solutions\nCode reviews', 'Health insurance\n401k\nRemote work', 'Full-time', 'Senior', 120000.00, 180000.00, 'New York, NY', 1, 'Active', '2024-11-23 09:08:56', NULL, 0),
(37, 2, 'Full Stack Developer', 'Building modern web applications', 'JavaScript/TypeScript\nReact\nNode.js\n3+ years experience', 'Develop features\nOptimize performance\nCollaborate with team', 'Competitive salary\nEquity\nFlexible hours', 'Full-time', 'Intermediate', 90000.00, 140000.00, 'San Francisco, CA', 1, 'Active', '2024-11-23 09:08:56', NULL, 0),
(38, 3, 'Data Scientist', 'ML model development and optimization', 'MS/PhD in related field\nPython\nML expertise', 'Build ML models\nData analysis\nResearch', 'Health benefits\nStock options\n401k', 'Full-time', 'Senior', 130000.00, 190000.00, 'Boston, MA', 1, 'Active', '2024-11-23 09:08:56', NULL, 0),
(39, 4, 'DevOps Engineer', 'Managing cloud infrastructure and CI/CD', 'AWS/Azure\nKubernetes\nTerraform', 'Manage infrastructure\nAutomate deployments\nMonitoring', 'Remote work\nHealth insurance\nBonus', 'Full-time', 'Senior', 125000.00, 175000.00, 'Seattle, WA', 1, 'Active', '2024-11-23 09:08:56', NULL, 0),
(40, 5, 'AI Research Engineer', 'Deep learning research and development', 'PhD preferred\nPyTorch\nComputer Vision', 'Research AI models\nPublish papers\nPrototype solutions', 'Research budget\nConference travel\nFlexible schedule', 'Full-time', 'Senior', 140000.00, 200000.00, 'Austin, TX', 1, 'Active', '2024-11-23 09:08:56', NULL, 0),
(41, 6, 'Security Engineer', 'Implementing cybersecurity solutions', 'Security certifications\nNetwork security\nPython', 'Security assessments\nImplement controls\nIncident response', 'Health benefits\nCertification support\nGym membership', 'Full-time', 'Intermediate', 110000.00, 160000.00, 'Washington, DC', 0, 'Active', '2024-11-23 09:08:56', NULL, 0),
(42, 7, 'Frontend Developer', 'Building responsive web interfaces', 'React/Vue\nCSS/SASS\nTypeScript', 'Build UI components\nOptimize performance\nA11y compliance', 'Remote work\nHealth insurance\nPTO', 'Full-time', 'Intermediate', 85000.00, 130000.00, 'Chicago, IL', 1, 'Active', '2024-11-23 09:08:56', NULL, 0),
(43, 8, 'Backend Developer', 'Developing scalable APIs', 'Java/Python\nSQL\nMicroservices', 'Design APIs\nOptimize database\nWrite tests', 'Stock options\n401k\nHealth benefits', 'Full-time', 'Senior', 120000.00, 170000.00, 'Boston, MA', 1, 'Active', '2024-11-23 09:08:56', NULL, 0),
(44, 9, 'Game Developer', 'Creating mobile games', 'Unity/Unreal\nC++\nGame design', 'Develop games\nOptimize performance\nFix bugs', 'Profit sharing\nCreative environment\nGym', 'Full-time', 'Intermediate', 90000.00, 140000.00, 'Los Angeles, CA', 0, 'Active', '2024-11-23 09:08:56', NULL, 0),
(45, 10, 'ML Engineer', 'Building machine learning systems', 'Python\nTensorFlow\nML deployment', 'Deploy ML models\nOptimize performance\nData pipeline', 'Stock options\nRemote work\n401k', 'Full-time', 'Senior', 130000.00, 180000.00, 'San Francisco, CA', 1, 'Active', '2024-11-23 09:08:56', NULL, 0),
(46, 11, 'Cloud Architect', 'Designing cloud solutions', 'AWS Solutions Architect\nTerraform\nKubernetes', 'Architecture design\nCloud strategy\nBest practices', 'Remote work\nStock options\nHealth benefits', 'Full-time', 'Senior', 140000.00, 190000.00, 'Seattle, WA', 1, 'Active', '2024-11-23 09:08:56', NULL, 0),
(47, 12, 'Mobile Developer', 'iOS/Android development', 'Swift/Kotlin\nMobile SDK\nCI/CD', 'Develop apps\nOptimize performance\nFix bugs', 'Health insurance\n401k\nGym membership', 'Full-time', 'Intermediate', 100000.00, 150000.00, 'New York, NY', 0, 'Active', '2024-11-23 09:08:56', NULL, 0),
(48, 13, 'Data Engineer', 'Building data pipelines', 'Python\nSpark\nAirflow', 'Design pipelines\nETL processes\nData modeling', 'Remote work\nStock options\nHealth benefits', 'Full-time', 'Senior', 125000.00, 175000.00, 'San Francisco, CA', 1, 'Active', '2024-11-23 09:08:56', NULL, 0),
(49, 14, 'Product Manager', 'Leading product development', 'Technical background\nAgile\nProduct management', 'Define roadmap\nStakeholder management\nFeature prioritization', 'Stock options\nBonus\nHealth benefits', 'Full-time', 'Senior', 130000.00, 180000.00, 'Boston, MA', 1, 'Active', '2024-11-23 09:08:56', NULL, 0),
(50, 15, 'QA Engineer', 'Ensuring software quality', 'Selenium\nJUnit\nCI/CD', 'Test automation\nQuality processes\nBug tracking', 'Health insurance\n401k\nRemote work', 'Full-time', 'Intermediate', 85000.00, 130000.00, 'Austin, TX', 1, 'Active', '2024-11-23 09:08:56', NULL, 0),
(51, 16, 'Blockchain Developer', 'Developing decentralized applications', 'Solidity\nWeb3\nSmart Contracts\n3+ years experience', 'Develop smart contracts\nImplement blockchain solutions\nOptimize gas usage', 'Crypto payments\nRemote work\nHealth insurance', 'Full-time', 'Intermediate', 110000.00, 170000.00, 'Miami, FL', 1, 'Active', '2024-11-23 09:09:17', NULL, 0),
(52, 17, 'SRE Engineer', 'Managing system reliability', 'Linux\nPython\nMonitoring tools\n4+ years experience', 'System monitoring\nIncident response\nAutomation', 'Remote work\nOn-call bonus\nHealth benefits', 'Full-time', 'Senior', 130000.00, 180000.00, 'San Francisco, CA', 1, 'Active', '2024-11-23 09:09:17', NULL, 0),
(53, 18, 'AR/VR Developer', 'Creating immersive experiences', 'Unity\nC#\n3D modeling\n2+ years AR/VR', 'Develop VR applications\nOptimize performance\n3D asset integration', 'Creative environment\nLatest VR equipment\nHealth insurance', 'Full-time', 'Intermediate', 95000.00, 145000.00, 'Los Angeles, CA', 0, 'Active', '2024-11-23 09:09:17', NULL, 0),
(54, 19, 'Technical Architect', 'Leading system architecture', 'System design\nCloud platforms\n8+ years experience', 'Design systems\nTechnical leadership\nVendor selection', 'Executive benefits\nStock options\nBonus', 'Full-time', 'Senior', 150000.00, 200000.00, 'Seattle, WA', 1, 'Active', '2024-11-23 09:09:17', NULL, 0),
(55, 20, 'IoT Developer', 'Building connected device solutions', 'Embedded systems\nC++\nIoT protocols\n3+ years', 'Develop IoT solutions\nDevice integration\nProtocol implementation', 'Hardware lab access\nPatent bonuses\nHealth benefits', 'Full-time', 'Intermediate', 100000.00, 150000.00, 'San Jose, CA', 0, 'Active', '2024-11-23 09:09:17', NULL, 0),
(56, 21, 'Database Administrator', 'Managing enterprise databases', 'PostgreSQL\nOracle\nBackup strategies\n5+ years', 'Database maintenance\nPerformance tuning\nDisaster recovery', 'On-call bonus\nCertification support\n401k', 'Full-time', 'Senior', 120000.00, 170000.00, 'Chicago, IL', 1, 'Active', '2024-11-23 09:09:17', NULL, 0),
(57, 22, 'UI/UX Designer', 'Creating user experiences', 'Figma\nUser research\nPrototyping\n4+ years', 'Design interfaces\nUser research\nPrototype testing', 'Creative environment\nDesign tools\nHealth benefits', 'Full-time', 'Intermediate', 90000.00, 140000.00, 'Austin, TX', 1, 'Active', '2024-11-23 09:09:17', NULL, 0),
(58, 23, 'Quantum Computing Researcher', 'Quantum algorithm development', 'PhD in Physics/CS\nQuantum algorithms\nPython', 'Research algorithms\nQuantum simulation\nPublish papers', 'Research budget\nConference travel\nFlexible hours', 'Full-time', 'Senior', 140000.00, 200000.00, 'Berkeley, CA', 0, 'Active', '2024-11-23 09:09:17', NULL, 0),
(59, 24, 'MLOps Engineer', 'Managing ML infrastructure', 'Python\nKubeflow\nML deployment\n3+ years', 'Deploy ML models\nBuild pipelines\nMonitor performance', 'Remote work\nStock options\nHealth benefits', 'Full-time', 'Intermediate', 115000.00, 165000.00, 'Boston, MA', 1, 'Active', '2024-11-23 09:09:17', NULL, 0),
(60, 25, 'Cybersecurity Analyst', 'Protecting digital assets', 'Security tools\nThreat analysis\nIncident response', 'Security monitoring\nThreat response\nSecurity audits', 'Security certifications\nHealth insurance\nGym membership', 'Full-time', 'Intermediate', 95000.00, 145000.00, 'Washington, DC', 0, 'Active', '2024-11-23 09:09:17', NULL, 0),
(61, 26, 'Cloud Security Engineer', 'Securing cloud infrastructure', 'AWS security\nIAM\nCompliance\n4+ years', 'Security architecture\nCompliance monitoring\nSecurity automation', 'Remote work\nCertification bonus\nHealth benefits', 'Full-time', 'Senior', 130000.00, 180000.00, 'Seattle, WA', 1, 'Active', '2024-11-23 09:09:17', NULL, 0),
(62, 27, 'React Native Developer', 'Cross-platform mobile development', 'React Native\nTypeScript\nMobile development\n3+ years', 'Build mobile apps\nAPI integration\nPerformance optimization', 'Remote work\nFlexible hours\n401k', 'Full-time', 'Intermediate', 100000.00, 150000.00, 'Portland, OR', 1, 'Active', '2024-11-23 09:09:17', NULL, 0),
(63, 28, 'Data Architect', 'Designing data infrastructure', 'Data modeling\nBig Data\nCloud platforms\n6+ years', 'Design data architecture\nData governance\nBest practices', 'Stock options\nBonus\nHealth benefits', 'Full-time', 'Senior', 140000.00, 190000.00, 'New York, NY', 1, 'Active', '2024-11-23 09:09:17', NULL, 0),
(64, 29, 'Embedded Systems Engineer', 'IoT device development', 'C/C++\nEmbedded Linux\nRTOS\n4+ years', 'Firmware development\nHardware integration\nOptimization', 'Hardware lab\nPatent bonuses\nHealth insurance', 'Full-time', 'Senior', 120000.00, 170000.00, 'San Diego, CA', 0, 'Active', '2024-11-23 09:09:17', NULL, 0),
(65, 30, 'Technical Product Manager', 'Managing technical products', 'Technical background\nProduct management\n5+ years', 'Product strategy\nRoadmap planning\nStakeholder management', 'Stock options\nBonus\nHealth benefits', 'Full-time', 'Senior', 130000.00, 180000.00, 'San Francisco, CA', 1, 'Active', '2024-11-23 09:09:17', NULL, 0),
(66, 31, 'GraphQL Developer', 'Building GraphQL APIs', 'GraphQL\nNode.js\nAPI design\n3+ years', 'Design schemas\nBuild resolvers\nOptimize queries', 'Remote work\nFlexible hours\nHealth benefits', 'Full-time', 'Intermediate', 100000.00, 150000.00, 'Austin, TX', 1, 'Active', '2024-11-23 09:09:17', NULL, 0),
(67, 32, 'Computer Vision Engineer', 'Developing CV solutions', 'OpenCV\nPython\nDeep Learning\n4+ years', 'Develop CV models\nOptimize algorithms\nModel deployment', 'GPU access\nResearch budget\nHealth benefits', 'Full-time', 'Senior', 130000.00, 180000.00, 'Boston, MA', 1, 'Active', '2024-11-23 09:09:17', NULL, 0),
(68, 33, 'Kubernetes Administrator', 'Managing container orchestration', 'Kubernetes\nDocker\nHelm\n4+ years', 'Cluster management\nDeployment automation\nMonitoring', 'Remote work\nOn-call bonus\n401k', 'Full-time', 'Senior', 125000.00, 175000.00, 'Seattle, WA', 1, 'Active', '2024-11-23 09:09:17', NULL, 0),
(69, 34, 'Flutter Developer', 'Cross-platform app development', 'Flutter\nDart\nMobile development\n2+ years', 'Build mobile apps\nUI implementation\nState management', 'Remote work\nFlexible hours\nHealth benefits', 'Full-time', 'Intermediate', 90000.00, 140000.00, 'Chicago, IL', 1, 'Active', '2024-11-23 09:09:17', NULL, 0),
(70, 35, 'NLP Engineer', 'Natural language processing', 'NLP\nPython\nTransformers\n3+ years', 'Develop NLP models\nText analysis\nModel deployment', 'Research budget\nConference travel\nHealth benefits', 'Full-time', 'Senior', 120000.00, 170000.00, 'San Francisco, CA', 1, 'Active', '2024-11-23 09:09:17', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `job_applications`
--

CREATE TABLE `job_applications` (
  `id` int(11) NOT NULL,
  `job_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `resume` varchar(255) DEFAULT NULL,
  `cover_letter` text DEFAULT NULL,
  `status` enum('Pending','Reviewed','Shortlisted','Interviewed','Offered','Rejected') DEFAULT 'Pending',
  `applied_date` timestamp NULL DEFAULT current_timestamp(),
  `last_updated` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_skills`
--

CREATE TABLE `job_skills` (
  `id` int(11) NOT NULL,
  `skill` varchar(100) DEFAULT NULL,
  `job_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_skills`
--

INSERT INTO `job_skills` (`id`, `skill`, `job_id`) VALUES
(412, 'Java', 1),
(413, 'Spring Boot', 1),
(414, 'Microservices', 1),
(415, 'SQL', 1),
(416, 'AWS', 1),
(417, 'System Design', 1),
(418, 'JavaScript', 2),
(419, 'TypeScript', 2),
(420, 'React', 2),
(421, 'Node.js', 2),
(422, 'MongoDB', 2),
(423, 'REST APIs', 2),
(424, 'Python', 3),
(425, 'Machine Learning', 3),
(426, 'SQL', 3),
(427, 'TensorFlow', 3),
(428, 'Data Analysis', 3),
(429, 'Statistics', 3),
(430, 'AWS', 4),
(431, 'Kubernetes', 4),
(432, 'Docker', 4),
(433, 'Terraform', 4),
(434, 'CI/CD', 4),
(435, 'Linux', 4),
(436, 'PyTorch', 5),
(437, 'Deep Learning', 5),
(438, 'Computer Vision', 5),
(439, 'Python', 5),
(440, 'Research', 5),
(441, 'TensorFlow', 5),
(442, 'Cybersecurity', 6),
(443, 'Network Security', 6),
(444, 'Python', 6),
(445, 'Security Tools', 6),
(446, 'Penetration Testing', 6),
(447, 'SIEM', 6),
(448, 'React', 7),
(449, 'TypeScript', 7),
(450, 'CSS', 7),
(451, 'HTML', 7),
(452, 'JavaScript', 7),
(453, 'Web Performance', 7),
(454, 'Java', 8),
(455, 'Spring Boot', 8),
(456, 'MySQL', 8),
(457, 'Redis', 8),
(458, 'API Design', 8),
(459, 'Microservices', 8),
(460, 'Unity', 9),
(461, 'C++', 9),
(462, 'Game Design', 9),
(463, '3D Graphics', 9),
(464, 'Physics', 9),
(465, 'Animation', 9),
(466, 'Python', 10),
(467, 'TensorFlow', 10),
(468, 'ML Ops', 10),
(469, 'SQL', 10),
(470, 'Data Pipeline', 10),
(471, 'Cloud ML', 10),
(472, 'AWS', 11),
(473, 'Azure', 11),
(474, 'Kubernetes', 11),
(475, 'Terraform', 11),
(476, 'System Design', 11),
(477, 'Security', 11),
(478, 'Swift', 12),
(479, 'Kotlin', 12),
(480, 'iOS', 12),
(481, 'Android', 12),
(482, 'Mobile SDK', 12),
(483, 'REST APIs', 12),
(484, 'Python', 13),
(485, 'Spark', 13),
(486, 'Airflow', 13),
(487, 'SQL', 13),
(488, 'ETL', 13),
(489, 'Data Modeling', 13),
(490, 'Agile', 14),
(491, 'Product Management', 14),
(492, 'Technical Background', 14),
(493, 'Stakeholder Management', 14),
(494, 'Analytics', 14),
(495, 'User Stories', 14),
(496, 'Selenium', 15),
(497, 'JUnit', 15),
(498, 'Test Automation', 15),
(499, 'CI/CD', 15),
(500, 'Bug Tracking', 15),
(501, 'Test Planning', 15),
(502, 'GraphQL', 1),
(503, 'Docker', 1),
(504, 'Kubernetes', 1),
(505, 'CI/CD', 1),
(506, 'Git', 1),
(507, 'Design Patterns', 1),
(508, 'Vue.js', 2),
(509, 'Next.js', 2),
(510, 'GraphQL', 2),
(511, 'AWS', 2),
(512, 'Docker', 2),
(513, 'PostgreSQL', 2),
(514, 'Pandas', 3),
(515, 'NumPy', 3),
(516, 'Scikit-learn', 3),
(517, 'Jupyter', 3),
(518, 'Big Data', 3),
(519, 'R', 3),
(520, 'Jenkins', 4),
(521, 'Ansible', 4),
(522, 'Python', 4),
(523, 'Shell Scripting', 4),
(524, 'Monitoring Tools', 4),
(525, 'ELK Stack', 4),
(526, 'NLP', 5),
(527, 'GANs', 5),
(528, 'CUDA', 5),
(529, 'MLOps', 5),
(530, 'Reinforcement Learning', 5),
(531, 'Neural Networks', 5),
(532, 'AWS Security', 6),
(533, 'Cryptography', 6),
(534, 'Ethical Hacking', 6),
(535, 'Incident Response', 6),
(536, 'Security Auditing', 6),
(537, 'Compliance', 6),
(538, 'Vue.js', 7),
(539, 'Angular', 7),
(540, 'SASS/SCSS', 7),
(541, 'Webpack', 7),
(542, 'Jest', 7),
(543, 'Redux', 7),
(544, 'Node.js', 8),
(545, 'PostgreSQL', 8),
(546, 'MongoDB', 8),
(547, 'RabbitMQ', 8),
(548, 'GraphQL', 8),
(549, 'Docker', 8),
(550, 'Unreal Engine', 9),
(551, 'DirectX', 9),
(552, 'OpenGL', 9),
(553, 'Shader Programming', 9),
(554, 'Multiplayer Networking', 9),
(555, 'Game AI', 9),
(556, 'Keras', 10),
(557, 'PyTorch', 10),
(558, 'Deep Learning', 10),
(559, 'Computer Vision', 10),
(560, 'NLP', 10),
(561, 'AWS SageMaker', 10),
(562, 'GCP', 11),
(563, 'CloudFormation', 11),
(564, 'Microservices', 11),
(565, 'DevOps', 11),
(566, 'Cloud Security', 11),
(567, 'Cost Optimization', 11),
(568, 'Flutter', 12),
(569, 'React Native', 12),
(570, 'Firebase', 12),
(571, 'GraphQL', 12),
(572, 'CI/CD', 12),
(573, 'App Store Optimization', 12),
(574, 'Hadoop', 13),
(575, 'Snowflake', 13),
(576, 'dbt', 13),
(577, 'AWS', 13),
(578, 'Docker', 13),
(579, 'Kubernetes', 13),
(580, 'Scrum', 14),
(581, 'Data Analysis', 14),
(582, 'A/B Testing', 14),
(583, 'Product Strategy', 14),
(584, 'Market Research', 14),
(585, 'UX Design', 14),
(586, 'Cypress', 15),
(587, 'TestNG', 15),
(588, 'Postman', 15),
(589, 'Performance Testing', 15),
(590, 'API Testing', 15),
(591, 'Mobile Testing', 15);

-- --------------------------------------------------------

--
-- Table structure for table `mail_record`
--

CREATE TABLE `mail_record` (
  `id` int(11) NOT NULL,
  `sender` text NOT NULL,
  `purpose` text NOT NULL,
  `mail_id` text NOT NULL,
  `reg_id` text NOT NULL,
  `time_id` int(11) NOT NULL,
  `ip` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mail_record`
--

INSERT INTO `mail_record` (`id`, `sender`, `purpose`, `mail_id`, `reg_id`, `time_id`, `ip`) VALUES
(9, 'bmrcodes@gmail.com', 'OTP Signup', '9KEJ99D15KL62', '2024-11-18 22:19:54', 1731948594, '2409:40f2:201f:b029:2954:d674:4193:bc60'),
(10, 'devia8419@gmail.com', 'OTP Signup', '7NRX68P71KU62', '2024-11-18 22:40:24', 1731949824, '2409:40f2:201f:b029:2954:d674:4193:bc60'),
(11, 'nithinramnithin987@gamil.com', 'OTP Signup', '1CIZ94D57NG80', '2024-11-20 12:16:55', 1732085215, '182.71.109.122'),
(12, 'nithinramnithin987@gmail.com', 'OTP Signup', '4HTB34I59YA17', '2024-11-20 12:17:56', 1732085276, '182.71.109.122');

-- --------------------------------------------------------

--
-- Table structure for table `registration_details`
--

CREATE TABLE `registration_details` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `registered_time` varchar(20) NOT NULL,
  `password` text NOT NULL,
  `token` text NOT NULL,
  `otp` int(6) NOT NULL,
  `verification_status` varchar(8) NOT NULL,
  `timeid` int(11) NOT NULL,
  `mailid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `registration_details`
--

INSERT INTO `registration_details` (`id`, `name`, `email`, `registered_time`, `password`, `token`, `otp`, `verification_status`, `timeid`, `mailid`) VALUES
(1, 'MOKSHAGNA REDDY BANDI', 'bmrcodes@gmail.com', '2024-11-18 22:19:52', '$2y$10$VVUZJ2okgUF5/xAtG2UpeeeR9dSBAVVBzBee24YKfQQDWrPdNX.l6', '6425daf567e1be68b7edd15285aed6a7dda6342b92a0e71468087017cd4c1c21', 839748, '', 1731948592, '9KEJ99D15KL62'),
(3, 'Nithin R', 'nithinramnithin987@gamil.com', '2024-11-20 12:16:53', '$2y$10$afRr7FVEqfnKbYas0Mqgz.YB8AeEWiWXfUGS5I36yoYFat4NDMGt6', '8ea4ec0cb38fa82f02efcab460cee0d56f7cf043eb46bb0bb46576de14b34c57', 692471, '', 1732085213, '1CIZ94D57NG80'),
(4, 'Nithin R', 'nithinramnithin987@gmail.com', '2024-11-20 12:17:54', '$2y$10$7SognVpieZTAMN31DfvrwexvZHIpAwAx19Po9TalYvTWBsOD8j.F2', '339b2b65d3a7bea601853320ad898bbb59375e003d8b708f430401b04c12fd05', 721129, '', 1732085274, '4HTB34I59YA17');

-- --------------------------------------------------------

--
-- Table structure for table `saved_jobs`
--

CREATE TABLE `saved_jobs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `saved_date` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `session_access`
--

CREATE TABLE `session_access` (
  `email` varchar(255) NOT NULL,
  `session_id` varchar(128) NOT NULL,
  `uid` varchar(128) NOT NULL,
  `registered_time` timestamp NULL DEFAULT current_timestamp(),
  `timeid` bigint(20) NOT NULL,
  `device_platform` varchar(50) DEFAULT NULL,
  `device_type` varchar(50) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `operating_system` varchar(100) DEFAULT NULL,
  `browser_info` varchar(255) DEFAULT NULL,
  `client_id_info` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `session_access`
--

INSERT INTO `session_access` (`email`, `session_id`, `uid`, `registered_time`, `timeid`, `device_platform`, `device_type`, `ip_address`, `operating_system`, `browser_info`, `client_id_info`) VALUES
('moksha10171@gmail.com', '1c76e750f8fd0a55a5246fc0550f18fc2b91fc8a0e47b564ce8045830d76111e', 'CQP97CXM3N41', '2024-11-23 14:53:49', 1732353829, 'Desktop', 'WINDOWS', '43.247.158.64', ' Win64', 'Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'),
('moksha10171@gmail.com', '666ef7bffacc6e4cf7584581e788c77c2b91fc8a0e47b564ce8045830d76111e', 'CQP97CXM3N41', '2024-11-17 18:43:54', 1731849234, 'Desktop', 'WINDOWS', '43.247.158.71', ' Win64', 'Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'),
('moksha10171@gmail.com', 'a1944609ca6f730e6f24164b5d0c11442b91fc8a0e47b564ce8045830d76111e', 'CQP97CXM3N41', '2024-11-17 18:32:26', 1731848546, 'Desktop', 'WINDOWS', '43.247.158.71', ' Win64', 'Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'),
('moksha10171@gmail.com', 'b608516d80953b7dcebb7c651dacc66f2b91fc8a0e47b564ce8045830d76111e', 'CQP97CXM3N41', '2024-11-17 19:01:21', 1731850281, 'Desktop', 'WINDOWS', '43.247.158.65', ' Win64', 'Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'),
('moksha10171@gmail.com', 'c2e0eb891a99599d8c2052f82dfc47682b91fc8a0e47b564ce8045830d76111e', 'CQP97CXM3N41', '2024-11-17 19:11:32', 1731850892, 'Desktop', 'WINDOWS', '43.247.158.64', ' Win64', 'Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'),
('moksha10171@gmail.com', 'dc80a7988a439e3a20e2ed427fd635122b91fc8a0e47b564ce8045830d76111e', 'CQP97CXM3N41', '2024-11-18 20:16:31', 1731941191, 'Desktop', 'WINDOWS', '43.247.158.64', ' Win64', 'Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'),
('moksha10171@gmail.com', 'e965794116e975a4eadc32c1c4d7dedc2b91fc8a0e47b564ce8045830d76111e', 'CQP97CXM3N41', '2024-11-17 19:16:00', 1731851160, 'Desktop', 'WINDOWS', '43.247.158.65', ' Win64', 'Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'),
('moksha10171@gmail.com', 'f1336e1cb336507d05c231662bed9a022b91fc8a0e47b564ce8045830d76111e', 'CQP97CXM3N41', '2024-11-17 18:58:16', 1731850096, 'Desktop', 'WINDOWS', '43.247.158.71', ' Win64', 'Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'),
('moksha10171@gmail.com', 'ff3d91e3bda4eec5427b032ef43db0d42b91fc8a0e47b564ce8045830d76111e', 'CQP97CXM3N41', '2024-11-23 14:05:24', 1732350924, 'Desktop', 'WINDOWS', '43.247.158.64', ' Win64', 'Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `uid` varchar(12) NOT NULL,
  `image` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Login_Count` int(20) NOT NULL,
  `registered_time` varchar(20) NOT NULL,
  `password` text NOT NULL,
  `timeid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `uid`, `image`, `Login_Count`, `registered_time`, `password`, `timeid`) VALUES
(92, 'Moksha', 'moksha10171@gmail.com', 'CQP97CXM3N41', '', 0, '2024-04-11 05:06:30 ', '$2y$10$0wAQMgxhCwxg32.0Z95rpe8ZEKY88vc1i4ydsu/BjsnsT0f9i3PiS', 0),
(93, 'BANDI DEVI', 'devia8419@gmail.com', 'CYN25FDZ5D12', '', 0, '2024-11-18 22:45:23', '$2y$10$HVPKe29mYAeaXMagdn34FOZWdWWFUU7LbratLhICTqCGFaw5rt3W2', 1731950123);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company_reviews`
--
ALTER TABLE `company_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `job_applications`
--
ALTER TABLE `job_applications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `job_id` (`job_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `job_skills`
--
ALTER TABLE `job_skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mail_record`
--
ALTER TABLE `mail_record`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration_details`
--
ALTER TABLE `registration_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saved_jobs`
--
ALTER TABLE `saved_jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `job_id` (`job_id`);

--
-- Indexes for table `session_access`
--
ALTER TABLE `session_access`
  ADD PRIMARY KEY (`session_id`,`uid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`) USING BTREE,
  ADD UNIQUE KEY `UNIQUE` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `company_reviews`
--
ALTER TABLE `company_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `job_applications`
--
ALTER TABLE `job_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `job_skills`
--
ALTER TABLE `job_skills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=592;

--
-- AUTO_INCREMENT for table `mail_record`
--
ALTER TABLE `mail_record`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `registration_details`
--
ALTER TABLE `registration_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `saved_jobs`
--
ALTER TABLE `saved_jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
