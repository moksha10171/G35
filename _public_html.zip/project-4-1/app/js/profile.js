class ProfileManager {
    #config = {
        endpoints: {
            upload: '/api/resume/upload',
            skills: '/api/skills',
            profile: '/api/profile'
        },
        maxFileSize: 5 * 1024 * 1024, // 5MB
        allowedFileTypes: ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
        uploadTimeout: 30000 // 30 seconds
    };

    constructor() {
        this.initializeComponents();
        this.setupEventListeners();
    }

    async initializeComponents() {
        try {
            await Promise.all([
                this.initializeResumeUpload(),
                this.initializeSkillsManager(),
                this.initializeCharts(),
                this.initializeImageUpload()
            ]);
        } catch (error) {
            console.error('Failed to initialize components:', error);
            this.showNotification('Some features may not be available', 'warning');
        }
    }

    setupEventListeners() {
        // Delegate events at the document level
        document.addEventListener('click', this.handleGlobalClick.bind(this));
        
        // Handle file drops anywhere in the app
        this.setupGlobalDragAndDrop();
        
        // Handle keyboard shortcuts
        this.setupKeyboardShortcuts();
    }

    handleGlobalClick(event) {
        const target = event.target.closest('[data-action]');
        if (!target) return;

        const action = target.dataset.action;
        const handlers = {
            'edit-profile': () => this.handleEditProfile(),
            'share-profile': () => this.handleShareProfile(),
            'download-resume': () => this.handleResumeDownload(),
            'print-profile': () => this.handleProfilePrint()
        };

        if (handlers[action]) {
            event.preventDefault();
            handlers[action]();
        }
    }

    async handleResumeUpload(file) {
        if (!this.validateFile(file)) return;

        const upload = new Upload(file, {
            endpoint: this.#config.endpoints.upload,
            timeout: this.#config.uploadTimeout,
            onProgress: this.updateProgressBar.bind(this)
        });

        try {
            const result = await upload.start();
            this.addResumeToList(result);
            this.showNotification('Resume uploaded successfully', 'success');
        } catch (error) {
            this.handleUploadError(error);
        }
    }

    validateFile(file) {
        const validations = [
            {
                test: () => this.#config.allowedFileTypes.includes(file.type),
                message: 'Invalid file type. Please upload PDF or Word document.'
            },
            {
                test: () => file.size <= this.#config.maxFileSize,
                message: 'File size exceeds 5MB limit.'
            }
        ];

        const failedValidation = validations.find(v => !v.test());
        
        if (failedValidation) {
            this.showNotification(failedValidation.message, 'error');
            return false;
        }

        return true;
    }

    showNotification(message, type = 'info') {
        const notification = new Notification({
            message,
            type,
            duration: 3000,
            position: 'top-right'
        });

        notification.show();
    }
}

// Initialize with error boundary
try {
    document.addEventListener('DOMContentLoaded', () => {
        window.profileManager = new ProfileManager();
    });
} catch (error) {
    console.error('Failed to initialize Profile Manager:', error);
    // Show fallback UI
    document.body.innerHTML = `
        <div class="error-boundary">
            <h1>Something went wrong</h1>
            <p>Please try refreshing the page</p>
        </div>
    `;
} 