<?php
session_start();
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$host = 'localhost';
$username = 'u291518478_project1';
$password = 'Moksha@10170+10171';
$dbname = 'u291518478_project1';

$loginUrl = 'https://www.bmreducation.in/project-4-1/login';
$logoutUrl = 'https://www.bmreducation.in/project-4-1/logout';

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    header("Location: $loginUrl");
    exit();
}

if (empty($_SESSION['session_new_project'])) {
    header("Location: $loginUrl");
    exit();
}

$stmt = $conn->prepare("SELECT * FROM session_access WHERE session_id = ?");
$stmt->bind_param("s", $_SESSION['session_new_project']);
$stmt->execute();
$userResult = $stmt->get_result();

if ($userResult->num_rows === 0) {
    header("Location: $logoutUrl");
    exit();
}

$userData = $userResult->fetch_assoc();

$stmt1 = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt1->bind_param("s", $userData['email']);
$stmt1->execute();
$adminResult = $stmt1->get_result();

if ($adminResult->num_rows === 0) {
    header("Location: $logoutUrl");
    exit();
}

$stmt->close();
$stmt1->close();
$conn->close();

function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$meta = inancap('../assets/layout/meta.php');
echo $meta;
?>

<link rel="stylesheet" href="/project-4-1/assets/styles/styles.915.20104.css">
<link rel="stylesheet" href="/project-4-1/assets/styles/jobs.css">
<link rel="stylesheet" href="/project-4-1/assets/styles/modal.css">
  <link rel="stylesheet" href="/project-4-1/assets/styles/dashboard.css">
<div class="dashboard-container">
        <!-- Enhanced Sidebar -->
        <aside class="dashboard-sidebar">
            <div class="sidebar-header">
                <div class="logo-wrapper">
                    <img src="../assets/images/logo-light.png" alt="Logo" class="logo-icon">
                </div>
                <button class="sidebar-toggle" id="sidebarToggle" aria-label="Toggle Sidebar">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            
            <nav class="sidebar-nav">
    <ul>
        <li class="active">
            <a href="/project-4-1/app/">
                <i class="fas fa-chart-line"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="/project-4-1/app/jobs">
                <i class="fas fa-briefcase"></i>
                <span>Browse Jobs</span>
            </a>
        </li>
        <li>
            <a href="/project-4-1/app/applications" class="nav-link-badge">
                <i class="fas fa-clipboard-list"></i>
                <span>Applications</span>
                <span class="badge">3</span>
            </a>
        </li>
        <li>
            <a href="/project-4-1/app/saved" class="nav-link-badge">
                <i class="fas fa-heart"></i>
                <span>Saved Jobs</span>
                <span class="badge">5</span>
            </a>
        </li>
    </ul>
</nav>
        </aside>
 <!-- Main Content Area -->
        <main class="dashboard-main">
            <!-- Updated Header Structure -->
            <header class="top-nav">
                <div class="nav-left">
                    <button class="search-toggle" aria-label="Toggle Search">
                        <i class="fas fa-search"></i>
                    </button>
                    <div class="search-wrapper">
                        <div class="search-bar">
                            <div class="search-input-wrapper">
                                <i class="fas fa-search search-icon"></i>
                                <input 
                                    type="text" 
                                    placeholder="Search jobs, companies, or keywords..." 
                                    aria-label="Search"
                                >
                                <button class="search-clear" aria-label="Clear search">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="nav-right">
                    <div class="nav-actions">
                        <button class="nav-btn" title="Messages">
                            <i class="fas fa-envelope"></i>
                            <span class="badge pulse">2</span>
                        </button>
                        <button class="nav-btn" title="Notifications">
                            <i class="fas fa-bell"></i>
                            <span class="badge">3</span>
                        </button>
                    </div>

                    <div class="user-menu" tabindex="0">
                        <div class="user-avatar">
                            <img
    src="<?php echo isset($userData['avatar']) && !empty($userData['avatar']) 
        ? '/project-4-1/uploads/profile_images/' . htmlspecialchars($userData['avatar']) 
        : '/project-4-1/assets/images/default-avatar.png'; ?>" 

                                alt="Profile" 
                                class="avatar"
                            >
                        </div>
                        <div class="user-info">
                            <span class="username">
                                <?php echo htmlspecialchars($userData['name'] ?? 'User'); ?>
                            </span>
                            <span class="user-role">
                                <?php echo htmlspecialchars($userData['role'] ?? 'Job Seeker'); ?>
                            </span>
                        </div>
                        <i class="fas fa-chevron-down dropdown-icon"></i>

                        <!-- Enhanced Dropdown Menu -->
                        <div class="user-dropdown">
                            <div class="dropdown-header">
                                <div class="user-preview">
                                    <img 
                                       
    src="<?php echo isset($userData['avatar']) && !empty($userData['avatar']) 
        ? '/project-4-1/uploads/profile_images/' . htmlspecialchars($userData['avatar']) 
        : '/project-4-1/assets/images/default-avatar.png'; ?>" 
                                        alt="Profile" 
                                        class="preview-avatar"
                                    >
                                    <div class="preview-info">
                                        <span class="preview-name"><?php echo htmlspecialchars($userData['name'] ?? 'User'); ?></span>
                                        <span class="preview-email"><?php echo htmlspecialchars($userData['email'] ?? 'email@example.com'); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="dropdown-content">
                                <a href="/project-4-1/app/profile" class="dropdown-item">
                                    <i class="fas fa-user"></i>
                                    <span>View Profile</span>
                                </a>
                                <a href="/project-4-1/app/settings" class="dropdown-item">
                                    <i class="fas fa-cog"></i>
                                    <span>Settings</span>
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="/project-4-1/logout" class="dropdown-item text-danger">
                                    <i class="fas fa-sign-out-alt"></i>
                                    <span>Logout</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

    <div class="jobs-container">
        <!-- Search Header -->
        <header class="search-header">
            <div class="search-wrapper">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Search jobs, companies, or keywords">
                </div>
                <div class="search-box">
                    <i class="fas fa-location-dot"></i>
                    <input type="text" id="locationInput" placeholder="City, state, or remote">
                </div>
                <button class="search-btn">
                    <i class="fas fa-search"></i>
                    <span>Find Jobs</span>
                </button>
            </div>
        </header>

        <div class="jobs-content">
            <!-- Filters Sidebar -->
            <aside class="filters-sidebar">
                <!-- Job Type Filter -->
                <div class="filter-section">
                    <h3>Job Type</h3>
                    <div class="filter-options">
                        <label class="filter-option">
                            <input type="checkbox" name="job_type" value="Full-time">
                            <span class="checkbox-custom"></span>
                            <span class="label-text">Full-time</span>
                        </label>
                        <label class="filter-option">
                            <input type="checkbox" name="job_type" value="Part-time">
                            <span class="checkbox-custom"></span>
                            <span class="label-text">Part-time</span>
                        </label>
                        <label class="filter-option">
                            <input type="checkbox" name="job_type" value="Contract">
                            <span class="checkbox-custom"></span>
                            <span class="label-text">Contract</span>
                        </label>
                        <label class="filter-option">
                            <input type="checkbox" name="job_type" value="Remote">
                            <span class="checkbox-custom"></span>
                            <span class="label-text">Remote</span>
                        </label>
                    </div>
                </div>

                <!-- Experience Level Filter -->
                <div class="filter-section">
                    <h3>Experience Level</h3>
                    <div class="filter-options">
                        <label class="filter-option">
                            <input type="checkbox" name="experience" value="Entry">
                            <span class="checkbox-custom"></span>
                            <span class="label-text">Entry Level</span>
                        </label>
                        <label class="filter-option">
                            <input type="checkbox" name="experience" value="Intermediate">
                            <span class="checkbox-custom"></span>
                            <span class="label-text">Intermediate</span>
                        </label>
                        <label class="filter-option">
                            <input type="checkbox" name="experience" value="Senior">
                            <span class="checkbox-custom"></span>
                            <span class="label-text">Senior</span>
                        </label>
                    </div>
                </div>

                <!-- Salary Range Filter -->
                <div class="filter-section">
                    <h3>Salary Range</h3>
                    <div class="salary-slider">
                        <div class="salary-input">
                            <input type="range" 
                                   id="salaryRange" 
                                   min="0" 
                                   max="200000" 
                                   step="10000" 
                                   value="0">
                        </div>
                        <div class="salary-values">
                            <span id="minSalary">$0</span>
                            <span id="maxSalary">$200k+</span>
                        </div>
                        <div class="current-salary">
                            <span>Selected: </span>
                            <span id="salaryValue">$0</span>
                        </div>
                    </div>
                </div>

                <!-- Skills Filter -->
                <div class="filter-section">
                    <h3>Popular Skills</h3>
                    <div class="skills-search">
                        <input type="text" placeholder="Search skills">
                    </div>
                    <div class="popular-skills">
                        <span class="skill-tag">JavaScript</span>
                        <span class="skill-tag">Python</span>
                        <span class="skill-tag">React</span>
                        <span class="skill-tag">AWS</span>
                        <span class="skill-tag">SQL</span>
                    </div>
                </div>
            </aside>

            <!-- Jobs List -->
            <main class="jobs-list">
                <div class="jobs-header">
                    <div class="jobs-count">
                        <span id="jobCount">0</span> jobs found
                    </div>
                    <div class="jobs-sort">
                        <select id="sortOptions" class="sort-select">
                            <option value="recent">Most Recent</option>
                            <option value="salary">Highest Salary</option>
                            <option value="relevance">Most Relevant</option>
                        </select>
                    </div>
                </div>

                <!-- Jobs Container -->
                <div id="jobsContainer" class="jobs-grid">
                    <!-- Jobs will be dynamically inserted here -->
                </div>

                <!-- Pagination -->
                <div class="pagination">
                    <!-- Pagination will be dynamically inserted here -->
                </div>
            </main>
        </div>
    </div>
        </main>
    </div>
    <!-- Job Application Modal -->
    <div class="modal" id="applicationModal">
        <div class="modal-content">
            <!-- Left Panel -->
            <div class="modal-left-panel">
                <div class="company-header">
                    <img class="company-logo" src="" alt="">
                    <div class="company-info">
                        <h2 class="job-title"></h2>
                        <div class="company-meta">
                            <span class="company-name"></span>
                            <span class="location"></span>
                        </div>
                    </div>
                </div>

                <!-- Tabs Navigation -->
                <div class="tabs">
                    <button class="tab-btn active" data-tab="description">
                        <i class="fas fa-file-alt"></i>
                        Description
                    </button>
                    <button class="tab-btn" data-tab="requirements">
                        <i class="fas fa-list-check"></i>
                        Requirements
                    </button>
                    <button class="tab-btn" data-tab="benefits">
                        <i class="fas fa-gift"></i>
                        Benefits
                    </button>
                    <button class="tab-btn" data-tab="company">
                        <i class="fas fa-building"></i>
                        Company
                    </button>
                </div>

                <!-- Tab Content -->
                <div class="tab-content">
                    <div id="description" class="tab-pane active">
                        <div class="job-description"></div>
                        <div class="required-skills">
                            <h4>Required Skills</h4>
                            <div class="skills-list"></div>
                        </div>
                    </div>
                    <div id="requirements" class="tab-pane">
                        <div class="requirements-list"></div>
                    </div>
                    <div id="benefits" class="tab-pane">
                        <div class="benefits-list"></div>
                    </div>
                    <div id="company" class="tab-pane">
                        <div class="company-stats">
                            <div class="stat">
                                <i class="fas fa-users"></i>
                                <span class="employee-count"></span>
                            </div>
                            <div class="stat">
                                <i class="fas fa-star"></i>
                                <span class="company-rating"></span>
                            </div>
                            <div class="stat">
                                <i class="fas fa-globe"></i>
                                <a class="company-website" target="_blank"></a>
                            </div>
                        </div>
                        <div class="company-description"></div>
                    </div>
                </div>
            </div>

            <!-- Right Panel - Application Form -->
            <div class="modal-right-panel">
                <button type="button" class="close-modal">
                    <i class="fas fa-times"></i>
                </button>
                
                <div class="application-header">
                    <h3>Submit Your Application</h3>
                    <p>Please fill out the form below to apply for this position.</p>
                </div>

                <form id="jobApplicationForm" class="application-form">
                    <input type="hidden" name="job_id" id="jobId">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    
                    <div class="form-group">
                        <label for="resume">Resume/CV</label>
                        <div class="file-upload">
                            <input type="file" id="resume" name="resume" accept=".pdf,.doc,.docx" required>
                            <div class="file-upload-info">
                                <i class="fas fa-cloud-upload-alt"></i>
                                <span>Drop your resume here or <span class="browse-text">browse</span></span>
                                <small>Maximum file size: 5MB (PDF, DOC, DOCX)</small>
                            </div>
                            <div class="selected-file"></div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="coverLetter">Cover Letter</label>
                        <textarea id="coverLetter" name="cover_letter" rows="6" 
                            placeholder="Tell us why you're the perfect fit for this role..." required></textarea>
                        <div class="char-count">0/500</div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-paper-plane"></i>
                            Submit Application
                            <span class="spinner"></span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://www.bmreducation.in/project-4-1/assets/js/main.js"></script>
    <script src="/project-4-1/assets/js/job-filter.js"></script>
    <script src="/project-4-1/assets/js/application-modal.js"></script>
</body>
</html> 