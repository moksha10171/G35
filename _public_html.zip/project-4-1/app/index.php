<?php
session_start();
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$host = 'localhost';
$username = 'u291518478_project1';
$password = 'Moksha@10170+10171';
$dbname = 'u291518478_project1';

$loginUrl = 'https://www.bmreducation.in/project-4-1/login';
$logoutUrl = 'https://www.bmreducation.in/project-4-1/logout';

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    header("Location: $loginUrl");
    exit();
}

if (empty($_SESSION['session_new_project'])) {
    header("Location: $loginUrl");
    exit();
}

$stmt = $conn->prepare("SELECT * FROM session_access WHERE session_id = ?");
$stmt->bind_param("s", $_SESSION['session_new_project']);
$stmt->execute();
$userResult = $stmt->get_result();

if ($userResult->num_rows === 0) {
    header("Location: $logoutUrl");
    exit();
}

$userData = $userResult->fetch_assoc();

$stmt1 = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt1->bind_param("s", $userData['email']);
$stmt1->execute();
$adminResult = $stmt1->get_result();

if ($adminResult->num_rows === 0) {
    header("Location: $logoutUrl");
    exit();
}

$stmt->close();
$stmt1->close();
$conn->close();

function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$meta = inancap('../assets/layout/meta.php');
echo $meta;
?>
    <link rel="stylesheet" href="/project-4-1/assets/styles/dashboard.css">
<div class="dashboard-container">
        <!-- Enhanced Sidebar -->
        <aside class="dashboard-sidebar">
            <div class="sidebar-header">
                <div class="logo-wrapper">
                    <img src="../assets/images/logo-light.png" alt="Logo" class="logo-icon">
                </div>
                <button class="sidebar-toggle" id="sidebarToggle" aria-label="Toggle Sidebar">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            
            <nav class="sidebar-nav">
    <ul>
        <li class="active">
            <a href="/project-4-1/app/">
                <i class="fas fa-chart-line"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="/project-4-1/app/jobs">
                <i class="fas fa-briefcase"></i>
                <span>Browse Jobs</span>
            </a>
        </li>
        <li>
            <a href="/project-4-1/app/applications" class="nav-link-badge">
                <i class="fas fa-clipboard-list"></i>
                <span>Applications</span>
                <span class="badge">3</span>
            </a>
        </li>
        <li>
            <a href="/project-4-1/app/saved" class="nav-link-badge">
                <i class="fas fa-heart"></i>
                <span>Saved Jobs</span>
                <span class="badge">5</span>
            </a>
        </li>
    </ul>
</nav>
        </aside>

        <!-- Main Content Area -->
        <main class="dashboard-main">
            <!-- Updated Header Structure -->
            <header class="top-nav">
                <div class="nav-left">
                    <button class="search-toggle" aria-label="Toggle Search">
                        <i class="fas fa-search"></i>
                    </button>
                    <div class="search-wrapper">
                        <div class="search-bar">
                            <div class="search-input-wrapper">
                                <i class="fas fa-search search-icon"></i>
                                <input 
                                    type="text" 
                                    placeholder="Search jobs, companies, or keywords..." 
                                    aria-label="Search"
                                >
                                <button class="search-clear" aria-label="Clear search">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="nav-right">
                    <div class="nav-actions">
                        <button class="nav-btn" title="Messages">
                            <i class="fas fa-envelope"></i>
                            <span class="badge pulse">2</span>
                        </button>
                        <button class="nav-btn" title="Notifications">
                            <i class="fas fa-bell"></i>
                            <span class="badge">3</span>
                        </button>
                    </div>

                    <div class="user-menu" tabindex="0">
                        <div class="user-avatar">
                            <img
    src="<?php echo isset($userData['avatar']) && !empty($userData['avatar']) 
        ? '/project-4-1/uploads/profile_images/' . htmlspecialchars($userData['avatar']) 
        : '/project-4-1/assets/images/default-avatar.png'; ?>" 

                                alt="Profile" 
                                class="avatar"
                            >
                        </div>
                        <div class="user-info">
                            <span class="username">
                                <?php echo htmlspecialchars($userData['name'] ?? 'User'); ?>
                            </span>
                            <span class="user-role">
                                <?php echo htmlspecialchars($userData['role'] ?? 'Job Seeker'); ?>
                            </span>
                        </div>
                        <i class="fas fa-chevron-down dropdown-icon"></i>

                        <!-- Enhanced Dropdown Menu -->
                        <div class="user-dropdown">
                            <div class="dropdown-header">
                                <div class="user-preview">
                                    <img 
                                       
    src="<?php echo isset($userData['avatar']) && !empty($userData['avatar']) 
        ? '/project-4-1/uploads/profile_images/' . htmlspecialchars($userData['avatar']) 
        : '/project-4-1/assets/images/default-avatar.png'; ?>" 
                                        alt="Profile" 
                                        class="preview-avatar"
                                    >
                                    <div class="preview-info">
                                        <span class="preview-name"><?php echo htmlspecialchars($userData['name'] ?? 'User'); ?></span>
                                        <span class="preview-email"><?php echo htmlspecialchars($userData['email'] ?? 'email@example.com'); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="dropdown-content">
                                <a href="/project-4-1/app/profile" class="dropdown-item">
                                    <i class="fas fa-user"></i>
                                    <span>View Profile</span>
                                </a>
                                <a href="/project-4-1/app/settings" class="dropdown-item">
                                    <i class="fas fa-cog"></i>
                                    <span>Settings</span>
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="/project-4-1/logout" class="dropdown-item text-danger">
                                    <i class="fas fa-sign-out-alt"></i>
                                    <span>Logout</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Dashboard Content -->
            <div class="dashboard-content">
                <div class="welcome-section">
                    <div class="welcome-header">
                        <h1>Welcome back, <?php echo htmlspecialchars($userData['name'] ?? 'User'); ?>!</h1>
                        <p class="subtitle">Here's what's happening with your job search</p>
                    </div>
                    <div class="quick-actions">
                        <button class="action-btn primary">
                            <i class="fas fa-plus"></i>
                            <span>New Application</span>
                        </button>
                        <a class="action-btn secondary" href="/project-4-1/app/jobs">
                            <svg class="svg-inline--fa fa-search fa-w-16" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="search" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z"></path></svg><!-- <i class="fas fa-search"></i> Font Awesome fontawesome.com -->
                            <span>Find Jobs</span>
                        </a>
                    </div>
                </div>

                <!-- Enhanced Stats Grid -->
                <div class="stats-grid">
                    <div class="stat-card applications">
                        <div class="stat-icon" style="background: rgba(52, 152, 219, 0.1); color: #3498db;">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <div class="stat-details">
                            <h3>Applications</h3>
                            <div class="stat-main">
                                <p class="stat-number">0</p>
                                <div class="stat-trend">
                                    <span class="trend-indicator">
                                        <i class="fas fa-arrow-up"></i>
                                    </span>
                                    <span class="trend-value">0%</span>
                                </div>
                            </div>
                            <p class="stat-period">Last 7 days</p>
                        </div>
                    </div>

                    <div class="stat-card interviews">
                        <div class="stat-icon" style="background: rgba(46, 204, 113, 0.1); color: #2ecc71;">
                            <i class="fas fa-calendar-check"></i>
                        </div>
                        <div class="stat-details">
                            <h3>Interviews</h3>
                            <div class="stat-main">
                                <p class="stat-number">0</p>
                                <div class="stat-trend">
                                    <span class="trend-indicator">
                                        <i class="fas fa-minus"></i>
                                    </span>
                                    <span class="trend-value">0%</span>
                                </div>
                            </div>
                            <p class="stat-period">This month</p>
                        </div>
                    </div>

                    <div class="stat-card profile-views">
                        <div class="stat-icon" style="background: rgba(155, 89, 182, 0.1); color: #9b59b6;">
                            <i class="fas fa-eye"></i>
                        </div>
                        <div class="stat-details">
                            <h3>Profile Views</h3>
                            <div class="stat-main">
                                <p class="stat-number">0</p>
                                <div class="stat-trend">
                                    <span class="trend-indicator">
                                        <i class="fas fa-arrow-up"></i>
                                    </span>
                                    <span class="trend-value">0%</span>
                                </div>
                            </div>
                            <p class="stat-period">This week</p>
                        </div>
                    </div>
                </div>

                <!-- Enhanced Dashboard Grid -->
                <div class="dashboard-grid">
                    <section class="dashboard-section activity-section">
                        <div class="section-header">
                            <h2><i class="fas fa-history"></i> Recent Activity</h2>
                            <div class="section-actions">
                                <select class="activity-filter">
                                    <option value="all">All Activities</option>
                                    <option value="applications">Applications</option>
                                    <option value="interviews">Interviews</option>
                                    <option value="profile">Profile Updates</option>
                                </select>
                                <button class="btn-view-all">View All</button>
                            </div>
                        </div>
                        <div class="activity-list">
                            <!-- Activity items will be dynamically populated -->
                            <div class="loading-placeholder">
                                <div class="loading-spinner"></div>
                            </div>
                        </div>
                    </section>

                    <section class="dashboard-section jobs-section">
                        <div class="section-header">
                            <h2><i class="fas fa-star"></i> Recommended Jobs</h2>
                            <div class="section-actions">
                                <button class="btn-refresh">
                                    <i class="fas fa-sync-alt"></i>
                                </button>
                                <button class="btn-view-all">View All</button>
                            </div>
                        </div>
                        <div class="jobs-grid">
                            <!-- Job cards will be dynamically populated -->
                            <div class="loading-placeholder">
                                <div class="loading-spinner"></div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </main>
    </div>

    <script src="/project-4-1/assets/js/dashboard.js"></script>
    <script src="/project-4-1/assets/js/main.js"></script>
    <script src="/project-4-1/assets/js/chat_90.js"></script>
</body>
</html>