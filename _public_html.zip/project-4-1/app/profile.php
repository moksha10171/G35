<?php
session_start();
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$host = 'localhost';
$username = 'u291518478_project1';
$password = 'Moksha@10170+10171';
$dbname = 'u291518478_project1';

$loginUrl = 'https://www.bmreducation.in/project-4-1/login';
$logoutUrl = 'https://www.bmreducation.in/project-4-1/logout';

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    header("Location: $loginUrl");
    exit();
}

if (empty($_SESSION['session_new_project'])) {
    header("Location: $loginUrl");
    exit();
}

$stmt = $conn->prepare("SELECT * FROM session_access WHERE session_id = ?");
$stmt->bind_param("s", $_SESSION['session_new_project']);
$stmt->execute();
$userResult = $stmt->get_result();

if ($userResult->num_rows === 0) {
    header("Location: $logoutUrl");
    exit();
}
$userData = $userResult->fetch_assoc();

$stmt1 = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt1->bind_param("s", $userData['email']);
$stmt1->execute();
$adminResult = $stmt1->get_result();

$stmt = $conn->prepare("
    SELECT u.*, up.*
    FROM users u
    LEFT JOIN user_profiles up ON u.id = up.user_id
    WHERE u.uid = ?
");
$stmtr1 = $conn->prepare("
    SELECT u.*, up.*
    FROM users u
    LEFT JOIN user_profiles up ON u.id = up.user_id
    WHERE u.uid = ?
");
$stmtr1->bind_param("s", $userData['uid']);
$stmtr1->execute();
$userstmtr = $stmtr1->get_result();
$user = $userstmtr->fetch_assoc();



if ($adminResult->num_rows === 0) {
    header("Location: $logoutUrl");
    exit();
}

$stmt->close();
$stmt1->close();
$conn->close();

function inancap($filename) {
    ob_start();
    include $filename;
    return ob_get_clean();
}
$meta = inancap('../assets/layout/meta.php');
echo $meta;
?>
<link rel="stylesheet" href="../assets/styles/styles.915.20104.css">
<link rel="stylesheet" href="/project-4-1/assets/styles/profile-update.css">
    <link rel="stylesheet" href="/project-4-1/assets/styles/dashboard.css">
<div class="dashboard-container">
        <!-- Enhanced Sidebar -->
        <aside class="dashboard-sidebar">
            <div class="sidebar-header">
                <div class="logo-wrapper">
                    <img src="../assets/images/logo-light.png" alt="Logo" class="logo-icon">
                </div>
                <button class="sidebar-toggle" id="sidebarToggle" aria-label="Toggle Sidebar">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            
            <nav class="sidebar-nav">
    <ul>
        <li class="active">
            <a href="/project-4-1/app/">
                <i class="fas fa-chart-line"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="/project-4-1/app/jobs">
                <i class="fas fa-briefcase"></i>
                <span>Browse Jobs</span>
            </a>
        </li>
        <li>
            <a href="/project-4-1/app/applications" class="nav-link-badge">
                <i class="fas fa-clipboard-list"></i>
                <span>Applications</span>
                <span class="badge">3</span>
            </a>
        </li>
        <li>
            <a href="/project-4-1/app/saved" class="nav-link-badge">
                <i class="fas fa-heart"></i>
                <span>Saved Jobs</span>
                <span class="badge">5</span>
            </a>
        </li>
    </ul>
</nav>
        </aside>

        <!-- Main Content Area -->
        <main class="dashboard-main">
            <!-- Updated Header Structure -->
            <header class="top-nav">
                <div class="nav-left">
                    <button class="search-toggle" aria-label="Toggle Search">
                        <i class="fas fa-search"></i>
                    </button>
                    <div class="search-wrapper">
                        <div class="search-bar">
                            <div class="search-input-wrapper">
                                <i class="fas fa-search search-icon"></i>
                                <input 
                                    type="text" 
                                    placeholder="Search jobs, companies, or keywords..." 
                                    aria-label="Search"
                                >
                                <button class="search-clear" aria-label="Clear search">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="nav-right">
                    <div class="nav-actions">
                        <button class="nav-btn" title="Messages">
                            <i class="fas fa-envelope"></i>
                            <span class="badge pulse">2</span>
                        </button>
                        <button class="nav-btn" title="Notifications">
                            <i class="fas fa-bell"></i>
                            <span class="badge">3</span>
                        </button>
                    </div>

                    <div class="user-menu" tabindex="0">
                        <div class="user-avatar">
                            <img
    src="<?php echo isset($userData['avatar']) && !empty($userData['avatar']) 
        ? '/project-4-1/uploads/profile_images/' . htmlspecialchars($userData['avatar']) 
        : '/project-4-1/assets/images/default-avatar.png'; ?>" 

                                alt="Profile" 
                                class="avatar"
                            >
                        </div>
                        <div class="user-info">
                            <span class="username">
                                <?php echo htmlspecialchars($userData['name'] ?? 'User'); ?>
                            </span>
                            <span class="user-role">
                                <?php echo htmlspecialchars($userData['role'] ?? 'Job Seeker'); ?>
                            </span>
                        </div>
                        <i class="fas fa-chevron-down dropdown-icon"></i>

                        <!-- Enhanced Dropdown Menu -->
                        <div class="user-dropdown">
                            <div class="dropdown-header">
                                <div class="user-preview">
                                    <img 
                                       
    src="<?php echo isset($userData['avatar']) && !empty($userData['avatar']) 
        ? '/project-4-1/uploads/profile_images/' . htmlspecialchars($userData['avatar']) 
        : '/project-4-1/assets/images/default-avatar.png'; ?>" 
                                        alt="Profile" 
                                        class="preview-avatar"
                                    >
                                    <div class="preview-info">
                                        <span class="preview-name"><?php echo htmlspecialchars($userData['name'] ?? 'User'); ?></span>
                                        <span class="preview-email"><?php echo htmlspecialchars($userData['email'] ?? 'email@example.com'); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="dropdown-content">
                                <a href="/project-4-1/app/profile" class="dropdown-item">
                                    <i class="fas fa-user"></i>
                                    <span>View Profile</span>
                                </a>
                                <a href="/project-4-1/app/settings" class="dropdown-item">
                                    <i class="fas fa-cog"></i>
                                    <span>Settings</span>
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="/project-4-1/logout" class="dropdown-item text-danger">
                                    <i class="fas fa-sign-out-alt"></i>
                                    <span>Logout</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
<div class="profile-update-container">
    <!-- Profile Header with Background -->
    <div class="profile-header">
        <div class="header-content">
            <h1><i class="fas fa-user-circle"></i>Profile</h1>
            <p>Your personal and professional information</p>
        </div>
    </div>

    <form id="profileUpdateForm" class="profile-form" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        
        <!-- Main Content Grid -->
        <div class="profile-grid">
            <!-- Left Column - Profile Image -->
            <div class="profile-sidebar">
                <div class="profile-card">
                    <div class="profile-image-wrapper">
                        <div class="image-container">
                            <img id="profilePreview" 
                                 src="<?php echo '/project-4-1/uploads/profile_images/'.htmlspecialchars($user['image'] ?? '/assets/images/default-avatar.png'); ?>" 
                                 alt="Profile Picture">
                            <div class="image-overlay">
                                <label for="profileImage" class="upload-btn">
                                    <i class="fas fa-camera"></i>
                                    <span>Change Photo</span>
                                </label>
                            </div>
                        </div>
                        <input type="file" id="profileImage" name="profile_image" accept="image/*" hidden>
                        <p class="upload-hint">Maximum file size: 5MB<br>Supported formats: JPG, PNG, WebP</p>
                    </div>
                </div>
            </div>

            <!-- Right Column - Form Sections -->
            <div class="profile-content">
                <!-- Personal Information Card -->
                <div class="form-card">
                    <div class="card-header">
                        <i class="fas fa-user"></i>
                        <h2>Personal Information</h2>
                    </div>
                    <div class="card-body">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="name">Full Name*</label>
                                <input type="text" id="name" name="name" 
                                       value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>" 
                                       required maxlength="25">
                                <div class="input-hint">Maximum 25 characters</div>
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone Number</label>
                                <input type="tel" id="phone" name="phone" 
                                       value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>"
                                       placeholder="+1 (234) 567-8900">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="location">Location</label>
                            <input type="text" id="location" name="location" 
                                   value="<?php echo htmlspecialchars($user['location'] ?? ''); ?>"
                                   placeholder="City, Country">
                        </div>
                    </div>
                </div>

                <!-- Professional Information Card -->
                <div class="form-card">
                    <div class="card-header">
                        <i class="fas fa-briefcase"></i>
                        <h2>Professional Details</h2>
                    </div>
                    <div class="card-body">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="title">Job Title*</label>
                                <input type="text" id="title" name="title" 
                                       value="<?php echo htmlspecialchars($user['title'] ?? ''); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="company">Company*</label>
                                <input type="text" id="company" name="company" 
                                       value="<?php echo htmlspecialchars($user['company'] ?? ''); ?>" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="bio">Professional Bio</label>
                            <textarea id="bio" name="bio" rows="4" maxlength="500"
                                    placeholder="Tell us about your professional journey..."><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                            <div class="char-counter">
                                <span id="bioCharCount">0</span>/500 characters
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="form-actions">
                    <button type="button" class="btn-update-secon-profile" onclick="window.profileManager.resetForm()">
                        <i class="fas fa-undo"></i> Reset Changes
                    </button>
                    <button type="submit" class="btn-update-profile">
                        <i class="fas fa-save"></i> Save Profile
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>
        </main>
    </div>
<script src="/project-4-1/assets/js/profile-update.js"></script>