<?php
session_start();

class Auth {
    private $conn;
    
    public function __construct($db) {
        $this->conn = $db;
    }

    public function isAuthenticated() {
        if (!isset($_SESSION['session_new_project'])) {
            return false;
        }

        try {
            $stmt = $this->conn->prepare("
                SELECT sa.*, u.id as user_id 
                FROM session_access sa
                JOIN users u ON sa.email = u.email
                WHERE sa.session_id = ?
                AND sa.timeid > ?
            ");
            
            if (!$stmt) {
                return false;
            }

            $currentTime = time() - (24 * 60 * 60);
            $stmt->bind_param("si", $_SESSION['session_new_project'], $currentTime);
            
            if (!$stmt->execute()) {
                return false;
            }

            $result = $stmt->get_result();
            $session = $result->fetch_assoc();
            $stmt->close();

            if ($session) {
                if (!isset($_SESSION['user_id'])) {
                    $_SESSION['user_id'] = $session['user_id'];
                    $_SESSION['uid'] = $session['uid'];
                }
                return true;
            }
            return false;
        } catch (Exception $e) {
            error_log("Auth Error: " . $e->getMessage());
            return false;
        }
    }

    public function getUserDetails() {
        if (!$this->isAuthenticated()) {
            return null;
        }

        try {
            $stmt = $this->conn->prepare("
                SELECT id, name, email, uid, image, Login_Count, registered_time
                FROM users 
                WHERE id = ? AND uid = ?
            ");
            
            if (!$stmt) {
                return null;
            }

            $stmt->bind_param("is", $_SESSION['user_id'], $_SESSION['uid']);
            
            if (!$stmt->execute()) {
                return null;
            }

            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $stmt->close();
            
            return $user;
        } catch (Exception $e) {
            error_log("Get User Error: " . $e->getMessage());
            return null;
        }
    }

    public function requireAuth() {
        if (!$this->isAuthenticated()) {
            header('HTTP/1.1 401 Unauthorized');
            echo json_encode([
                'success' => false,
                'error' => 'Authentication required'
            ]);
            exit;
        }
    }
} 